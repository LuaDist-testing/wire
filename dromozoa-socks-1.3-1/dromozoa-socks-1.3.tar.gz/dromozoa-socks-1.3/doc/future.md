# future

## future state machine

```
         launch            finish
initial --------> running --------> ready
                   |   ^
           suspend |   | resume
                   v   |
                 suspended
```
