stringy
-------

fast string methods for: count, find, startswith, endswith, split.

version 0.3.2

