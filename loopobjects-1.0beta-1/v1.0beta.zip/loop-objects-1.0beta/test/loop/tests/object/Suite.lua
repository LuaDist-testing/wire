local Suite = require "loop.test.Suite"

return Suite{
	Wrapper      = require "loop.tests.object.Wrapper",
	Publisher    = require "loop.tests.object.Publisher",
}
