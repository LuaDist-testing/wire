local class = require 'middleclass'

local Vector = class('Vector')

return Vector
