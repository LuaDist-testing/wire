##Unofficial repositary of [vararg](http://www.tecgraf.puc-rio.br/~maia/lua/vararg)
[![Build Status](https://travis-ci.org/moteus/lua-vararg.png?branch=master)](https://travis-ci.org/moteus/lua-vararg)
