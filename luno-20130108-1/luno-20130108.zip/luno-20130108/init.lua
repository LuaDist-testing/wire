-- *****************************************************************************
-- Luno
-- Copyright (c) 2011-2013 Eric Chiesse de Souza (www.echiesse.com.br)
-- Read "License.txt" for the license terms
-- *****************************************************************************


-- Carregar todas as libs

require"luno.base"
lunoReset()

require"luno.util"
require"luno.string"
require"luno.table"
require"luno.io"
require"luno.functional"
require"luno.oop"

require"luno.argReader" -- <<<<< Considerar criar a lib "lunox" e colocar argReader nela
