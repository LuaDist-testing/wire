local Ftp = require "lluv.ftp"

Ftp.self_test()
