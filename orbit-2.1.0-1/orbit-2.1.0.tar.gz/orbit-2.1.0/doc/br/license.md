
Orbit é um software livre: ele pode ser usado para fins acadêmicos e comerciais sem custo algum. Não tem royalties, nem restrições de “copyleft” como a GNU. Orbit é um software open source. Sua licença é compatível com [GPL](http://www.gnu.org/copyleft/gpl.html). Orbit não é de domínio público e o Projeto

Orbit mantém seu copyright. Os detalhes legais seguem abaixo.
A idéia da licença é que você possa utilizar o Orbit livremente para qualquer finalidade, sem custo algum e sem precisar pedir permissão. O único requisito é que você nos dê o crédito caso utilize o Orbit, incluindo a notificação de *copyright* apropriada em algum lugar de seu produto ou documentação.

Orbit é desenvolvido e implementado pela equipe do Orbit. A implementação não é derivada de um software licenciado.


Copyright © 2004 Projeto Kepler.

-----------

Permissão é aqui dada, livre de cobranças, a qualquer pessoa obtendo uma cópia deste programa e de seus arquivos de documentação (o "Programa"), para distribuí-lo sem restrição, incluindo sem limitações os direitos de usar, copiar, modificar, associar, publicar, distribuir, sub-licenciar e/ou vender cópias do mesmo, e para permitir a pessoas a quem o Programa for fornecido os mesmos direitos, sujeitos somente às seguintes condições:

A nota de *copyright* acima e esta nota de permissão devem ser incluídas em todas as cópias ou porções substanciais do Programa.

O PROGRAMA É FORNECIDO TAL COMO ESTÁ, SEM GARANTIAS DE QUALQUER ESPÉCIE, EXPRESSAS OU IMPLÍCITAS, INCLUÍDAS MAS NÃO LIMITADAS ÀS GARANTIAS MERCANTIS, ÀS CAPAZES DE SATISFAZER INTERESSES PARTICULARES E ÀS DE NÃO INFRIGIMENTO DOS DIREITOS DE TERCEIROS. EM NENHUMA HIPÓTESE OS AUTORES OU DETENTORES DO COPYRIGHT DESTE PROGRAMA PODEM SER RESPONSABILIZADOS POR QUALQUER ACUSAÇÃO, SEJA DE DANOS, ESTRAGOS OU PREJUÍZOS, MESMO QUANDO PREVISTO EM CONTRATO OU EM QUALQUER OUTRO ARTIFÍCIO LEGAL, DECORRENTE OU EM CONEXÃO COM O USO DESTE PROGRAMA OU DE SUAS DISTRIBUIÇÕES.

