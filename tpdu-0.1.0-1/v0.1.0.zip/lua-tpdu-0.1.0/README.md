# lua-tpdu
[![Licence](http://img.shields.io/badge/Licence-MIT-brightgreen.svg)](LICENSE)
[![Build Status](https://travis-ci.org/moteus/lua-tpdu.svg?branch=master)](https://travis-ci.org/moteus/lua-tpdu)
[![Coverage Status](https://coveralls.io/repos/moteus/lua-tpdu/badge.svg?branch=master)](https://coveralls.io/r/moteus/lua-tpdu?branch=master)

TPDU encoder/decoder
