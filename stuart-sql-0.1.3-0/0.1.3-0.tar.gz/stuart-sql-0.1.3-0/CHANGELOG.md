## [0.1.3] - 2017-11-11
### Added:
- Support minimal `SparkSession` class
- LuaRocks packaging

<small>(formatted per [keepachangelog-1.1.0](http://keepachangelog.com/en/1.0.0/))</small>
