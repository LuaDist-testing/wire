# RomanNumerals
Module for convert numbers in Roman numbers :)

## Requires
Written for Lua 5.2

## Install
Install via luarocks: `$ luarocks install roman-numerals`

## Pages

Example [file](https://github.com/TiagoDanin/RomanNumerals/blob/master/start.lua)

Suggestions and Support [New Issue](https://github.com/TiagoDanin/RomanNumerals/issues/new)

For stable versions to access [Releases](https://github.com/TiagoDanin/RomanNumerals/releases)

## LICENSE
GNU GENERAL PUBLIC LICENSE V2 [(GPL)](https://github.com/TiagoDanin/RomanNumerals/blob/master/LICENSE)

---
>2016 Tiago Danin
