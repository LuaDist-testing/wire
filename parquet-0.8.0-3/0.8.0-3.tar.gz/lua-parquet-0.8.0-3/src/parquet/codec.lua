return {
  PLAIN = require 'parquet.codec.plain',
  RLE = require 'parquet.codec.rle'
}
