module("bar", package.seeall)

class_description [[

  method initialize(msg)
    self.message = msg
  end

]]
