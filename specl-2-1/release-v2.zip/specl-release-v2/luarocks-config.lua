rocks_trees = {
  "/Users/gary/Desktop/Dropbox/Project/specl--github--0/luarocks"
}
