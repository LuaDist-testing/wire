local lfs = require"lfs"
return require"path.lfs.impl.fs"(lfs)
