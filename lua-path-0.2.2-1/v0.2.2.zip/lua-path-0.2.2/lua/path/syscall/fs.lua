local lfs = require"syscall.lfs"
return require"path.lfs.impl.fs"(lfs)
