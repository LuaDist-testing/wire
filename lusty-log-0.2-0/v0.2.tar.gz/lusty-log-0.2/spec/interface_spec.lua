package.path = './spec/?.lua;../src/?.lua;'..package.path

describe("log interface", function()
  it("", function()
    assert.are.equal(true, true)
  end)
end)
