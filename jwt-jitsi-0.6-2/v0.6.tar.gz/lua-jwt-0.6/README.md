lua-jwt
=======

JSON Web Token library

http://tools.ietf.org/html/draft-ietf-oauth-json-web-token-15
