-- supporting testfile; belongs to 'cl_spec.lua'

describe("runs a single successful test", function()

  it("is a succesful test", function()
    -- nothing here, makes it succeed
  end)
  
end)
