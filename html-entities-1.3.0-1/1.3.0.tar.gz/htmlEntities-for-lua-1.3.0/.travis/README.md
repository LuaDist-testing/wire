Thank https://github.com/moteus/lua-travis-example :)
