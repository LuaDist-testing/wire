#!/usr/bin/env lua


return {

	connection = {
		type = 'PostgreSQL',
		host = 'pgserver.zadzmo.org',
		name = 'sqltable',
		user = 'sqltable',
		pass = 'testinguser-12345!!!'
	},
	
	table1_vendor = {
	},
	
	table2_vendor = {
	},
	
	table3_vendor = {
	}
}

