return {
  MAJOR = 11,
  MINOR = 1,
  PATCH = 1,
  STRING = '11.1.1',
}
