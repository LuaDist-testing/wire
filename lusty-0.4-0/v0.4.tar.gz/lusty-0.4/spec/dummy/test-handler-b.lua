return {
  handler = function(context)
    context.output = "b"
  end
}

