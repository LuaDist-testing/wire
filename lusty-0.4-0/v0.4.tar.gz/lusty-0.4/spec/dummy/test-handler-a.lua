return {
  handler = function(context)
    context.output = "a"
  end
}

