
require 'MyApp.Bar'
require 'MyApp.Bar.Foo'
require 'MyApp.Baz'
require 'MyApp.Baz.Foo'

