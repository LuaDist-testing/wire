
require 'Coat'

class 'MyApp.Baz'
