local gbk = require 'gbk'
print(gbk.fromutf8 "小墨是笨蛋")
