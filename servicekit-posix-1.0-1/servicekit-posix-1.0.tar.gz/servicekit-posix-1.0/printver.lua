#!/usr/local/bin/lua

--
-- This is part of the release script.
--
-- See release.sh for more explanation.
--


servicekit = dofile("./servicekit.lua")
print(servicekit.version)
