int xml_push_error(lua_State *L, xmlErrorPtr err);
