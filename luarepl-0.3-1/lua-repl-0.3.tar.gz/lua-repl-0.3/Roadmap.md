Future
======

  * Plugins
    * where do plugins store values (self, storage object, etc?)
    * configuration
    * global assignments in plugins
    * we need a way to do method advice in REPL "subclasses"
    * test: iffeature
    * test: using advice from within ifplugin/iffeature
  * Steal ideas from ilua
  * Async implementation
  * GTK implementation
  * IRC bot implementation
