local loop = {}

loop.pcall = pcall
loop.step = function() end

return loop
