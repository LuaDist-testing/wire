
lua-TestLongString
==================

Introduction
------------

lua-TestLongString is a port of the Perl5 module [Test::LongString](http://search.cpan.org/~rgarcia/Test-LongString/).

It is an extension of [lua-TestMore](http://fperrad.github.com/lua-TestMore/).

It provides functions for comparing and testing strings
that are not in plain text or are especially long.

Links
-----

The homepage is at [http://fperrad.github.com/lua-TestLongString/](http://fperrad.github.com/lua-TestLongString/),
and the sources are [hosted at http://github.com/fperrad/lua-TestLongString/](hosted at http://github.com/fperrad/lua-TestLongString/).

Copyright and License
---------------------

Copyright (c) 2009-2012 Francois Perrad

This library is licensed under the terms of the MIT/X11 license, like Lua itself.

