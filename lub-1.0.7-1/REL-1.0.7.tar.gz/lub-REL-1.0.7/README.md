lub [![Build Status](https://travis-ci.org/lubyk/lub.png)](https://travis-ci.org/lubyk/lub)
===

Lubyk core library (provides autoloading, helpers).

[Documentation](http://doc.lubyk.org/lub.html).

install
-------

    luadist install lub

or

    luarocks install lub
