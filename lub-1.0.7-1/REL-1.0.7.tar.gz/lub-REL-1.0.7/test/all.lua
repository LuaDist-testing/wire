local lub = require 'lub'
local lut = require 'lut'

lut.Test.files(lub.path '|')

