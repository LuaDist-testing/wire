-- This is the configurations for the FixMail filter plugin
-- Append that to your config file if you need to use this plugin
filter.fixmail.fix.date = true
filter.fixmail.fix.envelope = true

-- Also add the plugin to the list of filters in filter.plugin
-- I.E:
-- filter.plugin= {
--        "tethys2.plugins.filter.MySQL",
--        "tethys2.plugins.filter.FixMail",
--}
