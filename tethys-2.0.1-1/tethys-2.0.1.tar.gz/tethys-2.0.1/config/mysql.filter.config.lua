-- This is the configurations for the MySQL filter plugin
-- Append that to your config file if you need to use this pluging
filter.plugin = "tethys2.plugins.filter.MySQL"
filter.mysql.host = "localhost"
filter.mysql.user = "tethys"
filter.mysql.pass = "mypassword"
filter.mysql.base = "tethys"
