io.stderr:write("This is stderr\n")
io.stdout:write("This is stdout\n")
