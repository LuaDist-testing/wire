lua-luq
=======
[![Build Status](https://travis-ci.org/moteus/lua-luq.svg?branch=master)](https://travis-ci.org/moteus/lua-luq)
[![Build Status](https://buildhive.cloudbees.com/job/moteus/job/lua-luq/badge/icon)](https://buildhive.cloudbees.com/job/moteus/job/lua-luq/)

Light userdata queue

This library aimed to be low level basis to build pools of shared objects.
For now it implement only queues with fixed capacity but I have plan to implement
shared objects.

For examples see [lzmq-pool](https://github.com/moteus/lzmq-pool) and [odbc-pool](https://github.com/moteus/lua-odbc-pool).
