local sha1 = require "util.sha1";

return { sha1 = sha1.sha1 };
