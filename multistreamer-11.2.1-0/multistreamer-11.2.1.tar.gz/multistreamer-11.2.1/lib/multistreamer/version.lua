return {
  MAJOR = 11,
  MINOR = 2,
  PATCH = 1,
  STRING = '11.2.1',
}
