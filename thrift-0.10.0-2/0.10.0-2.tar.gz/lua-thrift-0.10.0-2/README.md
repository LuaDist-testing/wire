# lua-thrift

LuaRocks packaging of [Apache Thrift](https://thrift.apache.org).

## Installation

```bash
$ luarocks install thrift
```

## Testing

```
$ luarocks install busted
$ busted -v
●●
2 successes / 0 failures / 0 errors / 0 pending : 0.010238 seconds
```
