return {
  MAJOR = 11,
  MINOR = 0,
  PATCH = 0,
  STRING = '11.0.0',
}
