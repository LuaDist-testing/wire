return function (c)
  c = c + 0
  if c < 9793 then
    if c < 8570 then
      if c < 970 then
        if c < 328 then
          if c < 236 then
            if c < 182 then
              if c < 169 then
                if c < 162 then
                  if c < 127 then
                    if c < 32 then return "N" else return "Na" end
                  else
                    if c < 161 then return "N" else return "A" end
                  end
                else
                  if c < 165 then
                    if c < 164 then return "Na" else return "A" end
                  else
                    if c < 167 then return "Na" else return "A" end
                  end
                end
              else
                if c < 173 then
                  if c < 171 then
                    if c < 170 then return "N" else return "A" end
                  else
                    if c < 172 then return "N" else return "Na" end
                  end
                else
                  if c < 176 then
                    if c < 175 then return "A" else return "Na" end
                  else
                    if c < 181 then return "A" else return "N" end
                  end
                end
              end
            else
              if c < 215 then
                if c < 198 then
                  if c < 188 then
                    if c < 187 then return "A" else return "N" end
                  else
                    if c < 192 then return "A" else return "N" end
                  end
                else
                  if c < 208 then
                    if c < 199 then return "A" else return "N" end
                  else
                    if c < 209 then return "A" else return "N" end
                  end
                end
              else
                if c < 230 then
                  if c < 222 then
                    if c < 217 then return "A" else return "N" end
                  else
                    if c < 226 then return "A" else return "N" end
                  end
                else
                  if c < 232 then
                    if c < 231 then return "A" else return "N" end
                  else
                    if c < 235 then return "A" else return "N" end
                  end
                end
              end
            end
          else
            if c < 275 then
              if c < 252 then
                if c < 242 then
                  if c < 240 then
                    if c < 238 then return "A" else return "N" end
                  else
                    if c < 241 then return "A" else return "N" end
                  end
                else
                  if c < 247 then
                    if c < 244 then return "A" else return "N" end
                  else
                    if c < 251 then return "A" else return "N" end
                  end
                end
              else
                if c < 257 then
                  if c < 254 then
                    if c < 253 then return "A" else return "N" end
                  else
                    if c < 255 then return "A" else return "N" end
                  end
                else
                  if c < 273 then
                    if c < 258 then return "A" else return "N" end
                  else
                    if c < 274 then return "A" else return "N" end
                  end
                end
              end
            else
              if c < 305 then
                if c < 294 then
                  if c < 283 then
                    if c < 276 then return "A" else return "N" end
                  else
                    if c < 284 then return "A" else return "N" end
                  end
                else
                  if c < 299 then
                    if c < 296 then return "A" else return "N" end
                  else
                    if c < 300 then return "A" else return "N" end
                  end
                end
              else
                if c < 319 then
                  if c < 312 then
                    if c < 308 then return "A" else return "N" end
                  else
                    if c < 313 then return "A" else return "N" end
                  end
                else
                  if c < 324 then
                    if c < 323 then return "A" else return "N" end
                  else
                    if c < 325 then return "A" else return "N" end
                  end
                end
              end
            end
          end
        else
          if c < 711 then
            if c < 468 then
              if c < 363 then
                if c < 338 then
                  if c < 333 then
                    if c < 332 then return "A" else return "N" end
                  else
                    if c < 334 then return "A" else return "N" end
                  end
                else
                  if c < 358 then
                    if c < 340 then return "A" else return "N" end
                  else
                    if c < 360 then return "A" else return "N" end
                  end
                end
              else
                if c < 464 then
                  if c < 462 then
                    if c < 364 then return "A" else return "N" end
                  else
                    if c < 463 then return "A" else return "N" end
                  end
                else
                  if c < 466 then
                    if c < 465 then return "A" else return "N" end
                  else
                    if c < 467 then return "A" else return "N" end
                  end
                end
              end
            else
              if c < 476 then
                if c < 472 then
                  if c < 470 then
                    if c < 469 then return "A" else return "N" end
                  else
                    if c < 471 then return "A" else return "N" end
                  end
                else
                  if c < 474 then
                    if c < 473 then return "A" else return "N" end
                  else
                    if c < 475 then return "A" else return "N" end
                  end
                end
              else
                if c < 609 then
                  if c < 593 then
                    if c < 477 then return "A" else return "N" end
                  else
                    if c < 594 then return "A" else return "N" end
                  end
                else
                  if c < 708 then
                    if c < 610 then return "A" else return "N" end
                  else
                    if c < 709 then return "A" else return "N" end
                  end
                end
              end
            end
          else
            if c < 880 then
              if c < 728 then
                if c < 717 then
                  if c < 713 then
                    if c < 712 then return "A" else return "N" end
                  else
                    if c < 716 then return "A" else return "N" end
                  end
                else
                  if c < 720 then
                    if c < 718 then return "A" else return "N" end
                  else
                    if c < 721 then return "A" else return "N" end
                  end
                end
              else
                if c < 735 then
                  if c < 733 then
                    if c < 732 then return "A" else return "N" end
                  else
                    if c < 734 then return "A" else return "N" end
                  end
                else
                  if c < 768 then
                    if c < 736 then return "A" else return "N" end
                  else
                    return "A"
                  end
                end
              end
            else
              if c < 938 then
                if c < 930 then
                  if c < 913 then return "N" else return "A" end
                else
                  if c < 931 then return "N" else return "A" end
                end
              else
                if c < 962 then
                  if c < 945 then return "N" else return "A" end
                else
                  if c < 963 then return "N" else return "A" end
                end
              end
            end
          end
        end
      else
        if c < 8309 then
          if c < 8222 then
            if c < 4448 then
              if c < 1104 then
                if c < 1026 then
                  if c < 1025 then return "N" else return "A" end
                else
                  if c < 1040 then return "N" else return "A" end
                end
              else
                if c < 1106 then
                  if c < 1105 then return "N" else return "A" end
                else
                  if c < 4352 then return "N" else return "W" end
                end
              end
            else
              if c < 8215 then
                if c < 8209 then
                  if c < 8208 then return "N" else return "A" end
                else
                  if c < 8211 then return "N" else return "A" end
                end
              else
                if c < 8218 then
                  if c < 8216 then return "N" else return "A" end
                else
                  if c < 8220 then return "N" else return "A" end
                end
              end
            end
          else
            if c < 8244 then
              if c < 8232 then
                if c < 8227 then
                  if c < 8224 then return "N" else return "A" end
                else
                  if c < 8228 then return "N" else return "A" end
                end
              else
                if c < 8241 then
                  if c < 8240 then return "N" else return "A" end
                else
                  if c < 8242 then return "N" else return "A" end
                end
              end
            else
              if c < 8252 then
                if c < 8246 then
                  if c < 8245 then return "N" else return "A" end
                else
                  if c < 8251 then return "N" else return "A" end
                end
              else
                if c < 8255 then
                  if c < 8254 then return "N" else return "A" end
                else
                  if c < 8308 then return "N" else return "A" end
                end
              end
            end
          end
        else
          if c < 8468 then
            if c < 8365 then
              if c < 8325 then
                if c < 8320 then
                  if c < 8319 then return "N" else return "A" end
                else
                  if c < 8321 then return "N" else return "A" end
                end
              else
                if c < 8362 then
                  if c < 8361 then return "N" else return "H" end
                else
                  if c < 8364 then return "N" else return "A" end
                end
              end
            else
              if c < 8454 then
                if c < 8452 then
                  if c < 8451 then return "N" else return "A" end
                else
                  if c < 8453 then return "N" else return "A" end
                end
              else
                if c < 8458 then
                  if c < 8457 then return "N" else return "A" end
                else
                  if c < 8467 then return "N" else return "A" end
                end
              end
            end
          else
            if c < 8492 then
              if c < 8483 then
                if c < 8471 then
                  if c < 8470 then return "N" else return "A" end
                else
                  if c < 8481 then return "N" else return "A" end
                end
              else
                if c < 8487 then
                  if c < 8486 then return "N" else return "A" end
                else
                  if c < 8491 then return "N" else return "A" end
                end
              end
            else
              if c < 8543 then
                if c < 8533 then
                  if c < 8531 then return "N" else return "A" end
                else
                  if c < 8539 then return "N" else return "A" end
                end
              else
                if c < 8556 then
                  if c < 8544 then return "N" else return "A" end
                else
                  if c < 8560 then return "N" else return "A" end
                end
              end
            end
          end
        end
      end
    else
      if c < 8858 then
        if c < 8740 then
          if c < 8708 then
            if c < 8659 then
              if c < 8602 then
                if c < 8586 then
                  if c < 8585 then return "N" else return "A" end
                else
                  if c < 8592 then return "N" else return "A" end
                end
              else
                if c < 8634 then
                  if c < 8632 then return "N" else return "A" end
                else
                  if c < 8658 then return "N" else return "A" end
                end
              end
            else
              if c < 8680 then
                if c < 8661 then
                  if c < 8660 then return "N" else return "A" end
                else
                  if c < 8679 then return "N" else return "A" end
                end
              else
                if c < 8705 then
                  if c < 8704 then return "N" else return "A" end
                else
                  if c < 8706 then return "N" else return "A" end
                end
              end
            end
          else
            if c < 8722 then
              if c < 8716 then
                if c < 8713 then
                  if c < 8711 then return "N" else return "A" end
                else
                  if c < 8715 then return "N" else return "A" end
                end
              else
                if c < 8720 then
                  if c < 8719 then return "N" else return "A" end
                else
                  if c < 8721 then return "N" else return "A" end
                end
              end
            else
              if c < 8731 then
                if c < 8726 then
                  if c < 8725 then return "N" else return "A" end
                else
                  if c < 8730 then return "N" else return "A" end
                end
              else
                if c < 8737 then
                  if c < 8733 then return "N" else return "A" end
                else
                  if c < 8739 then return "N" else return "A" end
                end
              end
            end
          end
        else
          if c < 8787 then
            if c < 8760 then
              if c < 8749 then
                if c < 8742 then
                  if c < 8741 then return "N" else return "A" end
                else
                  if c < 8743 then return "N" else return "A" end
                end
              else
                if c < 8751 then
                  if c < 8750 then return "N" else return "A" end
                else
                  if c < 8756 then return "N" else return "A" end
                end
              end
            else
              if c < 8777 then
                if c < 8766 then
                  if c < 8764 then return "N" else return "A" end
                else
                  if c < 8776 then return "N" else return "A" end
                end
              else
                if c < 8781 then
                  if c < 8780 then return "N" else return "A" end
                else
                  if c < 8786 then return "N" else return "A" end
                end
              end
            end
          else
            if c < 8816 then
              if c < 8808 then
                if c < 8802 then
                  if c < 8800 then return "N" else return "A" end
                else
                  if c < 8804 then return "N" else return "A" end
                end
              else
                if c < 8812 then
                  if c < 8810 then return "N" else return "A" end
                else
                  if c < 8814 then return "N" else return "A" end
                end
              end
            else
              if c < 8840 then
                if c < 8836 then
                  if c < 8834 then return "N" else return "A" end
                else
                  if c < 8838 then return "N" else return "A" end
                end
              else
                if c < 8854 then
                  if c < 8853 then return "N" else return "A" end
                else
                  if c < 8857 then return "N" else return "A" end
                end
              end
            end
          end
        end
      else
        if c < 9652 then
          if c < 9204 then
            if c < 8988 then
              if c < 8896 then
                if c < 8870 then
                  if c < 8869 then return "N" else return "A" end
                else
                  if c < 8895 then return "N" else return "A" end
                end
              else
                if c < 8979 then
                  if c < 8978 then return "N" else return "A" end
                else
                  if c < 8986 then return "N" else return "W" end
                end
              end
            else
              if c < 9197 then
                if c < 9003 then
                  if c < 9001 then return "N" else return "W" end
                else
                  if c < 9193 then return "N" else return "W" end
                end
              else
                if c < 9201 then
                  if c < 9200 then return "N" else return "W" end
                else
                  if c < 9203 then return "N" else return "W" end
                end
              end
            end
          else
            if c < 9616 then
              if c < 9548 then
                if c < 9450 then
                  if c < 9312 then return "N" else return "A" end
                else
                  if c < 9451 then return "N" else return "A" end
                end
              else
                if c < 9588 then
                  if c < 9552 then return "N" else return "A" end
                else
                  if c < 9600 then return "N" else return "A" end
                end
              end
            else
              if c < 9634 then
                if c < 9622 then
                  if c < 9618 then return "N" else return "A" end
                else
                  if c < 9632 then return "N" else return "A" end
                end
              else
                if c < 9642 then
                  if c < 9635 then return "N" else return "A" end
                else
                  if c < 9650 then return "N" else return "A" end
                end
              end
            end
          end
        else
          if c < 9712 then
            if c < 9673 then
              if c < 9662 then
                if c < 9656 then
                  if c < 9654 then return "N" else return "A" end
                else
                  if c < 9660 then return "N" else return "A" end
                end
              else
                if c < 9666 then
                  if c < 9664 then return "N" else return "A" end
                else
                  if c < 9670 then return "N" else return "A" end
                end
              end
            else
              if c < 9682 then
                if c < 9676 then
                  if c < 9675 then return "N" else return "A" end
                else
                  if c < 9678 then return "N" else return "A" end
                end
              else
                if c < 9702 then
                  if c < 9698 then return "N" else return "A" end
                else
                  if c < 9711 then return "N" else return "A" end
                end
              end
            end
          else
            if c < 9744 then
              if c < 9735 then
                if c < 9727 then
                  if c < 9725 then return "N" else return "W" end
                else
                  if c < 9733 then return "N" else return "A" end
                end
              else
                if c < 9738 then
                  if c < 9737 then return "N" else return "A" end
                else
                  if c < 9742 then return "N" else return "A" end
                end
              end
            else
              if c < 9757 then
                if c < 9750 then
                  if c < 9748 then return "N" else return "W" end
                else
                  if c < 9756 then return "N" else return "A" end
                end
              else
                if c < 9759 then
                  if c < 9758 then return "N" else return "A" end
                else
                  if c < 9792 then return "N" else return "A" end
                end
              end
            end
          end
        end
      end
    end
  else
    if c < 65050 then
      if c < 10072 then
        if c < 9940 then
          if c < 9856 then
            if c < 9830 then
              if c < 9812 then
                if c < 9795 then
                  if c < 9794 then return "N" else return "A" end
                else
                  if c < 9800 then return "N" else return "W" end
                end
              else
                if c < 9826 then
                  if c < 9824 then return "N" else return "A" end
                else
                  if c < 9827 then return "N" else return "A" end
                end
              end
            else
              if c < 9838 then
                if c < 9835 then
                  if c < 9831 then return "N" else return "A" end
                else
                  if c < 9836 then return "N" else return "A" end
                end
              else
                if c < 9840 then
                  if c < 9839 then return "N" else return "A" end
                else
                  if c < 9855 then return "N" else return "W" end
                end
              end
            end
          else
            if c < 9900 then
              if c < 9888 then
                if c < 9876 then
                  if c < 9875 then return "N" else return "W" end
                else
                  if c < 9886 then return "N" else return "A" end
                end
              else
                if c < 9890 then
                  if c < 9889 then return "N" else return "W" end
                else
                  if c < 9898 then return "N" else return "W" end
                end
              end
            else
              if c < 9924 then
                if c < 9919 then
                  if c < 9917 then return "N" else return "W" end
                else
                  if c < 9920 then return "A" else return "N" end
                end
              else
                if c < 9934 then
                  if c < 9926 then return "W" else return "A" end
                else
                  if c < 9935 then return "W" else return "A" end
                end
              end
            end
          end
        else
          if c < 9984 then
            if c < 9970 then
              if c < 9956 then
                if c < 9954 then
                  if c < 9941 then return "W" else return "A" end
                else
                  if c < 9955 then return "N" else return "A" end
                end
              else
                if c < 9962 then
                  if c < 9960 then return "N" else return "A" end
                else
                  if c < 9963 then return "W" else return "A" end
                end
              end
            else
              if c < 9978 then
                if c < 9973 then
                  if c < 9972 then return "W" else return "A" end
                else
                  if c < 9974 then return "W" else return "A" end
                end
              else
                if c < 9981 then
                  if c < 9979 then return "W" else return "A" end
                else
                  if c < 9982 then return "W" else return "A" end
                end
              end
            end
          else
            if c < 10046 then
              if c < 9996 then
                if c < 9990 then
                  if c < 9989 then return "N" else return "W" end
                else
                  if c < 9994 then return "N" else return "W" end
                end
              else
                if c < 10025 then
                  if c < 10024 then return "N" else return "W" end
                else
                  if c < 10045 then return "N" else return "A" end
                end
              end
            else
              if c < 10063 then
                if c < 10061 then
                  if c < 10060 then return "N" else return "W" end
                else
                  if c < 10062 then return "N" else return "W" end
                end
              else
                if c < 10070 then
                  if c < 10067 then return "N" else return "W" end
                else
                  if c < 10071 then return "N" else return "W" end
                end
              end
            end
          end
        end
      else
        if c < 12439 then
          if c < 11089 then
            if c < 10176 then
              if c < 10136 then
                if c < 10112 then
                  if c < 10102 then return "N" else return "A" end
                else
                  if c < 10133 then return "N" else return "W" end
                end
              else
                if c < 10161 then
                  if c < 10160 then return "N" else return "W" end
                else
                  if c < 10175 then return "N" else return "W" end
                end
              end
            else
              if c < 10631 then
                if c < 10222 then
                  if c < 10214 then return "N" else return "Na" end
                else
                  if c < 10629 then return "N" else return "Na" end
                end
              else
                if c < 11037 then
                  if c < 11035 then return "N" else return "W" end
                else
                  if c < 11088 then return "N" else return "W" end
                end
              end
            end
          else
            if c < 12032 then
              if c < 11904 then
                if c < 11094 then
                  if c < 11093 then return "N" else return "W" end
                else
                  if c < 11098 then return "A" else return "N" end
                end
              else
                if c < 11931 then
                  if c < 11930 then return "W" else return "N" end
                else
                  if c < 12020 then return "W" else return "N" end
                end
              end
            else
              if c < 12288 then
                if c < 12272 then
                  if c < 12246 then return "W" else return "N" end
                else
                  if c < 12284 then return "W" else return "N" end
                end
              else
                if c < 12351 then
                  if c < 12289 then return "F" else return "W" end
                else
                  if c < 12353 then return "N" else return "W" end
                end
              end
            end
          end
        else
          if c < 13055 then
            if c < 12731 then
              if c < 12591 then
                if c < 12544 then
                  if c < 12441 then return "N" else return "W" end
                else
                  if c < 12549 then return "N" else return "W" end
                end
              else
                if c < 12687 then
                  if c < 12593 then return "N" else return "W" end
                else
                  if c < 12688 then return "N" else return "W" end
                end
              end
            else
              if c < 12831 then
                if c < 12772 then
                  if c < 12736 then return "N" else return "W" end
                else
                  if c < 12784 then return "N" else return "W" end
                end
              else
                if c < 12872 then
                  if c < 12832 then return "N" else return "W" end
                else
                  if c < 12880 then return "A" else return "W" end
                end
              end
            end
          else
            if c < 43389 then
              if c < 42125 then
                if c < 19904 then
                  if c < 13056 then return "N" else return "W" end
                else
                  if c < 19968 then return "N" else return "W" end
                end
              else
                if c < 42183 then
                  if c < 42128 then return "N" else return "W" end
                else
                  if c < 43360 then return "N" else return "W" end
                end
              end
            else
              if c < 63744 then
                if c < 55204 then
                  if c < 44032 then return "N" else return "W" end
                else
                  if c < 57344 then return "N" else return "A" end
                end
              else
                if c < 65024 then
                  if c < 64256 then return "W" else return "N" end
                else
                  if c < 65040 then return "A" else return "W" end
                end
              end
            end
          end
        end
      end
    else
      if c < 127799 then
        if c < 110960 then
          if c < 65498 then
            if c < 65377 then
              if c < 65127 then
                if c < 65107 then
                  if c < 65072 then return "N" else return "W" end
                else
                  if c < 65108 then return "N" else return "W" end
                end
              else
                if c < 65132 then
                  if c < 65128 then return "N" else return "W" end
                else
                  if c < 65281 then return "N" else return "F" end
                end
              end
            else
              if c < 65482 then
                if c < 65474 then
                  if c < 65471 then return "H" else return "N" end
                else
                  if c < 65480 then return "H" else return "N" end
                end
              else
                if c < 65490 then
                  if c < 65488 then return "H" else return "N" end
                else
                  if c < 65496 then return "H" else return "N" end
                end
              end
            end
          else
            if c < 94176 then
              if c < 65512 then
                if c < 65504 then
                  if c < 65501 then return "H" else return "N" end
                else
                  if c < 65511 then return "F" else return "N" end
                end
              else
                if c < 65533 then
                  if c < 65519 then return "H" else return "N" end
                else
                  if c < 65534 then return "A" else return "N" end
                end
              end
            else
              if c < 100352 then
                if c < 94208 then
                  if c < 94178 then return "W" else return "N" end
                else
                  if c < 100333 then return "W" else return "N" end
                end
              else
                if c < 110592 then
                  if c < 101107 then return "W" else return "N" end
                else
                  if c < 110879 then return "W" else return "N" end
                end
              end
            end
          end
        else
          if c < 127387 then
            if c < 127248 then
              if c < 127183 then
                if c < 126980 then
                  if c < 111356 then return "W" else return "N" end
                else
                  if c < 126981 then return "W" else return "N" end
                end
              else
                if c < 127232 then
                  if c < 127184 then return "W" else return "N" end
                else
                  if c < 127243 then return "A" else return "N" end
                end
              end
            else
              if c < 127344 then
                if c < 127280 then
                  if c < 127278 then return "A" else return "N" end
                else
                  if c < 127338 then return "A" else return "N" end
                end
              else
                if c < 127375 then
                  if c < 127374 then return "A" else return "W" end
                else
                  if c < 127377 then return "A" else return "W" end
                end
              end
            end
          else
            if c < 127568 then
              if c < 127504 then
                if c < 127488 then
                  if c < 127405 then return "A" else return "N" end
                else
                  if c < 127491 then return "W" else return "N" end
                end
              else
                if c < 127552 then
                  if c < 127548 then return "W" else return "N" end
                else
                  if c < 127561 then return "W" else return "N" end
                end
              end
            else
              if c < 127744 then
                if c < 127584 then
                  if c < 127570 then return "W" else return "N" end
                else
                  if c < 127590 then return "W" else return "N" end
                end
              else
                if c < 127789 then
                  if c < 127777 then return "W" else return "N" end
                else
                  if c < 127798 then return "W" else return "N" end
                end
              end
            end
          end
        end
      else
        if c < 128640 then
          if c < 128066 then
            if c < 127968 then
              if c < 127904 then
                if c < 127870 then
                  if c < 127869 then return "W" else return "N" end
                else
                  if c < 127892 then return "W" else return "N" end
                end
              else
                if c < 127951 then
                  if c < 127947 then return "W" else return "N" end
                else
                  if c < 127956 then return "W" else return "N" end
                end
              end
            else
              if c < 127992 then
                if c < 127988 then
                  if c < 127985 then return "W" else return "N" end
                else
                  if c < 127989 then return "W" else return "N" end
                end
              else
                if c < 128064 then
                  if c < 128063 then return "W" else return "N" end
                else
                  if c < 128065 then return "W" else return "N" end
                end
              end
            end
          else
            if c < 128378 then
              if c < 128331 then
                if c < 128255 then
                  if c < 128253 then return "W" else return "N" end
                else
                  if c < 128318 then return "W" else return "N" end
                end
              else
                if c < 128336 then
                  if c < 128335 then return "W" else return "N" end
                else
                  if c < 128360 then return "W" else return "N" end
                end
              end
            else
              if c < 128420 then
                if c < 128405 then
                  if c < 128379 then return "W" else return "N" end
                else
                  if c < 128407 then return "W" else return "N" end
                end
              else
                if c < 128507 then
                  if c < 128421 then return "W" else return "N" end
                else
                  if c < 128592 then return "W" else return "N" end
                end
              end
            end
          end
        else
          if c < 129408 then
            if c < 128756 then
              if c < 128720 then
                if c < 128716 then
                  if c < 128710 then return "W" else return "N" end
                else
                  if c < 128717 then return "W" else return "N" end
                end
              else
                if c < 128747 then
                  if c < 128723 then return "W" else return "N" end
                else
                  if c < 128749 then return "W" else return "N" end
                end
              end
            else
              if c < 129344 then
                if c < 129296 then
                  if c < 128761 then return "W" else return "N" end
                else
                  if c < 129343 then return "W" else return "N" end
                end
              else
                if c < 129360 then
                  if c < 129357 then return "W" else return "N" end
                else
                  if c < 129388 then return "W" else return "N" end
                end
              end
            end
          else
            if c < 196608 then
              if c < 129488 then
                if c < 129472 then
                  if c < 129432 then return "W" else return "N" end
                else
                  if c < 129473 then return "W" else return "N" end
                end
              else
                if c < 131072 then
                  if c < 129511 then return "W" else return "N" end
                else
                  if c < 196606 then return "W" else return "N" end
                end
              end
            else
              if c < 983040 then
                if c < 917760 then
                  if c < 262142 then return "W" else return "N" end
                else
                  if c < 918000 then return "A" else return "N" end
                end
              else
                if c < 1048576 then
                  if c < 1048574 then return "A" else return "N" end
                else
                  if c < 1114110 then return "A" else return "N" end
                end
              end
            end
          end
        end
      end
    end
  end
end
