lusty-store-mysql
=================

MySQL plugin for lusty persistence interface
