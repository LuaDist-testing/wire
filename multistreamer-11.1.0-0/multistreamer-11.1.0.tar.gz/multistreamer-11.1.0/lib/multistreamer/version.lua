return {
  MAJOR = 11,
  MINOR = 1,
  PATCH = 0,
  STRING = '11.1.0',
}
