# ljsyscall documentation

This is under development at present, and the best examples are currently the tests, or ask for help with a github issue.

Currently just experimenting with how to put documentation together. It needs to be cross platform, and explain the common Posix facilities as well as OS versions, either showing all of them or just for the flatform you are interested in. Thinking of experimenting with annotations, but will probably need more metadata.

Initial experiment with what we need to document ``open``.

