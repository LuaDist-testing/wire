-- arm64 ioctl differences

local arch = {
  ioctl = {
  }
}

return arch

