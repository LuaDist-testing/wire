-- ARM ioctl differences

local arch = {
  ioctl = {
    FIOQSIZE = 0x545E,
  }
}

return arch

