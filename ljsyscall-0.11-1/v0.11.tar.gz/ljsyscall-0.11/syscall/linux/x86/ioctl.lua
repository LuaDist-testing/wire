-- x86 ioctl differences

local arch = {
  ioctl = {
  }
}

return arch

