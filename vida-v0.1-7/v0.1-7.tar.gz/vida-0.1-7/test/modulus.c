EXPORT uint modulus(uint x, uint y) {
    return x % y;
}
