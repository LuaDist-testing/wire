return{
  _NAME = "PATH lua library";
  _VERSION = nil;
}