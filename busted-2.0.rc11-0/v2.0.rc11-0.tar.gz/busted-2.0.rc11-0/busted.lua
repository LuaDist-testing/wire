-- This is a dummy file so it can be used in busted's specs
-- without adding ./?/init.lua to the lua path
return require 'busted.init'
