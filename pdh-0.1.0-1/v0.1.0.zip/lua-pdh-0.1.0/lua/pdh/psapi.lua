-- @fixme
return assert(require"pdh.core".psapi, 'can not load `pdh.psapi` module')