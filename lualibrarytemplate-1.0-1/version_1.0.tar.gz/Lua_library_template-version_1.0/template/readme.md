Library generated from the Lua template library
===============================================

see https://github.com/Tieske/Lua_library_template/blob/master/readme.md 

License
=======
The generated code is MIT/X11 licensed, the same as Lua itself.
