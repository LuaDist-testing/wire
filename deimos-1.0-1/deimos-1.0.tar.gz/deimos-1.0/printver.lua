#!/usr/local/bin/lua

--
-- This is part of the release script.
--
-- See release.sh for more explanation.
--


deimos = dofile("./deimos.lua")
print(deimos.version)
