return require "lzmq.ffi".poller
