#!/bin/sh
ikiwiki doc/ html/ --no-usedirs --plugin=goodstuff --plugin=toc
