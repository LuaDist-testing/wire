# dromozoa-bind

Helper library for creating bindings between C++ and Lua.

```
git remote add bind git@github.com:dromozoa/dromozoa-bind.git
git subtree add --prefix bind --squash bind master
git subtree pull --prefix bind --squash bind master
```
