return {
  getRequest = function() return require 'dummy.request' end,
  getResponse = function() return require 'dummy.response' end
}
