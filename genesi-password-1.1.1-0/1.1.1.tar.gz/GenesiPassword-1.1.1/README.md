## GenesiPassword [![Build Status](https://travis-ci.org/TiagoDanin/GenesiPassword.svg?branch=master)](https://travis-ci.org/TiagoDanin/GenesiPassword) [![GPLv3](https://img.shields.io/aur/license/yaourt.svg?maxAge=2592000)](https://github.com/Tiagodanin/GenesiPassword/blob/master/LICENSE) [![Luarocks](https://img.shields.io/badge/Luarocks-genesi--password-yellow.svg)](http://luarocks.org/modules/tiagodanin/genesi-password)
**Module and tool for create password**

## Requires
Written for Lua 5.3

## Install And Run
Install: `$ luarocks install genesi-password`

Run: `$ genesiPassword`

## Pages

Suggestions and Support [New Issue](https://github.com/Tiagodanin/GenesiPassword/issues/new)

For stable versions to access [Releases](https://github.com/Tiagodanin/GenesiPassword/releases)

## LICENSE
GNU GENERAL PUBLIC LICENSE V3 [(GPL)](https://github.com/Tiagodanin/GenesiPassword/blob/master/LICENSE)

---
>2016 Tiago Danin
