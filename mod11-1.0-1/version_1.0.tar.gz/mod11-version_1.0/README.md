mod11
=====

[![travis-ci status](https://secure.travis-ci.org/Tieske/mod11.png)](http://travis-ci.org/#!/Tieske/mod11/builds)

Lua modulo11 number generator and verificator

[Documentation](http://tieske.github.io/mod11/) is available online at github as is the [source code](https://github.com/Tieske/mod11)