A Lua Binding for various Unix functions and system calls

Copyright (C) 2014 - 2016 by Micro Systems Marc Balmer.
All rights reserved.

NB: This module does not aim to be complete, it mereley contains functions
that I needed at some point of time.

