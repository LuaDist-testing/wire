## [0.1.5] - 2017-12-10
### Added:
- Support reading a Parquet file into an RDD

## [0.1.3] - 2017-11-11
### Added:
- Support minimal `SparkSession` class
- LuaRocks packaging

<small>(formatted per [keepachangelog-1.1.0](http://keepachangelog.com/en/1.0.0/))</small>
