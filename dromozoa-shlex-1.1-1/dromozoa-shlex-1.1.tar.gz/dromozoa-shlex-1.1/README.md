# dromozoa-shlex

Simple lexical analyzer like Python's shlex.
