if [ "$(uname)" == "Linux" ]; then
  PLATFORM="linux";
else
  PLATFORM="macosx";
fi;
