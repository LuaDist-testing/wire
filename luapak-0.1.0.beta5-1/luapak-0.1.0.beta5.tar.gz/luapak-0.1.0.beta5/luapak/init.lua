---------
-- The main module.
----

return {
  --- The module's name.
  _NAME = 'luapak',
  --- The module's version number.
  _VERSION = '0.1.0.beta5',
  --- The module's homepage.
  _HOMEPAGE = 'https://github.com/jirutka/luapak',
}
