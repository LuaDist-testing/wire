#ifndef _TEK_PROTO_DISPLAY_H
#define _TEK_PROTO_DISPLAY_H

#include <tek/mod/display.h>
#include <tek/stdcall/display.h>

extern TMODENTRY TUINT
tek_init_display(struct TTask *, struct TModule *, TUINT16, TTAGITEM *);

#endif /* _TEK_PROTO_DISPLAY_H */
