#ifndef _TEK_MOD_DISPLAY_H
#define _TEK_MOD_DISPLAY_H

/*
**	tek/mod/display.h - Display driver interface
*/

#include <tek/exec.h>

/*****************************************************************************/
/*
**	Forward declarations
*/

/* Display module base structure: */
struct TDisplayBase;

#endif
