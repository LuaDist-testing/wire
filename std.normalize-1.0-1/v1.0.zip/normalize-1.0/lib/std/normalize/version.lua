return "Normalized Lua Functions / 1.0"
