#!/bin/sh
lua ./bin/smithsnmpd -c config/agentx.conf
