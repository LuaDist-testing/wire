#!/bin/sh
lua ./bin/smithsnmpd -c config/snmp.conf
