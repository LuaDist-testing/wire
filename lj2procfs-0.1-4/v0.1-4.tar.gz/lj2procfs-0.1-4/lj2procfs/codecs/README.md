AVAILABLE
=========
* buddyinfo
* cgroups
* cmdline
* cpuinfo
* crypto
* diskstats
* interrupts
* iomem
* ioports
* kallsyms
* linkchaser - cwd, exe, root
* loadavg
* meminfo
* modules
* net
* partitions
* softirqs
* uptime
* vmstat

Per Process
-----------
* environ
* exe
* io
* limits
* maps
* mounts
* sched
* status


TODO - Flat files in /proc
====
buddyinfo
consoles
devices
dma
execdomains
filesystems
kcore
keys
key-users
kmsg
kpagecount
kpageflags
locks
mdstat
misc
mtrr
pagetypeinfo
sched_debug
schedstat
slabinfo
stat
swaps
sysrq-trigger
timer_list
timer_stats
version
version_signature
vmallocinfo
zoneinfo
