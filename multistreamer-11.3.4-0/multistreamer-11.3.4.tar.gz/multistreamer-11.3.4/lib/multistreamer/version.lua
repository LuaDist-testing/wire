return {
  MAJOR = 11,
  MINOR = 3,
  PATCH = 4,
  STRING = '11.3.4',
}
