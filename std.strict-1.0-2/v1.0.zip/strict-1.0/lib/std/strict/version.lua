return "Strict Variable Declaration / 1.0"
