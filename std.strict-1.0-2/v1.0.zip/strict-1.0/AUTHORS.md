# Strict's contributors

Gary V. Vaughan rewrote the strict module to work for individual
environments as well as the `_G` table of global variables, and
separated back out into a standalone library.

Reuben Thomas brought `strict.lua` into the `lua-stdlib` standard
libraries project he created, and maintained it there for several years
to work seamlessly with the other stdlib modules.

The original stdlib `strict.lua` code was based on `etc/strict.lua` from
the PUC Rio Lua 5.0 distribution.
