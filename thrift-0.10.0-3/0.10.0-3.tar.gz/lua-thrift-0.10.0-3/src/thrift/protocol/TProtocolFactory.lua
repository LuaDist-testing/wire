local class = require 'middleclass'

local TProtocolFactory = class('TProtocolFactory')

function TProtocolFactory:getProtocol() end

return TProtocolFactory

