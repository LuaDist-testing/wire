return 'posix for ' .. _VERSION .. ' / luaposix 34.0.1'
