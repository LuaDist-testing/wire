
# Coat.Persistent.lsqlite3

---

# Reference

Just an alternate implementation using
[LuaSQLite3](http://lua.sqlite.org/) (instead of
[LuaSQL](http://www.keplerproject.org/luasql/) library).

# Examples

```lua
require 'Coat.Persistent.lsqlite3'  -- instead of require 'Coat.Persistent'
```
