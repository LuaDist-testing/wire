NetChewck is free software under the MIT/X11 license.
Copyright 2011 Thijs Schreijer

See included documentation for usage, source is available at
http://github.com/Tieske/netcheck

Changelog;
===================================================================
23-Nov-2011; Initial release 0.1.0

-------------------------------------------------------------------
