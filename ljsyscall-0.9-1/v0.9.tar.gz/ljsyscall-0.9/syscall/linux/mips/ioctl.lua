-- MIPS ioctl differences

return function(s)

local arch = {
  ioctl = {
  }
}

return arch

end

