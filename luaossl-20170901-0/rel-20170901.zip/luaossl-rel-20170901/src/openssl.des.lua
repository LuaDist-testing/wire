local ctx = require"_openssl.des"

return ctx
