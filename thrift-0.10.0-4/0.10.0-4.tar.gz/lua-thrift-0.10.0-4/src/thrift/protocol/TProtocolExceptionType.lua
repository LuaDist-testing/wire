return {
  UNKNOWN          = 0,
  INVALID_DATA     = 1,
  NEGATIVE_SIZE    = 2,
  SIZE_LIMIT       = 3,
  BAD_VERSION      = 4,
  INVALID_PROTOCOL = 5,
  DEPTH_LIMIT      = 6
}
