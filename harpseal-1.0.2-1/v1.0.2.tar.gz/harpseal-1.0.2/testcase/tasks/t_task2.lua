return {
	y = def:reduce("?", "testcase.tasks.t_task3", function(result)
		return 'HI'
	end)
}