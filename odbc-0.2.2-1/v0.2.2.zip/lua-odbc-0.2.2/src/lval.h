#ifndef _LVAL_H_FFB77533_6339_45E8_95B2_2EB730EA7578_
#define _LVAL_H_FFB77533_6339_45E8_95B2_2EB730EA7578_

#include <lua.h>
#include "lodbc.h"

LODBC_INTERNAL void lodbc_val_initlib (lua_State *L, int nup);

#endif