# lustache-lambdas

Useful [lambdas](http://mustache.github.io/mustache.5.html) for {{[lustache](https://github.com/Olivine-Labs/lustache)}}
