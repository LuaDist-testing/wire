package.path = './spec/?.lua;../src/?.lua;'..package.path

describe("Config", function()
  it("", function()
    assert.are.equal(true, true)
  end)
end)
