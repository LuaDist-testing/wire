local M = {}

function M.new()
  error('not implemented yet')
end

return M
