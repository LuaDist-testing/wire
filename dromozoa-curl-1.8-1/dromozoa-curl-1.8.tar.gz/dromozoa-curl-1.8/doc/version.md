System | Version | URL
----|----|----
CentOS 5 | 7.15.5 |
CentOS 6 | 7.19.7 | http://mirror.centos.org/centos/6/os/x86_64/Packages/
CentOS 7 | 7.29.0 | http://mirror.centos.org/centos/7/os/x86_64/Packages/
Amazon Linux AMI 2016.09 | 7.47.1 | https://aws.amazon.com/jp/amazon-linux-ami/2016.09-packages/
OS X 10.10.5 | 7.43.0 |
OS X 10.12.3 | 7.51.0 |
Raspbian GNU/Linux 8 (jessie) | 7.38.0 |
