# `luatz.parse`

Provides parsers for common time and date formats.

Functions take the source string and an optional initial postition.

### `rfc_3339 ( string [, init] )`

Returns a luatz timetable and the (optional) time zone offset in seconds
