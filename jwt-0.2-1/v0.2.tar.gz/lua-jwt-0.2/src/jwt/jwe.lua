local data = {}

function data:encode(claims, options)
  return nil, "Not Implemented"
end

function data:decode(header, str, options)
  return nil, "Not Implemented"
end

return data
