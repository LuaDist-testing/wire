
## Df_Dict

The Df_Dict is a class that is used to wrap a dictionary table. A dictionary table
has a string name corresponding to each key and an array as values, i.e. it may
not contain any tables.

