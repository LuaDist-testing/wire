
## Df_Array

The Df_Array is a class that is used to wrap an array table. An array table
no key names, it only uses numbers for indexing and each element has to be
an atomic element, i.e. it may not contain any tables.

