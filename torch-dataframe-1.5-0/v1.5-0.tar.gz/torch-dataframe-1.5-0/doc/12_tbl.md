
## Df_Tbl

The Df_Tbl is a class that is used to wrap a table. In contrast with Df_Array
and Df_Dict it does not check any input data.

