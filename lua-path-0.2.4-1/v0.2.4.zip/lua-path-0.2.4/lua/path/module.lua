return{
  _NAME = "PATH lua library";
  _VERSION = "0.2.4";
}