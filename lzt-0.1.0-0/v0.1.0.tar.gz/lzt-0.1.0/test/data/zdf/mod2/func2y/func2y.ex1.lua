local t = require( "tapered" )
local func2y = require( "func2y" )
--TODO
t.nok( true )
t.done()
