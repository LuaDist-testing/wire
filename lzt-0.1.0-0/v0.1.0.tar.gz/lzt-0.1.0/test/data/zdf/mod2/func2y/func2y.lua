local liby = require( "liby" ) --ZREQ-liby

--ZFUNC-func2y-v2
local function func2y( ... )
   --TODO
end

return func2y
