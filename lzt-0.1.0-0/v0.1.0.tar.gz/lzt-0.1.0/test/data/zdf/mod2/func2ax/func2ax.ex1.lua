local t = require( "tapered" )
local func2ax = require( "func2ax" )

t.is( "ax", func2ax() )
t.done()
