local t = require( "tapered" )
local func2z = require( "func2z" )
--TODO
t.nok( true )
t.done()
