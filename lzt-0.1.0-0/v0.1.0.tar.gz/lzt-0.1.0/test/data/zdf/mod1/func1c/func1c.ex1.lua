local t = require( "tapered" )
local func1c = require( "func1c" )
--TODO
t.nok( true )
t.done()
