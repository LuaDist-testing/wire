local ccc = require( "ccc" ) --ZREQ-ccc

--ZFUNC-func1c-v1
local function func1c( ... )
   --TODO
end

return func1c
