local t = require( "tapered" )
local func1b = require( "func1b" )
--TODO
t.nok( true )
t.done()
