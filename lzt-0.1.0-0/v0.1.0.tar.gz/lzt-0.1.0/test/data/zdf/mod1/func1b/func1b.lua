--ZFUNC-func1b-v1
local function func1b()
   return "b"
end

return func1b
