local t = require( "tapered" )
local func1dax = require( "func1dax" )

t.is( "dax", func1dax() )
t.done()
