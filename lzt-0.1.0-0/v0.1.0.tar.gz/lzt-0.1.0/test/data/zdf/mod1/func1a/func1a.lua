--ZFUNC-func1a-v1
local function func1a()
   return "a"
end

return func1a
