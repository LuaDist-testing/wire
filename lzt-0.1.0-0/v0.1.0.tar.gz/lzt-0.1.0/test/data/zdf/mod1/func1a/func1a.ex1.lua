local t = require( "tapered" )
local func1a = require( "func1a" )

t.is( "a", func1a() )
t.done()
