--ZFUNC-func1a-v1
local function func1a()
   return "a"
end
--ZFUNC-func2y-v1
local function func2y( ... )
   --TODO
end
--ZFUNC-unknownfunction-v3
