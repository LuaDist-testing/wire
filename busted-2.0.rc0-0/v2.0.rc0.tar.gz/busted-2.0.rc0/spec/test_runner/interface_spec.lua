describe('does a describe', function()
  for i = 1, 1000 do
    it('does 1000 its', function()
      assert(true)
    end)
  end
end)
