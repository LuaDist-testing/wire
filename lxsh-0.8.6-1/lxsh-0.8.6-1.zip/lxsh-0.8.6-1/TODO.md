# To-do list for LXSH

 * Proper support for Lua's interactive mode! (this is something I miss in every other highlighter out there)
 * Support for lexing and highlighting of SGML (HTML and XML), CSS
 * Make the documentation links optional (but enabled by default)
