return function (c)
  c = c + 0
  if c < 11399 then
    if c < 3342 then
      if c < 1212 then
        if c < 485 then
          if c < 325 then
            if c < 260 then
              if c < 166 then
                if c < 65 then
                  if c < 43 then
                    if c < 37 then
                      if c < 33 then
                        if c < 32 then return "Cc" else return "Zs" end
                      else
                        if c < 36 then return "Po" else return "Sc" end
                      end
                    else
                      if c < 41 then
                        if c < 40 then return "Po" else return "Ps" end
                      else
                        if c < 42 then return "Pe" else return "Po" end
                      end
                    end
                  else
                    if c < 48 then
                      if c < 45 then
                        if c < 44 then return "Sm" else return "Po" end
                      else
                        if c < 46 then return "Pd" else return "Po" end
                      end
                    else
                      if c < 60 then
                        if c < 58 then return "Nd" else return "Po" end
                      else
                        if c < 63 then return "Sm" else return "Po" end
                      end
                    end
                  end
                else
                  if c < 123 then
                    if c < 94 then
                      if c < 92 then
                        if c < 91 then return "Lu" else return "Ps" end
                      else
                        if c < 93 then return "Po" else return "Pe" end
                      end
                    else
                      if c < 96 then
                        if c < 95 then return "Sk" else return "Pc" end
                      else
                        if c < 97 then return "Sk" else return "Ll" end
                      end
                    end
                  else
                    if c < 127 then
                      if c < 125 then
                        if c < 124 then return "Ps" else return "Sm" end
                      else
                        if c < 126 then return "Pe" else return "Sm" end
                      end
                    else
                      if c < 161 then
                        if c < 160 then return "Cc" else return "Zs" end
                      else
                        if c < 162 then return "Po" else return "Sc" end
                      end
                    end
                  end
                end
              else
                if c < 184 then
                  if c < 174 then
                    if c < 170 then
                      if c < 168 then
                        if c < 167 then return "So" else return "Po" end
                      else
                        if c < 169 then return "Sk" else return "So" end
                      end
                    else
                      if c < 172 then
                        if c < 171 then return "Lo" else return "Pi" end
                      else
                        if c < 173 then return "Sm" else return "Cf" end
                      end
                    end
                  else
                    if c < 178 then
                      if c < 176 then
                        if c < 175 then return "So" else return "Sk" end
                      else
                        if c < 177 then return "So" else return "Sm" end
                      end
                    else
                      if c < 181 then
                        if c < 180 then return "No" else return "Sk" end
                      else
                        if c < 182 then return "Ll" else return "Po" end
                      end
                    end
                  end
                else
                  if c < 216 then
                    if c < 188 then
                      if c < 186 then
                        if c < 185 then return "Sk" else return "No" end
                      else
                        if c < 187 then return "Lo" else return "Pf" end
                      end
                    else
                      if c < 192 then
                        if c < 191 then return "No" else return "Po" end
                      else
                        if c < 215 then return "Lu" else return "Sm" end
                      end
                    end
                  else
                    if c < 256 then
                      if c < 247 then
                        if c < 223 then return "Lu" else return "Ll" end
                      else
                        if c < 248 then return "Sm" else return "Ll" end
                      end
                    else
                      if c < 258 then
                        if c < 257 then return "Lu" else return "Ll" end
                      else
                        if c < 259 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              end
            else
              if c < 292 then
                if c < 276 then
                  if c < 268 then
                    if c < 264 then
                      if c < 262 then
                        if c < 261 then return "Lu" else return "Ll" end
                      else
                        if c < 263 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 266 then
                        if c < 265 then return "Lu" else return "Ll" end
                      else
                        if c < 267 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 272 then
                      if c < 270 then
                        if c < 269 then return "Lu" else return "Ll" end
                      else
                        if c < 271 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 274 then
                        if c < 273 then return "Lu" else return "Ll" end
                      else
                        if c < 275 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 284 then
                    if c < 280 then
                      if c < 278 then
                        if c < 277 then return "Lu" else return "Ll" end
                      else
                        if c < 279 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 282 then
                        if c < 281 then return "Lu" else return "Ll" end
                      else
                        if c < 283 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 288 then
                      if c < 286 then
                        if c < 285 then return "Lu" else return "Ll" end
                      else
                        if c < 287 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 290 then
                        if c < 289 then return "Lu" else return "Ll" end
                      else
                        if c < 291 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              else
                if c < 308 then
                  if c < 300 then
                    if c < 296 then
                      if c < 294 then
                        if c < 293 then return "Lu" else return "Ll" end
                      else
                        if c < 295 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 298 then
                        if c < 297 then return "Lu" else return "Ll" end
                      else
                        if c < 299 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 304 then
                      if c < 302 then
                        if c < 301 then return "Lu" else return "Ll" end
                      else
                        if c < 303 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 306 then
                        if c < 305 then return "Lu" else return "Ll" end
                      else
                        if c < 307 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 317 then
                    if c < 313 then
                      if c < 310 then
                        if c < 309 then return "Lu" else return "Ll" end
                      else
                        if c < 311 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 315 then
                        if c < 314 then return "Lu" else return "Ll" end
                      else
                        if c < 316 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 321 then
                      if c < 319 then
                        if c < 318 then return "Lu" else return "Ll" end
                      else
                        if c < 320 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 323 then
                        if c < 322 then return "Lu" else return "Ll" end
                      else
                        if c < 324 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              end
            end
          else
            if c < 398 then
              if c < 358 then
                if c < 342 then
                  if c < 334 then
                    if c < 330 then
                      if c < 327 then
                        if c < 326 then return "Lu" else return "Ll" end
                      else
                        if c < 328 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 332 then
                        if c < 331 then return "Lu" else return "Ll" end
                      else
                        if c < 333 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 338 then
                      if c < 336 then
                        if c < 335 then return "Lu" else return "Ll" end
                      else
                        if c < 337 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 340 then
                        if c < 339 then return "Lu" else return "Ll" end
                      else
                        if c < 341 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 350 then
                    if c < 346 then
                      if c < 344 then
                        if c < 343 then return "Lu" else return "Ll" end
                      else
                        if c < 345 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 348 then
                        if c < 347 then return "Lu" else return "Ll" end
                      else
                        if c < 349 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 354 then
                      if c < 352 then
                        if c < 351 then return "Lu" else return "Ll" end
                      else
                        if c < 353 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 356 then
                        if c < 355 then return "Lu" else return "Ll" end
                      else
                        if c < 357 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              else
                if c < 374 then
                  if c < 366 then
                    if c < 362 then
                      if c < 360 then
                        if c < 359 then return "Lu" else return "Ll" end
                      else
                        if c < 361 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 364 then
                        if c < 363 then return "Lu" else return "Ll" end
                      else
                        if c < 365 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 370 then
                      if c < 368 then
                        if c < 367 then return "Lu" else return "Ll" end
                      else
                        if c < 369 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 372 then
                        if c < 371 then return "Lu" else return "Ll" end
                      else
                        if c < 373 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 385 then
                    if c < 379 then
                      if c < 376 then
                        if c < 375 then return "Lu" else return "Ll" end
                      else
                        if c < 378 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 381 then
                        if c < 380 then return "Lu" else return "Ll" end
                      else
                        if c < 382 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 390 then
                      if c < 388 then
                        if c < 387 then return "Lu" else return "Ll" end
                      else
                        if c < 389 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 393 then
                        if c < 392 then return "Lu" else return "Ll" end
                      else
                        if c < 396 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              end
            else
              if c < 452 then
                if c < 425 then
                  if c < 415 then
                    if c < 406 then
                      if c < 403 then
                        if c < 402 then return "Lu" else return "Ll" end
                      else
                        if c < 405 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 412 then
                        if c < 409 then return "Lu" else return "Ll" end
                      else
                        if c < 414 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 420 then
                      if c < 418 then
                        if c < 417 then return "Lu" else return "Ll" end
                      else
                        if c < 419 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 422 then
                        if c < 421 then return "Lu" else return "Ll" end
                      else
                        if c < 424 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 437 then
                    if c < 430 then
                      if c < 428 then
                        if c < 426 then return "Lu" else return "Ll" end
                      else
                        if c < 429 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 433 then
                        if c < 432 then return "Lu" else return "Ll" end
                      else
                        if c < 436 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 443 then
                      if c < 439 then
                        if c < 438 then return "Lu" else return "Ll" end
                      else
                        if c < 441 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 445 then
                        if c < 444 then return "Lo" else return "Lu" end
                      else
                        if c < 448 then return "Ll" else return "Lo" end
                      end
                    end
                  end
                end
              else
                if c < 468 then
                  if c < 460 then
                    if c < 456 then
                      if c < 454 then
                        if c < 453 then return "Lu" else return "Lt" end
                      else
                        if c < 455 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 458 then
                        if c < 457 then return "Lt" else return "Ll" end
                      else
                        if c < 459 then return "Lu" else return "Lt" end
                      end
                    end
                  else
                    if c < 464 then
                      if c < 462 then
                        if c < 461 then return "Ll" else return "Lu" end
                      else
                        if c < 463 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 466 then
                        if c < 465 then return "Ll" else return "Lu" end
                      else
                        if c < 467 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                else
                  if c < 476 then
                    if c < 472 then
                      if c < 470 then
                        if c < 469 then return "Ll" else return "Lu" end
                      else
                        if c < 471 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 474 then
                        if c < 473 then return "Ll" else return "Lu" end
                      else
                        if c < 475 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 481 then
                      if c < 479 then
                        if c < 478 then return "Ll" else return "Lu" end
                      else
                        if c < 480 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 483 then
                        if c < 482 then return "Ll" else return "Lu" end
                      else
                        if c < 484 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                end
              end
            end
          end
        else
          if c < 913 then
            if c < 552 then
              if c < 520 then
                if c < 502 then
                  if c < 493 then
                    if c < 489 then
                      if c < 487 then
                        if c < 486 then return "Ll" else return "Lu" end
                      else
                        if c < 488 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 491 then
                        if c < 490 then return "Ll" else return "Lu" end
                      else
                        if c < 492 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 498 then
                      if c < 495 then
                        if c < 494 then return "Ll" else return "Lu" end
                      else
                        if c < 497 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 500 then
                        if c < 499 then return "Lt" else return "Ll" end
                      else
                        if c < 501 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 512 then
                    if c < 508 then
                      if c < 506 then
                        if c < 505 then return "Lu" else return "Ll" end
                      else
                        if c < 507 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 510 then
                        if c < 509 then return "Lu" else return "Ll" end
                      else
                        if c < 511 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 516 then
                      if c < 514 then
                        if c < 513 then return "Lu" else return "Ll" end
                      else
                        if c < 515 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 518 then
                        if c < 517 then return "Lu" else return "Ll" end
                      else
                        if c < 519 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              else
                if c < 536 then
                  if c < 528 then
                    if c < 524 then
                      if c < 522 then
                        if c < 521 then return "Lu" else return "Ll" end
                      else
                        if c < 523 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 526 then
                        if c < 525 then return "Lu" else return "Ll" end
                      else
                        if c < 527 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 532 then
                      if c < 530 then
                        if c < 529 then return "Lu" else return "Ll" end
                      else
                        if c < 531 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 534 then
                        if c < 533 then return "Lu" else return "Ll" end
                      else
                        if c < 535 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 544 then
                    if c < 540 then
                      if c < 538 then
                        if c < 537 then return "Lu" else return "Ll" end
                      else
                        if c < 539 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 542 then
                        if c < 541 then return "Lu" else return "Ll" end
                      else
                        if c < 543 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 548 then
                      if c < 546 then
                        if c < 545 then return "Lu" else return "Ll" end
                      else
                        if c < 547 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 550 then
                        if c < 549 then return "Lu" else return "Ll" end
                      else
                        if c < 551 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              end
            else
              if c < 710 then
                if c < 577 then
                  if c < 560 then
                    if c < 556 then
                      if c < 554 then
                        if c < 553 then return "Lu" else return "Ll" end
                      else
                        if c < 555 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 558 then
                        if c < 557 then return "Lu" else return "Ll" end
                      else
                        if c < 559 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 570 then
                      if c < 562 then
                        if c < 561 then return "Lu" else return "Ll" end
                      else
                        if c < 563 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 573 then
                        if c < 572 then return "Lu" else return "Ll" end
                      else
                        if c < 575 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 588 then
                    if c < 584 then
                      if c < 579 then
                        if c < 578 then return "Lu" else return "Ll" end
                      else
                        if c < 583 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 586 then
                        if c < 585 then return "Lu" else return "Ll" end
                      else
                        if c < 587 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 660 then
                      if c < 590 then
                        if c < 589 then return "Lu" else return "Ll" end
                      else
                        if c < 591 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 688 then
                        if c < 661 then return "Lo" else return "Ll" end
                      else
                        if c < 706 then return "Lm" else return "Sk" end
                      end
                    end
                  end
                end
              else
                if c < 887 then
                  if c < 768 then
                    if c < 748 then
                      if c < 736 then
                        if c < 722 then return "Lm" else return "Sk" end
                      else
                        if c < 741 then return "Lm" else return "Sk" end
                      end
                    else
                      if c < 750 then
                        if c < 749 then return "Lm" else return "Sk" end
                      else
                        if c < 751 then return "Lm" else return "Sk" end
                      end
                    end
                  else
                    if c < 883 then
                      if c < 881 then
                        if c < 880 then return "Mn" else return "Lu" end
                      else
                        if c < 882 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 885 then
                        if c < 884 then return "Ll" else return "Lm" end
                      else
                        if c < 886 then return "Sk" else return "Lu" end
                      end
                    end
                  end
                else
                  if c < 902 then
                    if c < 894 then
                      if c < 890 then
                        if c < 888 then return "Ll" else return "Cn" end
                      else
                        if c < 891 then return "Lm" else return "Ll" end
                      end
                    else
                      if c < 896 then
                        if c < 895 then return "Po" else return "Lu" end
                      else
                        if c < 900 then return "Cn" else return "Sk" end
                      end
                    end
                  else
                    if c < 908 then
                      if c < 904 then
                        if c < 903 then return "Lu" else return "Po" end
                      else
                        if c < 907 then return "Lu" else return "Cn" end
                      end
                    else
                      if c < 910 then
                        if c < 909 then return "Lu" else return "Cn" end
                      else
                        if c < 912 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              end
            end
          else
            if c < 1143 then
              if c < 1012 then
                if c < 992 then
                  if c < 984 then
                    if c < 975 then
                      if c < 931 then
                        if c < 930 then return "Lu" else return "Cn" end
                      else
                        if c < 940 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 978 then
                        if c < 976 then return "Lu" else return "Ll" end
                      else
                        if c < 981 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 988 then
                      if c < 986 then
                        if c < 985 then return "Lu" else return "Ll" end
                      else
                        if c < 987 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 990 then
                        if c < 989 then return "Lu" else return "Ll" end
                      else
                        if c < 991 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 1000 then
                    if c < 996 then
                      if c < 994 then
                        if c < 993 then return "Lu" else return "Ll" end
                      else
                        if c < 995 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 998 then
                        if c < 997 then return "Lu" else return "Ll" end
                      else
                        if c < 999 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 1004 then
                      if c < 1002 then
                        if c < 1001 then return "Lu" else return "Ll" end
                      else
                        if c < 1003 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1006 then
                        if c < 1005 then return "Lu" else return "Ll" end
                      else
                        if c < 1007 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              else
                if c < 1127 then
                  if c < 1072 then
                    if c < 1016 then
                      if c < 1014 then
                        if c < 1013 then return "Lu" else return "Ll" end
                      else
                        if c < 1015 then return "Sm" else return "Lu" end
                      end
                    else
                      if c < 1019 then
                        if c < 1017 then return "Ll" else return "Lu" end
                      else
                        if c < 1021 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 1123 then
                      if c < 1121 then
                        if c < 1120 then return "Ll" else return "Lu" end
                      else
                        if c < 1122 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 1125 then
                        if c < 1124 then return "Ll" else return "Lu" end
                      else
                        if c < 1126 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                else
                  if c < 1135 then
                    if c < 1131 then
                      if c < 1129 then
                        if c < 1128 then return "Ll" else return "Lu" end
                      else
                        if c < 1130 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 1133 then
                        if c < 1132 then return "Ll" else return "Lu" end
                      else
                        if c < 1134 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 1139 then
                      if c < 1137 then
                        if c < 1136 then return "Ll" else return "Lu" end
                      else
                        if c < 1138 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 1141 then
                        if c < 1140 then return "Ll" else return "Lu" end
                      else
                        if c < 1142 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                end
              end
            else
              if c < 1180 then
                if c < 1164 then
                  if c < 1151 then
                    if c < 1147 then
                      if c < 1145 then
                        if c < 1144 then return "Ll" else return "Lu" end
                      else
                        if c < 1146 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 1149 then
                        if c < 1148 then return "Ll" else return "Lu" end
                      else
                        if c < 1150 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 1155 then
                      if c < 1153 then
                        if c < 1152 then return "Ll" else return "Lu" end
                      else
                        if c < 1154 then return "Ll" else return "So" end
                      end
                    else
                      if c < 1162 then
                        if c < 1160 then return "Mn" else return "Me" end
                      else
                        if c < 1163 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 1172 then
                    if c < 1168 then
                      if c < 1166 then
                        if c < 1165 then return "Lu" else return "Ll" end
                      else
                        if c < 1167 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1170 then
                        if c < 1169 then return "Lu" else return "Ll" end
                      else
                        if c < 1171 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 1176 then
                      if c < 1174 then
                        if c < 1173 then return "Lu" else return "Ll" end
                      else
                        if c < 1175 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1178 then
                        if c < 1177 then return "Lu" else return "Ll" end
                      else
                        if c < 1179 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              else
                if c < 1196 then
                  if c < 1188 then
                    if c < 1184 then
                      if c < 1182 then
                        if c < 1181 then return "Lu" else return "Ll" end
                      else
                        if c < 1183 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1186 then
                        if c < 1185 then return "Lu" else return "Ll" end
                      else
                        if c < 1187 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 1192 then
                      if c < 1190 then
                        if c < 1189 then return "Lu" else return "Ll" end
                      else
                        if c < 1191 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1194 then
                        if c < 1193 then return "Lu" else return "Ll" end
                      else
                        if c < 1195 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 1204 then
                    if c < 1200 then
                      if c < 1198 then
                        if c < 1197 then return "Lu" else return "Ll" end
                      else
                        if c < 1199 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1202 then
                        if c < 1201 then return "Lu" else return "Ll" end
                      else
                        if c < 1203 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 1208 then
                      if c < 1206 then
                        if c < 1205 then return "Lu" else return "Ll" end
                      else
                        if c < 1207 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1210 then
                        if c < 1209 then return "Lu" else return "Ll" end
                      else
                        if c < 1211 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              end
            end
          end
        end
      else
        if c < 2486 then
          if c < 1425 then
            if c < 1278 then
              if c < 1246 then
                if c < 1229 then
                  if c < 1221 then
                    if c < 1216 then
                      if c < 1214 then
                        if c < 1213 then return "Lu" else return "Ll" end
                      else
                        if c < 1215 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1219 then
                        if c < 1218 then return "Lu" else return "Ll" end
                      else
                        if c < 1220 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 1225 then
                      if c < 1223 then
                        if c < 1222 then return "Lu" else return "Ll" end
                      else
                        if c < 1224 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1227 then
                        if c < 1226 then return "Lu" else return "Ll" end
                      else
                        if c < 1228 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 1238 then
                    if c < 1234 then
                      if c < 1232 then
                        if c < 1230 then return "Lu" else return "Ll" end
                      else
                        if c < 1233 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1236 then
                        if c < 1235 then return "Lu" else return "Ll" end
                      else
                        if c < 1237 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 1242 then
                      if c < 1240 then
                        if c < 1239 then return "Lu" else return "Ll" end
                      else
                        if c < 1241 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1244 then
                        if c < 1243 then return "Lu" else return "Ll" end
                      else
                        if c < 1245 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              else
                if c < 1262 then
                  if c < 1254 then
                    if c < 1250 then
                      if c < 1248 then
                        if c < 1247 then return "Lu" else return "Ll" end
                      else
                        if c < 1249 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1252 then
                        if c < 1251 then return "Lu" else return "Ll" end
                      else
                        if c < 1253 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 1258 then
                      if c < 1256 then
                        if c < 1255 then return "Lu" else return "Ll" end
                      else
                        if c < 1257 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1260 then
                        if c < 1259 then return "Lu" else return "Ll" end
                      else
                        if c < 1261 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 1270 then
                    if c < 1266 then
                      if c < 1264 then
                        if c < 1263 then return "Lu" else return "Ll" end
                      else
                        if c < 1265 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1268 then
                        if c < 1267 then return "Lu" else return "Ll" end
                      else
                        if c < 1269 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 1274 then
                      if c < 1272 then
                        if c < 1271 then return "Lu" else return "Ll" end
                      else
                        if c < 1273 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1276 then
                        if c < 1275 then return "Lu" else return "Ll" end
                      else
                        if c < 1277 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              end
            else
              if c < 1310 then
                if c < 1294 then
                  if c < 1286 then
                    if c < 1282 then
                      if c < 1280 then
                        if c < 1279 then return "Lu" else return "Ll" end
                      else
                        if c < 1281 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1284 then
                        if c < 1283 then return "Lu" else return "Ll" end
                      else
                        if c < 1285 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 1290 then
                      if c < 1288 then
                        if c < 1287 then return "Lu" else return "Ll" end
                      else
                        if c < 1289 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1292 then
                        if c < 1291 then return "Lu" else return "Ll" end
                      else
                        if c < 1293 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 1302 then
                    if c < 1298 then
                      if c < 1296 then
                        if c < 1295 then return "Lu" else return "Ll" end
                      else
                        if c < 1297 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1300 then
                        if c < 1299 then return "Lu" else return "Ll" end
                      else
                        if c < 1301 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 1306 then
                      if c < 1304 then
                        if c < 1303 then return "Lu" else return "Ll" end
                      else
                        if c < 1305 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1308 then
                        if c < 1307 then return "Lu" else return "Ll" end
                      else
                        if c < 1309 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              else
                if c < 1326 then
                  if c < 1318 then
                    if c < 1314 then
                      if c < 1312 then
                        if c < 1311 then return "Lu" else return "Ll" end
                      else
                        if c < 1313 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1316 then
                        if c < 1315 then return "Lu" else return "Ll" end
                      else
                        if c < 1317 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 1322 then
                      if c < 1320 then
                        if c < 1319 then return "Lu" else return "Ll" end
                      else
                        if c < 1321 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 1324 then
                        if c < 1323 then return "Lu" else return "Ll" end
                      else
                        if c < 1325 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 1377 then
                    if c < 1367 then
                      if c < 1328 then
                        if c < 1327 then return "Lu" else return "Ll" end
                      else
                        if c < 1329 then return "Cn" else return "Lu" end
                      end
                    else
                      if c < 1370 then
                        if c < 1369 then return "Cn" else return "Lm" end
                      else
                        if c < 1376 then return "Po" else return "Cn" end
                      end
                    end
                  else
                    if c < 1419 then
                      if c < 1417 then
                        if c < 1416 then return "Ll" else return "Cn" end
                      else
                        if c < 1418 then return "Po" else return "Pd" end
                      end
                    else
                      if c < 1423 then
                        if c < 1421 then return "Cn" else return "So" end
                      else
                        if c < 1424 then return "Sc" else return "Cn" end
                      end
                    end
                  end
                end
              end
            end
          else
            if c < 2027 then
              if c < 1646 then
                if c < 1542 then
                  if c < 1479 then
                    if c < 1473 then
                      if c < 1471 then
                        if c < 1470 then return "Mn" else return "Pd" end
                      else
                        if c < 1472 then return "Mn" else return "Po" end
                      end
                    else
                      if c < 1476 then
                        if c < 1475 then return "Mn" else return "Po" end
                      else
                        if c < 1478 then return "Mn" else return "Po" end
                      end
                    end
                  else
                    if c < 1520 then
                      if c < 1488 then
                        if c < 1480 then return "Mn" else return "Cn" end
                      else
                        if c < 1515 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 1525 then
                        if c < 1523 then return "Lo" else return "Po" end
                      else
                        if c < 1536 then return "Cn" else return "Cf" end
                      end
                    end
                  end
                else
                  if c < 1565 then
                    if c < 1550 then
                      if c < 1547 then
                        if c < 1545 then return "Sm" else return "Po" end
                      else
                        if c < 1548 then return "Sc" else return "Po" end
                      end
                    else
                      if c < 1563 then
                        if c < 1552 then return "So" else return "Mn" end
                      else
                        if c < 1564 then return "Po" else return "Cf" end
                      end
                    end
                  else
                    if c < 1601 then
                      if c < 1568 then
                        if c < 1566 then return "Cn" else return "Po" end
                      else
                        if c < 1600 then return "Lo" else return "Lm" end
                      end
                    else
                      if c < 1632 then
                        if c < 1611 then return "Lo" else return "Mn" end
                      else
                        if c < 1642 then return "Nd" else return "Po" end
                      end
                    end
                  end
                end
              else
                if c < 1789 then
                  if c < 1759 then
                    if c < 1749 then
                      if c < 1649 then
                        if c < 1648 then return "Lo" else return "Mn" end
                      else
                        if c < 1748 then return "Lo" else return "Po" end
                      end
                    else
                      if c < 1757 then
                        if c < 1750 then return "Lo" else return "Mn" end
                      else
                        if c < 1758 then return "Cf" else return "So" end
                      end
                    end
                  else
                    if c < 1770 then
                      if c < 1767 then
                        if c < 1765 then return "Mn" else return "Lm" end
                      else
                        if c < 1769 then return "Mn" else return "So" end
                      end
                    else
                      if c < 1776 then
                        if c < 1774 then return "Mn" else return "Lo" end
                      else
                        if c < 1786 then return "Nd" else return "Lo" end
                      end
                    end
                  end
                else
                  if c < 1840 then
                    if c < 1807 then
                      if c < 1792 then
                        if c < 1791 then return "So" else return "Lo" end
                      else
                        if c < 1806 then return "Po" else return "Cn" end
                      end
                    else
                      if c < 1809 then
                        if c < 1808 then return "Cf" else return "Lo" end
                      else
                        if c < 1810 then return "Mn" else return "Lo" end
                      end
                    end
                  else
                    if c < 1969 then
                      if c < 1869 then
                        if c < 1867 then return "Mn" else return "Cn" end
                      else
                        if c < 1958 then return "Lo" else return "Mn" end
                      end
                    else
                      if c < 1984 then
                        if c < 1970 then return "Lo" else return "Cn" end
                      else
                        if c < 1994 then return "Nd" else return "Lo" end
                      end
                    end
                  end
                end
              end
            else
              if c < 2308 then
                if c < 2111 then
                  if c < 2074 then
                    if c < 2042 then
                      if c < 2038 then
                        if c < 2036 then return "Mn" else return "Lm" end
                      else
                        if c < 2039 then return "So" else return "Po" end
                      end
                    else
                      if c < 2048 then
                        if c < 2043 then return "Lm" else return "Cn" end
                      else
                        if c < 2070 then return "Lo" else return "Mn" end
                      end
                    end
                  else
                    if c < 2088 then
                      if c < 2084 then
                        if c < 2075 then return "Lm" else return "Mn" end
                      else
                        if c < 2085 then return "Lm" else return "Mn" end
                      end
                    else
                      if c < 2094 then
                        if c < 2089 then return "Lm" else return "Mn" end
                      else
                        if c < 2096 then return "Cn" else return "Po" end
                      end
                    end
                  end
                else
                  if c < 2208 then
                    if c < 2142 then
                      if c < 2137 then
                        if c < 2112 then return "Cn" else return "Lo" end
                      else
                        if c < 2140 then return "Mn" else return "Cn" end
                      end
                    else
                      if c < 2144 then
                        if c < 2143 then return "Po" else return "Cn" end
                      else
                        if c < 2155 then return "Lo" else return "Cn" end
                      end
                    end
                  else
                    if c < 2260 then
                      if c < 2230 then
                        if c < 2229 then return "Lo" else return "Cn" end
                      else
                        if c < 2238 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 2275 then
                        if c < 2274 then return "Mn" else return "Cf" end
                      else
                        if c < 2307 then return "Mn" else return "Mc" end
                      end
                    end
                  end
                end
              else
                if c < 2416 then
                  if c < 2381 then
                    if c < 2365 then
                      if c < 2363 then
                        if c < 2362 then return "Lo" else return "Mn" end
                      else
                        if c < 2364 then return "Mc" else return "Mn" end
                      end
                    else
                      if c < 2369 then
                        if c < 2366 then return "Lo" else return "Mc" end
                      else
                        if c < 2377 then return "Mn" else return "Mc" end
                      end
                    end
                  else
                    if c < 2392 then
                      if c < 2384 then
                        if c < 2382 then return "Mn" else return "Mc" end
                      else
                        if c < 2385 then return "Lo" else return "Mn" end
                      end
                    else
                      if c < 2404 then
                        if c < 2402 then return "Lo" else return "Mn" end
                      else
                        if c < 2406 then return "Po" else return "Nd" end
                      end
                    end
                  end
                else
                  if c < 2447 then
                    if c < 2434 then
                      if c < 2418 then
                        if c < 2417 then return "Po" else return "Lm" end
                      else
                        if c < 2433 then return "Lo" else return "Mn" end
                      end
                    else
                      if c < 2437 then
                        if c < 2436 then return "Mc" else return "Cn" end
                      else
                        if c < 2445 then return "Lo" else return "Cn" end
                      end
                    end
                  else
                    if c < 2474 then
                      if c < 2451 then
                        if c < 2449 then return "Lo" else return "Cn" end
                      else
                        if c < 2473 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 2482 then
                        if c < 2481 then return "Lo" else return "Cn" end
                      else
                        if c < 2483 then return "Lo" else return "Cn" end
                      end
                    end
                  end
                end
              end
            end
          end
        else
          if c < 2891 then
            if c < 2677 then
              if c < 2565 then
                if c < 2526 then
                  if c < 2505 then
                    if c < 2494 then
                      if c < 2492 then
                        if c < 2490 then return "Lo" else return "Cn" end
                      else
                        if c < 2493 then return "Mn" else return "Lo" end
                      end
                    else
                      if c < 2501 then
                        if c < 2497 then return "Mc" else return "Mn" end
                      else
                        if c < 2503 then return "Cn" else return "Mc" end
                      end
                    end
                  else
                    if c < 2511 then
                      if c < 2509 then
                        if c < 2507 then return "Cn" else return "Mc" end
                      else
                        if c < 2510 then return "Mn" else return "Lo" end
                      end
                    else
                      if c < 2520 then
                        if c < 2519 then return "Cn" else return "Mc" end
                      else
                        if c < 2524 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                else
                  if c < 2554 then
                    if c < 2534 then
                      if c < 2530 then
                        if c < 2527 then return "Cn" else return "Lo" end
                      else
                        if c < 2532 then return "Mn" else return "Cn" end
                      end
                    else
                      if c < 2546 then
                        if c < 2544 then return "Nd" else return "Lo" end
                      else
                        if c < 2548 then return "Sc" else return "No" end
                      end
                    end
                  else
                    if c < 2558 then
                      if c < 2556 then
                        if c < 2555 then return "So" else return "Sc" end
                      else
                        if c < 2557 then return "Lo" else return "Po" end
                      end
                    else
                      if c < 2563 then
                        if c < 2561 then return "Cn" else return "Mn" end
                      else
                        if c < 2564 then return "Mc" else return "Cn" end
                      end
                    end
                  end
                end
              else
                if c < 2622 then
                  if c < 2610 then
                    if c < 2579 then
                      if c < 2575 then
                        if c < 2571 then return "Lo" else return "Cn" end
                      else
                        if c < 2577 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 2602 then
                        if c < 2601 then return "Lo" else return "Cn" end
                      else
                        if c < 2609 then return "Lo" else return "Cn" end
                      end
                    end
                  else
                    if c < 2616 then
                      if c < 2613 then
                        if c < 2612 then return "Lo" else return "Cn" end
                      else
                        if c < 2615 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 2620 then
                        if c < 2618 then return "Lo" else return "Cn" end
                      else
                        if c < 2621 then return "Mn" else return "Cn" end
                      end
                    end
                  end
                else
                  if c < 2642 then
                    if c < 2633 then
                      if c < 2627 then
                        if c < 2625 then return "Mc" else return "Mn" end
                      else
                        if c < 2631 then return "Cn" else return "Mn" end
                      end
                    else
                      if c < 2638 then
                        if c < 2635 then return "Cn" else return "Mn" end
                      else
                        if c < 2641 then return "Cn" else return "Mn" end
                      end
                    end
                  else
                    if c < 2655 then
                      if c < 2653 then
                        if c < 2649 then return "Cn" else return "Lo" end
                      else
                        if c < 2654 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 2672 then
                        if c < 2662 then return "Cn" else return "Nd" end
                      else
                        if c < 2674 then return "Mn" else return "Lo" end
                      end
                    end
                  end
                end
              end
            else
              if c < 2788 then
                if c < 2746 then
                  if c < 2706 then
                    if c < 2692 then
                      if c < 2689 then
                        if c < 2678 then return "Mn" else return "Cn" end
                      else
                        if c < 2691 then return "Mn" else return "Mc" end
                      end
                    else
                      if c < 2702 then
                        if c < 2693 then return "Cn" else return "Lo" end
                      else
                        if c < 2703 then return "Cn" else return "Lo" end
                      end
                    end
                  else
                    if c < 2737 then
                      if c < 2729 then
                        if c < 2707 then return "Cn" else return "Lo" end
                      else
                        if c < 2730 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 2740 then
                        if c < 2738 then return "Cn" else return "Lo" end
                      else
                        if c < 2741 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                else
                  if c < 2762 then
                    if c < 2753 then
                      if c < 2749 then
                        if c < 2748 then return "Cn" else return "Mn" end
                      else
                        if c < 2750 then return "Lo" else return "Mc" end
                      end
                    else
                      if c < 2759 then
                        if c < 2758 then return "Mn" else return "Cn" end
                      else
                        if c < 2761 then return "Mn" else return "Mc" end
                      end
                    end
                  else
                    if c < 2768 then
                      if c < 2765 then
                        if c < 2763 then return "Cn" else return "Mc" end
                      else
                        if c < 2766 then return "Mn" else return "Cn" end
                      end
                    else
                      if c < 2784 then
                        if c < 2769 then return "Lo" else return "Cn" end
                      else
                        if c < 2786 then return "Lo" else return "Mn" end
                      end
                    end
                  end
                end
              else
                if c < 2857 then
                  if c < 2817 then
                    if c < 2802 then
                      if c < 2800 then
                        if c < 2790 then return "Cn" else return "Nd" end
                      else
                        if c < 2801 then return "Po" else return "Sc" end
                      end
                    else
                      if c < 2810 then
                        if c < 2809 then return "Cn" else return "Lo" end
                      else
                        if c < 2816 then return "Mn" else return "Cn" end
                      end
                    end
                  else
                    if c < 2829 then
                      if c < 2820 then
                        if c < 2818 then return "Mn" else return "Mc" end
                      else
                        if c < 2821 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 2833 then
                        if c < 2831 then return "Cn" else return "Lo" end
                      else
                        if c < 2835 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                else
                  if c < 2877 then
                    if c < 2868 then
                      if c < 2865 then
                        if c < 2858 then return "Cn" else return "Lo" end
                      else
                        if c < 2866 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 2874 then
                        if c < 2869 then return "Cn" else return "Lo" end
                      else
                        if c < 2876 then return "Cn" else return "Mn" end
                      end
                    end
                  else
                    if c < 2881 then
                      if c < 2879 then
                        if c < 2878 then return "Lo" else return "Mc" end
                      else
                        if c < 2880 then return "Mn" else return "Mc" end
                      end
                    else
                      if c < 2887 then
                        if c < 2885 then return "Mn" else return "Cn" end
                      else
                        if c < 2889 then return "Mc" else return "Cn" end
                      end
                    end
                  end
                end
              end
            end
          else
            if c < 3113 then
              if c < 2981 then
                if c < 2946 then
                  if c < 2911 then
                    if c < 2903 then
                      if c < 2894 then
                        if c < 2893 then return "Mc" else return "Mn" end
                      else
                        if c < 2902 then return "Cn" else return "Mn" end
                      end
                    else
                      if c < 2908 then
                        if c < 2904 then return "Mc" else return "Cn" end
                      else
                        if c < 2910 then return "Lo" else return "Cn" end
                      end
                    end
                  else
                    if c < 2928 then
                      if c < 2916 then
                        if c < 2914 then return "Lo" else return "Mn" end
                      else
                        if c < 2918 then return "Cn" else return "Nd" end
                      end
                    else
                      if c < 2930 then
                        if c < 2929 then return "So" else return "Lo" end
                      else
                        if c < 2936 then return "No" else return "Cn" end
                      end
                    end
                  end
                else
                  if c < 2966 then
                    if c < 2955 then
                      if c < 2948 then
                        if c < 2947 then return "Mn" else return "Lo" end
                      else
                        if c < 2949 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 2961 then
                        if c < 2958 then return "Cn" else return "Lo" end
                      else
                        if c < 2962 then return "Cn" else return "Lo" end
                      end
                    end
                  else
                    if c < 2973 then
                      if c < 2971 then
                        if c < 2969 then return "Cn" else return "Lo" end
                      else
                        if c < 2972 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 2976 then
                        if c < 2974 then return "Cn" else return "Lo" end
                      else
                        if c < 2979 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                end
              else
                if c < 3031 then
                  if c < 3011 then
                    if c < 3002 then
                      if c < 2987 then
                        if c < 2984 then return "Cn" else return "Lo" end
                      else
                        if c < 2990 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 3008 then
                        if c < 3006 then return "Cn" else return "Mc" end
                      else
                        if c < 3009 then return "Mn" else return "Mc" end
                      end
                    end
                  else
                    if c < 3021 then
                      if c < 3017 then
                        if c < 3014 then return "Cn" else return "Mc" end
                      else
                        if c < 3018 then return "Cn" else return "Mc" end
                      end
                    else
                      if c < 3024 then
                        if c < 3022 then return "Mn" else return "Cn" end
                      else
                        if c < 3025 then return "Lo" else return "Cn" end
                      end
                    end
                  end
                else
                  if c < 3072 then
                    if c < 3059 then
                      if c < 3046 then
                        if c < 3032 then return "Mc" else return "Cn" end
                      else
                        if c < 3056 then return "Nd" else return "No" end
                      end
                    else
                      if c < 3066 then
                        if c < 3065 then return "So" else return "Sc" end
                      else
                        if c < 3067 then return "So" else return "Cn" end
                      end
                    end
                  else
                    if c < 3085 then
                      if c < 3076 then
                        if c < 3073 then return "Mn" else return "Mc" end
                      else
                        if c < 3077 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 3089 then
                        if c < 3086 then return "Cn" else return "Lo" end
                      else
                        if c < 3090 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                end
              end
            else
              if c < 3242 then
                if c < 3170 then
                  if c < 3145 then
                    if c < 3134 then
                      if c < 3130 then
                        if c < 3114 then return "Cn" else return "Lo" end
                      else
                        if c < 3133 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 3141 then
                        if c < 3137 then return "Mn" else return "Mc" end
                      else
                        if c < 3142 then return "Cn" else return "Mn" end
                      end
                    end
                  else
                    if c < 3159 then
                      if c < 3150 then
                        if c < 3146 then return "Cn" else return "Mn" end
                      else
                        if c < 3157 then return "Cn" else return "Mn" end
                      end
                    else
                      if c < 3163 then
                        if c < 3160 then return "Cn" else return "Lo" end
                      else
                        if c < 3168 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                else
                  if c < 3202 then
                    if c < 3192 then
                      if c < 3174 then
                        if c < 3172 then return "Mn" else return "Cn" end
                      else
                        if c < 3184 then return "Nd" else return "Cn" end
                      end
                    else
                      if c < 3200 then
                        if c < 3199 then return "No" else return "So" end
                      else
                        if c < 3201 then return "Lo" else return "Mn" end
                      end
                    end
                  else
                    if c < 3214 then
                      if c < 3205 then
                        if c < 3204 then return "Mc" else return "Cn" end
                      else
                        if c < 3213 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 3218 then
                        if c < 3217 then return "Lo" else return "Cn" end
                      else
                        if c < 3241 then return "Lo" else return "Cn" end
                      end
                    end
                  end
                end
              else
                if c < 3285 then
                  if c < 3264 then
                    if c < 3260 then
                      if c < 3253 then
                        if c < 3252 then return "Lo" else return "Cn" end
                      else
                        if c < 3258 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 3262 then
                        if c < 3261 then return "Mn" else return "Lo" end
                      else
                        if c < 3263 then return "Mc" else return "Mn" end
                      end
                    end
                  else
                    if c < 3273 then
                      if c < 3270 then
                        if c < 3269 then return "Mc" else return "Cn" end
                      else
                        if c < 3271 then return "Mn" else return "Mc" end
                      end
                    else
                      if c < 3276 then
                        if c < 3274 then return "Cn" else return "Mc" end
                      else
                        if c < 3278 then return "Mn" else return "Cn" end
                      end
                    end
                  end
                else
                  if c < 3312 then
                    if c < 3296 then
                      if c < 3294 then
                        if c < 3287 then return "Mc" else return "Cn" end
                      else
                        if c < 3295 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 3300 then
                        if c < 3298 then return "Lo" else return "Mn" end
                      else
                        if c < 3302 then return "Cn" else return "Nd" end
                      end
                    end
                  else
                    if c < 3330 then
                      if c < 3315 then
                        if c < 3313 then return "Cn" else return "Lo" end
                      else
                        if c < 3328 then return "Cn" else return "Mn" end
                      end
                    else
                      if c < 3333 then
                        if c < 3332 then return "Mc" else return "Cn" end
                      else
                        if c < 3341 then return "Lo" else return "Cn" end
                      end
                    end
                  end
                end
              end
            end
          end
        end
      end
    else
      if c < 7743 then
        if c < 5938 then
          if c < 3913 then
            if c < 3676 then
              if c < 3507 then
                if c < 3415 then
                  if c < 3398 then
                    if c < 3389 then
                      if c < 3346 then
                        if c < 3345 then return "Lo" else return "Cn" end
                      else
                        if c < 3387 then return "Lo" else return "Mn" end
                      end
                    else
                      if c < 3393 then
                        if c < 3390 then return "Lo" else return "Mc" end
                      else
                        if c < 3397 then return "Mn" else return "Cn" end
                      end
                    end
                  else
                    if c < 3406 then
                      if c < 3402 then
                        if c < 3401 then return "Mc" else return "Cn" end
                      else
                        if c < 3405 then return "Mc" else return "Mn" end
                      end
                    else
                      if c < 3408 then
                        if c < 3407 then return "Lo" else return "So" end
                      else
                        if c < 3412 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                else
                  if c < 3450 then
                    if c < 3428 then
                      if c < 3423 then
                        if c < 3416 then return "Mc" else return "No" end
                      else
                        if c < 3426 then return "Lo" else return "Mn" end
                      end
                    else
                      if c < 3440 then
                        if c < 3430 then return "Cn" else return "Nd" end
                      else
                        if c < 3449 then return "No" else return "So" end
                      end
                    end
                  else
                    if c < 3461 then
                      if c < 3458 then
                        if c < 3456 then return "Lo" else return "Cn" end
                      else
                        if c < 3460 then return "Mc" else return "Cn" end
                      end
                    else
                      if c < 3482 then
                        if c < 3479 then return "Lo" else return "Cn" end
                      else
                        if c < 3506 then return "Lo" else return "Cn" end
                      end
                    end
                  end
                end
              else
                if c < 3568 then
                  if c < 3535 then
                    if c < 3520 then
                      if c < 3517 then
                        if c < 3516 then return "Lo" else return "Cn" end
                      else
                        if c < 3518 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 3530 then
                        if c < 3527 then return "Lo" else return "Cn" end
                      else
                        if c < 3531 then return "Mn" else return "Cn" end
                      end
                    end
                  else
                    if c < 3543 then
                      if c < 3541 then
                        if c < 3538 then return "Mc" else return "Mn" end
                      else
                        if c < 3542 then return "Cn" else return "Mn" end
                      end
                    else
                      if c < 3552 then
                        if c < 3544 then return "Cn" else return "Mc" end
                      else
                        if c < 3558 then return "Cn" else return "Nd" end
                      end
                    end
                  end
                else
                  if c < 3643 then
                    if c < 3585 then
                      if c < 3572 then
                        if c < 3570 then return "Cn" else return "Mc" end
                      else
                        if c < 3573 then return "Po" else return "Cn" end
                      end
                    else
                      if c < 3634 then
                        if c < 3633 then return "Lo" else return "Mn" end
                      else
                        if c < 3636 then return "Lo" else return "Mn" end
                      end
                    end
                  else
                    if c < 3655 then
                      if c < 3648 then
                        if c < 3647 then return "Cn" else return "Sc" end
                      else
                        if c < 3654 then return "Lo" else return "Lm" end
                      end
                    else
                      if c < 3664 then
                        if c < 3663 then return "Mn" else return "Po" end
                      else
                        if c < 3674 then return "Nd" else return "Po" end
                      end
                    end
                  end
                end
              end
            else
              if c < 3781 then
                if c < 3748 then
                  if c < 3723 then
                    if c < 3717 then
                      if c < 3715 then
                        if c < 3713 then return "Cn" else return "Lo" end
                      else
                        if c < 3716 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 3721 then
                        if c < 3719 then return "Cn" else return "Lo" end
                      else
                        if c < 3722 then return "Cn" else return "Lo" end
                      end
                    end
                  else
                    if c < 3736 then
                      if c < 3726 then
                        if c < 3725 then return "Cn" else return "Lo" end
                      else
                        if c < 3732 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 3744 then
                        if c < 3737 then return "Cn" else return "Lo" end
                      else
                        if c < 3745 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                else
                  if c < 3761 then
                    if c < 3752 then
                      if c < 3750 then
                        if c < 3749 then return "Cn" else return "Lo" end
                      else
                        if c < 3751 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 3756 then
                        if c < 3754 then return "Cn" else return "Lo" end
                      else
                        if c < 3757 then return "Cn" else return "Lo" end
                      end
                    end
                  else
                    if c < 3771 then
                      if c < 3764 then
                        if c < 3762 then return "Mn" else return "Lo" end
                      else
                        if c < 3770 then return "Mn" else return "Cn" end
                      end
                    else
                      if c < 3774 then
                        if c < 3773 then return "Mn" else return "Lo" end
                      else
                        if c < 3776 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                end
              else
                if c < 3866 then
                  if c < 3808 then
                    if c < 3790 then
                      if c < 3783 then
                        if c < 3782 then return "Cn" else return "Lm" end
                      else
                        if c < 3784 then return "Cn" else return "Mn" end
                      end
                    else
                      if c < 3802 then
                        if c < 3792 then return "Cn" else return "Nd" end
                      else
                        if c < 3804 then return "Cn" else return "Lo" end
                      end
                    end
                  else
                    if c < 3859 then
                      if c < 3841 then
                        if c < 3840 then return "Cn" else return "Lo" end
                      else
                        if c < 3844 then return "So" else return "Po" end
                      end
                    else
                      if c < 3861 then
                        if c < 3860 then return "So" else return "Po" end
                      else
                        if c < 3864 then return "So" else return "Mn" end
                      end
                    end
                  end
                else
                  if c < 3897 then
                    if c < 3893 then
                      if c < 3882 then
                        if c < 3872 then return "So" else return "Nd" end
                      else
                        if c < 3892 then return "No" else return "So" end
                      end
                    else
                      if c < 3895 then
                        if c < 3894 then return "Mn" else return "So" end
                      else
                        if c < 3896 then return "Mn" else return "So" end
                      end
                    end
                  else
                    if c < 3901 then
                      if c < 3899 then
                        if c < 3898 then return "Mn" else return "Ps" end
                      else
                        if c < 3900 then return "Pe" else return "Ps" end
                      end
                    else
                      if c < 3904 then
                        if c < 3902 then return "Pe" else return "Mc" end
                      else
                        if c < 3912 then return "Lo" else return "Cn" end
                      end
                    end
                  end
                end
              end
            end
          else
            if c < 4348 then
              if c < 4170 then
                if c < 4046 then
                  if c < 3981 then
                    if c < 3968 then
                      if c < 3953 then
                        if c < 3949 then return "Lo" else return "Cn" end
                      else
                        if c < 3967 then return "Mn" else return "Mc" end
                      end
                    else
                      if c < 3974 then
                        if c < 3973 then return "Mn" else return "Po" end
                      else
                        if c < 3976 then return "Mn" else return "Lo" end
                      end
                    end
                  else
                    if c < 4030 then
                      if c < 3993 then
                        if c < 3992 then return "Mn" else return "Cn" end
                      else
                        if c < 4029 then return "Mn" else return "Cn" end
                      end
                    else
                      if c < 4039 then
                        if c < 4038 then return "So" else return "Mn" end
                      else
                        if c < 4045 then return "So" else return "Cn" end
                      end
                    end
                  end
                else
                  if c < 4145 then
                    if c < 4059 then
                      if c < 4053 then
                        if c < 4048 then return "So" else return "Po" end
                      else
                        if c < 4057 then return "So" else return "Po" end
                      end
                    else
                      if c < 4139 then
                        if c < 4096 then return "Cn" else return "Lo" end
                      else
                        if c < 4141 then return "Mc" else return "Mn" end
                      end
                    end
                  else
                    if c < 4155 then
                      if c < 4152 then
                        if c < 4146 then return "Mc" else return "Mn" end
                      else
                        if c < 4153 then return "Mc" else return "Mn" end
                      end
                    else
                      if c < 4159 then
                        if c < 4157 then return "Mc" else return "Mn" end
                      else
                        if c < 4160 then return "Lo" else return "Nd" end
                      end
                    end
                  end
                end
              else
                if c < 4231 then
                  if c < 4197 then
                    if c < 4186 then
                      if c < 4182 then
                        if c < 4176 then return "Po" else return "Lo" end
                      else
                        if c < 4184 then return "Mc" else return "Mn" end
                      end
                    else
                      if c < 4193 then
                        if c < 4190 then return "Lo" else return "Mn" end
                      else
                        if c < 4194 then return "Lo" else return "Mc" end
                      end
                    end
                  else
                    if c < 4213 then
                      if c < 4206 then
                        if c < 4199 then return "Lo" else return "Mc" end
                      else
                        if c < 4209 then return "Lo" else return "Mn" end
                      end
                    else
                      if c < 4227 then
                        if c < 4226 then return "Lo" else return "Mn" end
                      else
                        if c < 4229 then return "Mc" else return "Mn" end
                      end
                    end
                  end
                else
                  if c < 4256 then
                    if c < 4240 then
                      if c < 4238 then
                        if c < 4237 then return "Mc" else return "Mn" end
                      else
                        if c < 4239 then return "Lo" else return "Mc" end
                      end
                    else
                      if c < 4253 then
                        if c < 4250 then return "Nd" else return "Mc" end
                      else
                        if c < 4254 then return "Mn" else return "So" end
                      end
                    end
                  else
                    if c < 4301 then
                      if c < 4295 then
                        if c < 4294 then return "Lu" else return "Cn" end
                      else
                        if c < 4296 then return "Lu" else return "Cn" end
                      end
                    else
                      if c < 4304 then
                        if c < 4302 then return "Lu" else return "Cn" end
                      else
                        if c < 4347 then return "Lo" else return "Po" end
                      end
                    end
                  end
                end
              end
            else
              if c < 4955 then
                if c < 4785 then
                  if c < 4697 then
                    if c < 4686 then
                      if c < 4681 then
                        if c < 4349 then return "Lm" else return "Lo" end
                      else
                        if c < 4682 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 4695 then
                        if c < 4688 then return "Cn" else return "Lo" end
                      else
                        if c < 4696 then return "Cn" else return "Lo" end
                      end
                    end
                  else
                    if c < 4745 then
                      if c < 4702 then
                        if c < 4698 then return "Cn" else return "Lo" end
                      else
                        if c < 4704 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 4750 then
                        if c < 4746 then return "Cn" else return "Lo" end
                      else
                        if c < 4752 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                else
                  if c < 4806 then
                    if c < 4799 then
                      if c < 4790 then
                        if c < 4786 then return "Cn" else return "Lo" end
                      else
                        if c < 4792 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 4801 then
                        if c < 4800 then return "Cn" else return "Lo" end
                      else
                        if c < 4802 then return "Cn" else return "Lo" end
                      end
                    end
                  else
                    if c < 4881 then
                      if c < 4823 then
                        if c < 4808 then return "Cn" else return "Lo" end
                      else
                        if c < 4824 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 4886 then
                        if c < 4882 then return "Cn" else return "Lo" end
                      else
                        if c < 4888 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                end
              else
                if c < 5760 then
                  if c < 5024 then
                    if c < 4989 then
                      if c < 4960 then
                        if c < 4957 then return "Cn" else return "Mn" end
                      else
                        if c < 4969 then return "Po" else return "No" end
                      end
                    else
                      if c < 5008 then
                        if c < 4992 then return "Cn" else return "Lo" end
                      else
                        if c < 5018 then return "So" else return "Cn" end
                      end
                    end
                  else
                    if c < 5120 then
                      if c < 5112 then
                        if c < 5110 then return "Lu" else return "Cn" end
                      else
                        if c < 5118 then return "Ll" else return "Cn" end
                      end
                    else
                      if c < 5741 then
                        if c < 5121 then return "Pd" else return "Lo" end
                      else
                        if c < 5743 then return "Po" else return "Lo" end
                      end
                    end
                  end
                else
                  if c < 5873 then
                    if c < 5789 then
                      if c < 5787 then
                        if c < 5761 then return "Zs" else return "Lo" end
                      else
                        if c < 5788 then return "Ps" else return "Pe" end
                      end
                    else
                      if c < 5867 then
                        if c < 5792 then return "Cn" else return "Lo" end
                      else
                        if c < 5870 then return "Po" else return "Nl" end
                      end
                    end
                  else
                    if c < 5902 then
                      if c < 5888 then
                        if c < 5881 then return "Lo" else return "Cn" end
                      else
                        if c < 5901 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 5909 then
                        if c < 5906 then return "Lo" else return "Mn" end
                      else
                        if c < 5920 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                end
              end
            end
          end
        else
          if c < 7028 then
            if c < 6465 then
              if c < 6150 then
                if c < 6078 then
                  if c < 5998 then
                    if c < 5970 then
                      if c < 5943 then
                        if c < 5941 then return "Mn" else return "Po" end
                      else
                        if c < 5952 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 5984 then
                        if c < 5972 then return "Mn" else return "Cn" end
                      else
                        if c < 5997 then return "Lo" else return "Cn" end
                      end
                    end
                  else
                    if c < 6016 then
                      if c < 6002 then
                        if c < 6001 then return "Lo" else return "Cn" end
                      else
                        if c < 6004 then return "Mn" else return "Cn" end
                      end
                    else
                      if c < 6070 then
                        if c < 6068 then return "Lo" else return "Mn" end
                      else
                        if c < 6071 then return "Mc" else return "Mn" end
                      end
                    end
                  end
                else
                  if c < 6108 then
                    if c < 6100 then
                      if c < 6087 then
                        if c < 6086 then return "Mc" else return "Mn" end
                      else
                        if c < 6089 then return "Mc" else return "Mn" end
                      end
                    else
                      if c < 6104 then
                        if c < 6103 then return "Po" else return "Lm" end
                      else
                        if c < 6107 then return "Po" else return "Sc" end
                      end
                    end
                  else
                    if c < 6122 then
                      if c < 6110 then
                        if c < 6109 then return "Lo" else return "Mn" end
                      else
                        if c < 6112 then return "Cn" else return "Nd" end
                      end
                    else
                      if c < 6138 then
                        if c < 6128 then return "Cn" else return "No" end
                      else
                        if c < 6144 then return "Cn" else return "Po" end
                      end
                    end
                  end
                end
              else
                if c < 6315 then
                  if c < 6211 then
                    if c < 6159 then
                      if c < 6155 then
                        if c < 6151 then return "Pd" else return "Po" end
                      else
                        if c < 6158 then return "Mn" else return "Cf" end
                      end
                    else
                      if c < 6170 then
                        if c < 6160 then return "Cn" else return "Nd" end
                      else
                        if c < 6176 then return "Cn" else return "Lo" end
                      end
                    end
                  else
                    if c < 6277 then
                      if c < 6264 then
                        if c < 6212 then return "Lm" else return "Lo" end
                      else
                        if c < 6272 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 6313 then
                        if c < 6279 then return "Mn" else return "Lo" end
                      else
                        if c < 6314 then return "Mn" else return "Lo" end
                      end
                    end
                  end
                else
                  if c < 6441 then
                    if c < 6431 then
                      if c < 6390 then
                        if c < 6320 then return "Cn" else return "Lo" end
                      else
                        if c < 6400 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 6435 then
                        if c < 6432 then return "Cn" else return "Mn" end
                      else
                        if c < 6439 then return "Mc" else return "Mn" end
                      end
                    end
                  else
                    if c < 6451 then
                      if c < 6448 then
                        if c < 6444 then return "Mc" else return "Cn" end
                      else
                        if c < 6450 then return "Mc" else return "Mn" end
                      end
                    else
                      if c < 6460 then
                        if c < 6457 then return "Mc" else return "Mn" end
                      else
                        if c < 6464 then return "Cn" else return "So" end
                      end
                    end
                  end
                end
              end
            else
              if c < 6765 then
                if c < 6679 then
                  if c < 6572 then
                    if c < 6510 then
                      if c < 6470 then
                        if c < 6468 then return "Cn" else return "Po" end
                      else
                        if c < 6480 then return "Nd" else return "Lo" end
                      end
                    else
                      if c < 6517 then
                        if c < 6512 then return "Cn" else return "Lo" end
                      else
                        if c < 6528 then return "Cn" else return "Lo" end
                      end
                    end
                  else
                    if c < 6618 then
                      if c < 6602 then
                        if c < 6576 then return "Cn" else return "Lo" end
                      else
                        if c < 6608 then return "Cn" else return "Nd" end
                      end
                    else
                      if c < 6622 then
                        if c < 6619 then return "No" else return "Cn" end
                      else
                        if c < 6656 then return "So" else return "Lo" end
                      end
                    end
                  end
                else
                  if c < 6743 then
                    if c < 6686 then
                      if c < 6683 then
                        if c < 6681 then return "Mn" else return "Mc" end
                      else
                        if c < 6684 then return "Mn" else return "Cn" end
                      end
                    else
                      if c < 6741 then
                        if c < 6688 then return "Po" else return "Lo" end
                      else
                        if c < 6742 then return "Mc" else return "Mn" end
                      end
                    end
                  else
                    if c < 6753 then
                      if c < 6751 then
                        if c < 6744 then return "Mc" else return "Mn" end
                      else
                        if c < 6752 then return "Cn" else return "Mn" end
                      end
                    else
                      if c < 6755 then
                        if c < 6754 then return "Mc" else return "Mn" end
                      else
                        if c < 6757 then return "Mc" else return "Mn" end
                      end
                    end
                  end
                end
              else
                if c < 6916 then
                  if c < 6816 then
                    if c < 6784 then
                      if c < 6781 then
                        if c < 6771 then return "Mc" else return "Mn" end
                      else
                        if c < 6783 then return "Cn" else return "Mn" end
                      end
                    else
                      if c < 6800 then
                        if c < 6794 then return "Nd" else return "Cn" end
                      else
                        if c < 6810 then return "Nd" else return "Cn" end
                      end
                    end
                  else
                    if c < 6832 then
                      if c < 6824 then
                        if c < 6823 then return "Po" else return "Lm" end
                      else
                        if c < 6830 then return "Po" else return "Cn" end
                      end
                    else
                      if c < 6847 then
                        if c < 6846 then return "Mn" else return "Me" end
                      else
                        if c < 6912 then return "Cn" else return "Mn" end
                      end
                    end
                  end
                else
                  if c < 6978 then
                    if c < 6966 then
                      if c < 6964 then
                        if c < 6917 then return "Mc" else return "Lo" end
                      else
                        if c < 6965 then return "Mn" else return "Mc" end
                      end
                    else
                      if c < 6972 then
                        if c < 6971 then return "Mn" else return "Mc" end
                      else
                        if c < 6973 then return "Mn" else return "Mc" end
                      end
                    end
                  else
                    if c < 6992 then
                      if c < 6981 then
                        if c < 6979 then return "Mn" else return "Mc" end
                      else
                        if c < 6988 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 7009 then
                        if c < 7002 then return "Nd" else return "Po" end
                      else
                        if c < 7019 then return "So" else return "Mn" end
                      end
                    end
                  end
                end
              end
            end
          else
            if c < 7675 then
              if c < 7242 then
                if c < 7144 then
                  if c < 7080 then
                    if c < 7043 then
                      if c < 7040 then
                        if c < 7037 then return "So" else return "Cn" end
                      else
                        if c < 7042 then return "Mn" else return "Mc" end
                      end
                    else
                      if c < 7074 then
                        if c < 7073 then return "Lo" else return "Mc" end
                      else
                        if c < 7078 then return "Mn" else return "Mc" end
                      end
                    end
                  else
                    if c < 7088 then
                      if c < 7083 then
                        if c < 7082 then return "Mn" else return "Mc" end
                      else
                        if c < 7086 then return "Mn" else return "Lo" end
                      end
                    else
                      if c < 7142 then
                        if c < 7098 then return "Nd" else return "Lo" end
                      else
                        if c < 7143 then return "Mn" else return "Mc" end
                      end
                    end
                  end
                else
                  if c < 7168 then
                    if c < 7151 then
                      if c < 7149 then
                        if c < 7146 then return "Mn" else return "Mc" end
                      else
                        if c < 7150 then return "Mn" else return "Mc" end
                      end
                    else
                      if c < 7156 then
                        if c < 7154 then return "Mn" else return "Mc" end
                      else
                        if c < 7164 then return "Cn" else return "Po" end
                      end
                    end
                  else
                    if c < 7222 then
                      if c < 7212 then
                        if c < 7204 then return "Lo" else return "Mc" end
                      else
                        if c < 7220 then return "Mn" else return "Mc" end
                      end
                    else
                      if c < 7227 then
                        if c < 7224 then return "Mn" else return "Cn" end
                      else
                        if c < 7232 then return "Po" else return "Nd" end
                      end
                    end
                  end
                end
              else
                if c < 7405 then
                  if c < 7360 then
                    if c < 7288 then
                      if c < 7248 then
                        if c < 7245 then return "Cn" else return "Lo" end
                      else
                        if c < 7258 then return "Nd" else return "Lo" end
                      end
                    else
                      if c < 7296 then
                        if c < 7294 then return "Lm" else return "Po" end
                      else
                        if c < 7305 then return "Ll" else return "Cn" end
                      end
                    end
                  else
                    if c < 7380 then
                      if c < 7376 then
                        if c < 7368 then return "Po" else return "Cn" end
                      else
                        if c < 7379 then return "Mn" else return "Po" end
                      end
                    else
                      if c < 7394 then
                        if c < 7393 then return "Mn" else return "Mc" end
                      else
                        if c < 7401 then return "Mn" else return "Lo" end
                      end
                    end
                  end
                else
                  if c < 7424 then
                    if c < 7413 then
                      if c < 7410 then
                        if c < 7406 then return "Mn" else return "Lo" end
                      else
                        if c < 7412 then return "Mc" else return "Mn" end
                      end
                    else
                      if c < 7416 then
                        if c < 7415 then return "Lo" else return "Mc" end
                      else
                        if c < 7418 then return "Mn" else return "Cn" end
                      end
                    end
                  else
                    if c < 7545 then
                      if c < 7531 then
                        if c < 7468 then return "Ll" else return "Lm" end
                      else
                        if c < 7544 then return "Ll" else return "Lm" end
                      end
                    else
                      if c < 7616 then
                        if c < 7579 then return "Ll" else return "Lm" end
                      else
                        if c < 7674 then return "Mn" else return "Cn" end
                      end
                    end
                  end
                end
              end
            else
              if c < 7711 then
                if c < 7695 then
                  if c < 7687 then
                    if c < 7683 then
                      if c < 7681 then
                        if c < 7680 then return "Mn" else return "Lu" end
                      else
                        if c < 7682 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7685 then
                        if c < 7684 then return "Ll" else return "Lu" end
                      else
                        if c < 7686 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 7691 then
                      if c < 7689 then
                        if c < 7688 then return "Ll" else return "Lu" end
                      else
                        if c < 7690 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7693 then
                        if c < 7692 then return "Ll" else return "Lu" end
                      else
                        if c < 7694 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                else
                  if c < 7703 then
                    if c < 7699 then
                      if c < 7697 then
                        if c < 7696 then return "Ll" else return "Lu" end
                      else
                        if c < 7698 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7701 then
                        if c < 7700 then return "Ll" else return "Lu" end
                      else
                        if c < 7702 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 7707 then
                      if c < 7705 then
                        if c < 7704 then return "Ll" else return "Lu" end
                      else
                        if c < 7706 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7709 then
                        if c < 7708 then return "Ll" else return "Lu" end
                      else
                        if c < 7710 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                end
              else
                if c < 7727 then
                  if c < 7719 then
                    if c < 7715 then
                      if c < 7713 then
                        if c < 7712 then return "Ll" else return "Lu" end
                      else
                        if c < 7714 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7717 then
                        if c < 7716 then return "Ll" else return "Lu" end
                      else
                        if c < 7718 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 7723 then
                      if c < 7721 then
                        if c < 7720 then return "Ll" else return "Lu" end
                      else
                        if c < 7722 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7725 then
                        if c < 7724 then return "Ll" else return "Lu" end
                      else
                        if c < 7726 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                else
                  if c < 7735 then
                    if c < 7731 then
                      if c < 7729 then
                        if c < 7728 then return "Ll" else return "Lu" end
                      else
                        if c < 7730 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7733 then
                        if c < 7732 then return "Ll" else return "Lu" end
                      else
                        if c < 7734 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 7739 then
                      if c < 7737 then
                        if c < 7736 then return "Ll" else return "Lu" end
                      else
                        if c < 7738 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7741 then
                        if c < 7740 then return "Ll" else return "Lu" end
                      else
                        if c < 7742 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                end
              end
            end
          end
        end
      else
        if c < 8221 then
          if c < 7879 then
            if c < 7807 then
              if c < 7775 then
                if c < 7759 then
                  if c < 7751 then
                    if c < 7747 then
                      if c < 7745 then
                        if c < 7744 then return "Ll" else return "Lu" end
                      else
                        if c < 7746 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7749 then
                        if c < 7748 then return "Ll" else return "Lu" end
                      else
                        if c < 7750 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 7755 then
                      if c < 7753 then
                        if c < 7752 then return "Ll" else return "Lu" end
                      else
                        if c < 7754 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7757 then
                        if c < 7756 then return "Ll" else return "Lu" end
                      else
                        if c < 7758 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                else
                  if c < 7767 then
                    if c < 7763 then
                      if c < 7761 then
                        if c < 7760 then return "Ll" else return "Lu" end
                      else
                        if c < 7762 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7765 then
                        if c < 7764 then return "Ll" else return "Lu" end
                      else
                        if c < 7766 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 7771 then
                      if c < 7769 then
                        if c < 7768 then return "Ll" else return "Lu" end
                      else
                        if c < 7770 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7773 then
                        if c < 7772 then return "Ll" else return "Lu" end
                      else
                        if c < 7774 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                end
              else
                if c < 7791 then
                  if c < 7783 then
                    if c < 7779 then
                      if c < 7777 then
                        if c < 7776 then return "Ll" else return "Lu" end
                      else
                        if c < 7778 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7781 then
                        if c < 7780 then return "Ll" else return "Lu" end
                      else
                        if c < 7782 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 7787 then
                      if c < 7785 then
                        if c < 7784 then return "Ll" else return "Lu" end
                      else
                        if c < 7786 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7789 then
                        if c < 7788 then return "Ll" else return "Lu" end
                      else
                        if c < 7790 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                else
                  if c < 7799 then
                    if c < 7795 then
                      if c < 7793 then
                        if c < 7792 then return "Ll" else return "Lu" end
                      else
                        if c < 7794 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7797 then
                        if c < 7796 then return "Ll" else return "Lu" end
                      else
                        if c < 7798 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 7803 then
                      if c < 7801 then
                        if c < 7800 then return "Ll" else return "Lu" end
                      else
                        if c < 7802 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7805 then
                        if c < 7804 then return "Ll" else return "Lu" end
                      else
                        if c < 7806 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                end
              end
            else
              if c < 7847 then
                if c < 7823 then
                  if c < 7815 then
                    if c < 7811 then
                      if c < 7809 then
                        if c < 7808 then return "Ll" else return "Lu" end
                      else
                        if c < 7810 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7813 then
                        if c < 7812 then return "Ll" else return "Lu" end
                      else
                        if c < 7814 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 7819 then
                      if c < 7817 then
                        if c < 7816 then return "Ll" else return "Lu" end
                      else
                        if c < 7818 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7821 then
                        if c < 7820 then return "Ll" else return "Lu" end
                      else
                        if c < 7822 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                else
                  if c < 7839 then
                    if c < 7827 then
                      if c < 7825 then
                        if c < 7824 then return "Ll" else return "Lu" end
                      else
                        if c < 7826 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7829 then
                        if c < 7828 then return "Ll" else return "Lu" end
                      else
                        if c < 7838 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 7843 then
                      if c < 7841 then
                        if c < 7840 then return "Ll" else return "Lu" end
                      else
                        if c < 7842 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7845 then
                        if c < 7844 then return "Ll" else return "Lu" end
                      else
                        if c < 7846 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                end
              else
                if c < 7863 then
                  if c < 7855 then
                    if c < 7851 then
                      if c < 7849 then
                        if c < 7848 then return "Ll" else return "Lu" end
                      else
                        if c < 7850 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7853 then
                        if c < 7852 then return "Ll" else return "Lu" end
                      else
                        if c < 7854 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 7859 then
                      if c < 7857 then
                        if c < 7856 then return "Ll" else return "Lu" end
                      else
                        if c < 7858 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7861 then
                        if c < 7860 then return "Ll" else return "Lu" end
                      else
                        if c < 7862 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                else
                  if c < 7871 then
                    if c < 7867 then
                      if c < 7865 then
                        if c < 7864 then return "Ll" else return "Lu" end
                      else
                        if c < 7866 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7869 then
                        if c < 7868 then return "Ll" else return "Lu" end
                      else
                        if c < 7870 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 7875 then
                      if c < 7873 then
                        if c < 7872 then return "Ll" else return "Lu" end
                      else
                        if c < 7874 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7877 then
                        if c < 7876 then return "Ll" else return "Lu" end
                      else
                        if c < 7878 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                end
              end
            end
          else
            if c < 7984 then
              if c < 7911 then
                if c < 7895 then
                  if c < 7887 then
                    if c < 7883 then
                      if c < 7881 then
                        if c < 7880 then return "Ll" else return "Lu" end
                      else
                        if c < 7882 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7885 then
                        if c < 7884 then return "Ll" else return "Lu" end
                      else
                        if c < 7886 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 7891 then
                      if c < 7889 then
                        if c < 7888 then return "Ll" else return "Lu" end
                      else
                        if c < 7890 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7893 then
                        if c < 7892 then return "Ll" else return "Lu" end
                      else
                        if c < 7894 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                else
                  if c < 7903 then
                    if c < 7899 then
                      if c < 7897 then
                        if c < 7896 then return "Ll" else return "Lu" end
                      else
                        if c < 7898 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7901 then
                        if c < 7900 then return "Ll" else return "Lu" end
                      else
                        if c < 7902 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 7907 then
                      if c < 7905 then
                        if c < 7904 then return "Ll" else return "Lu" end
                      else
                        if c < 7906 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7909 then
                        if c < 7908 then return "Ll" else return "Lu" end
                      else
                        if c < 7910 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                end
              else
                if c < 7927 then
                  if c < 7919 then
                    if c < 7915 then
                      if c < 7913 then
                        if c < 7912 then return "Ll" else return "Lu" end
                      else
                        if c < 7914 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7917 then
                        if c < 7916 then return "Ll" else return "Lu" end
                      else
                        if c < 7918 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 7923 then
                      if c < 7921 then
                        if c < 7920 then return "Ll" else return "Lu" end
                      else
                        if c < 7922 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7925 then
                        if c < 7924 then return "Ll" else return "Lu" end
                      else
                        if c < 7926 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                else
                  if c < 7935 then
                    if c < 7931 then
                      if c < 7929 then
                        if c < 7928 then return "Ll" else return "Lu" end
                      else
                        if c < 7930 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 7933 then
                        if c < 7932 then return "Ll" else return "Lu" end
                      else
                        if c < 7934 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 7960 then
                      if c < 7952 then
                        if c < 7944 then return "Ll" else return "Lu" end
                      else
                        if c < 7958 then return "Ll" else return "Cn" end
                      end
                    else
                      if c < 7968 then
                        if c < 7966 then return "Lu" else return "Cn" end
                      else
                        if c < 7976 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                end
              end
            else
              if c < 8127 then
                if c < 8040 then
                  if c < 8025 then
                    if c < 8008 then
                      if c < 8000 then
                        if c < 7992 then return "Ll" else return "Lu" end
                      else
                        if c < 8006 then return "Ll" else return "Cn" end
                      end
                    else
                      if c < 8016 then
                        if c < 8014 then return "Lu" else return "Cn" end
                      else
                        if c < 8024 then return "Ll" else return "Cn" end
                      end
                    end
                  else
                    if c < 8029 then
                      if c < 8027 then
                        if c < 8026 then return "Lu" else return "Cn" end
                      else
                        if c < 8028 then return "Lu" else return "Cn" end
                      end
                    else
                      if c < 8031 then
                        if c < 8030 then return "Lu" else return "Cn" end
                      else
                        if c < 8032 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 8104 then
                    if c < 8072 then
                      if c < 8062 then
                        if c < 8048 then return "Lu" else return "Ll" end
                      else
                        if c < 8064 then return "Cn" else return "Ll" end
                      end
                    else
                      if c < 8088 then
                        if c < 8080 then return "Lt" else return "Ll" end
                      else
                        if c < 8096 then return "Lt" else return "Ll" end
                      end
                    end
                  else
                    if c < 8120 then
                      if c < 8117 then
                        if c < 8112 then return "Lt" else return "Ll" end
                      else
                        if c < 8118 then return "Cn" else return "Ll" end
                      end
                    else
                      if c < 8125 then
                        if c < 8124 then return "Lu" else return "Lt" end
                      else
                        if c < 8126 then return "Sk" else return "Ll" end
                      end
                    end
                  end
                end
              else
                if c < 8176 then
                  if c < 8148 then
                    if c < 8136 then
                      if c < 8133 then
                        if c < 8130 then return "Sk" else return "Ll" end
                      else
                        if c < 8134 then return "Cn" else return "Ll" end
                      end
                    else
                      if c < 8141 then
                        if c < 8140 then return "Lu" else return "Lt" end
                      else
                        if c < 8144 then return "Sk" else return "Ll" end
                      end
                    end
                  else
                    if c < 8157 then
                      if c < 8152 then
                        if c < 8150 then return "Cn" else return "Ll" end
                      else
                        if c < 8156 then return "Lu" else return "Cn" end
                      end
                    else
                      if c < 8168 then
                        if c < 8160 then return "Sk" else return "Ll" end
                      else
                        if c < 8173 then return "Lu" else return "Sk" end
                      end
                    end
                  end
                else
                  if c < 8192 then
                    if c < 8184 then
                      if c < 8181 then
                        if c < 8178 then return "Cn" else return "Ll" end
                      else
                        if c < 8182 then return "Cn" else return "Ll" end
                      end
                    else
                      if c < 8189 then
                        if c < 8188 then return "Lu" else return "Lt" end
                      else
                        if c < 8191 then return "Sk" else return "Cn" end
                      end
                    end
                  else
                    if c < 8216 then
                      if c < 8208 then
                        if c < 8203 then return "Zs" else return "Cf" end
                      else
                        if c < 8214 then return "Pd" else return "Po" end
                      end
                    else
                      if c < 8218 then
                        if c < 8217 then return "Pi" else return "Pf" end
                      else
                        if c < 8219 then return "Ps" else return "Pi" end
                      end
                    end
                  end
                end
              end
            end
          end
        else
          if c < 9085 then
            if c < 8478 then
              if c < 8318 then
                if c < 8262 then
                  if c < 8240 then
                    if c < 8232 then
                      if c < 8223 then
                        if c < 8222 then return "Pf" else return "Ps" end
                      else
                        if c < 8224 then return "Pi" else return "Po" end
                      end
                    else
                      if c < 8234 then
                        if c < 8233 then return "Zl" else return "Zp" end
                      else
                        if c < 8239 then return "Cf" else return "Zs" end
                      end
                    end
                  else
                    if c < 8255 then
                      if c < 8250 then
                        if c < 8249 then return "Po" else return "Pi" end
                      else
                        if c < 8251 then return "Pf" else return "Po" end
                      end
                    else
                      if c < 8260 then
                        if c < 8257 then return "Pc" else return "Po" end
                      else
                        if c < 8261 then return "Sm" else return "Ps" end
                      end
                    end
                  end
                else
                  if c < 8293 then
                    if c < 8276 then
                      if c < 8274 then
                        if c < 8263 then return "Pe" else return "Po" end
                      else
                        if c < 8275 then return "Sm" else return "Po" end
                      end
                    else
                      if c < 8287 then
                        if c < 8277 then return "Pc" else return "Po" end
                      else
                        if c < 8288 then return "Zs" else return "Cf" end
                      end
                    end
                  else
                    if c < 8306 then
                      if c < 8304 then
                        if c < 8294 then return "Cn" else return "Cf" end
                      else
                        if c < 8305 then return "No" else return "Lm" end
                      end
                    else
                      if c < 8314 then
                        if c < 8308 then return "Cn" else return "No" end
                      else
                        if c < 8317 then return "Sm" else return "Ps" end
                      end
                    end
                  end
                end
              else
                if c < 8433 then
                  if c < 8349 then
                    if c < 8333 then
                      if c < 8320 then
                        if c < 8319 then return "Pe" else return "Lm" end
                      else
                        if c < 8330 then return "No" else return "Sm" end
                      end
                    else
                      if c < 8335 then
                        if c < 8334 then return "Ps" else return "Pe" end
                      else
                        if c < 8336 then return "Cn" else return "Lm" end
                      end
                    end
                  else
                    if c < 8413 then
                      if c < 8384 then
                        if c < 8352 then return "Cn" else return "Sc" end
                      else
                        if c < 8400 then return "Cn" else return "Mn" end
                      end
                    else
                      if c < 8418 then
                        if c < 8417 then return "Me" else return "Mn" end
                      else
                        if c < 8421 then return "Me" else return "Mn" end
                      end
                    end
                  end
                else
                  if c < 8462 then
                    if c < 8455 then
                      if c < 8450 then
                        if c < 8448 then return "Cn" else return "So" end
                      else
                        if c < 8451 then return "Lu" else return "So" end
                      end
                    else
                      if c < 8458 then
                        if c < 8456 then return "Lu" else return "So" end
                      else
                        if c < 8459 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 8469 then
                      if c < 8467 then
                        if c < 8464 then return "Ll" else return "Lu" end
                      else
                        if c < 8468 then return "Ll" else return "So" end
                      end
                    else
                      if c < 8472 then
                        if c < 8470 then return "Lu" else return "So" end
                      else
                        if c < 8473 then return "Sm" else return "Lu" end
                      end
                    end
                  end
                end
              end
            else
              if c < 8588 then
                if c < 8510 then
                  if c < 8494 then
                    if c < 8487 then
                      if c < 8485 then
                        if c < 8484 then return "So" else return "Lu" end
                      else
                        if c < 8486 then return "So" else return "Lu" end
                      end
                    else
                      if c < 8489 then
                        if c < 8488 then return "So" else return "Lu" end
                      else
                        if c < 8490 then return "So" else return "Lu" end
                      end
                    end
                  else
                    if c < 8501 then
                      if c < 8496 then
                        if c < 8495 then return "So" else return "Ll" end
                      else
                        if c < 8500 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 8506 then
                        if c < 8505 then return "Lo" else return "Ll" end
                      else
                        if c < 8508 then return "So" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 8527 then
                    if c < 8522 then
                      if c < 8517 then
                        if c < 8512 then return "Lu" else return "Sm" end
                      else
                        if c < 8518 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 8524 then
                        if c < 8523 then return "So" else return "Sm" end
                      else
                        if c < 8526 then return "So" else return "Ll" end
                      end
                    end
                  else
                    if c < 8580 then
                      if c < 8544 then
                        if c < 8528 then return "So" else return "No" end
                      else
                        if c < 8579 then return "Nl" else return "Lu" end
                      end
                    else
                      if c < 8585 then
                        if c < 8581 then return "Ll" else return "Nl" end
                      else
                        if c < 8586 then return "No" else return "So" end
                      end
                    end
                  end
                end
              else
                if c < 8659 then
                  if c < 8612 then
                    if c < 8604 then
                      if c < 8597 then
                        if c < 8592 then return "Cn" else return "Sm" end
                      else
                        if c < 8602 then return "So" else return "Sm" end
                      end
                    else
                      if c < 8609 then
                        if c < 8608 then return "So" else return "Sm" end
                      else
                        if c < 8611 then return "So" else return "Sm" end
                      end
                    end
                  else
                    if c < 8623 then
                      if c < 8615 then
                        if c < 8614 then return "So" else return "Sm" end
                      else
                        if c < 8622 then return "So" else return "Sm" end
                      end
                    else
                      if c < 8656 then
                        if c < 8654 then return "So" else return "Sm" end
                      else
                        if c < 8658 then return "So" else return "Sm" end
                      end
                    end
                  end
                else
                  if c < 8971 then
                    if c < 8960 then
                      if c < 8661 then
                        if c < 8660 then return "So" else return "Sm" end
                      else
                        if c < 8692 then return "So" else return "Sm" end
                      end
                    else
                      if c < 8969 then
                        if c < 8968 then return "So" else return "Ps" end
                      else
                        if c < 8970 then return "Pe" else return "Ps" end
                      end
                    end
                  else
                    if c < 9001 then
                      if c < 8992 then
                        if c < 8972 then return "Pe" else return "So" end
                      else
                        if c < 8994 then return "Sm" else return "So" end
                      end
                    else
                      if c < 9003 then
                        if c < 9002 then return "Ps" else return "Pe" end
                      else
                        if c < 9084 then return "So" else return "Sm" end
                      end
                    end
                  end
                end
              end
            end
          else
            if c < 10638 then
              if c < 10100 then
                if c < 9720 then
                  if c < 9312 then
                    if c < 9186 then
                      if c < 9140 then
                        if c < 9115 then return "So" else return "Sm" end
                      else
                        if c < 9180 then return "So" else return "Sm" end
                      end
                    else
                      if c < 9280 then
                        if c < 9255 then return "So" else return "Cn" end
                      else
                        if c < 9291 then return "So" else return "Cn" end
                      end
                    end
                  else
                    if c < 9655 then
                      if c < 9450 then
                        if c < 9372 then return "No" else return "So" end
                      else
                        if c < 9472 then return "No" else return "So" end
                      end
                    else
                      if c < 9665 then
                        if c < 9656 then return "Sm" else return "So" end
                      else
                        if c < 9666 then return "Sm" else return "So" end
                      end
                    end
                  end
                else
                  if c < 10092 then
                    if c < 10088 then
                      if c < 9839 then
                        if c < 9728 then return "Sm" else return "So" end
                      else
                        if c < 9840 then return "Sm" else return "So" end
                      end
                    else
                      if c < 10090 then
                        if c < 10089 then return "Ps" else return "Pe" end
                      else
                        if c < 10091 then return "Ps" else return "Pe" end
                      end
                    end
                  else
                    if c < 10096 then
                      if c < 10094 then
                        if c < 10093 then return "Ps" else return "Pe" end
                      else
                        if c < 10095 then return "Ps" else return "Pe" end
                      end
                    else
                      if c < 10098 then
                        if c < 10097 then return "Ps" else return "Pe" end
                      else
                        if c < 10099 then return "Ps" else return "Pe" end
                      end
                    end
                  end
                end
              else
                if c < 10222 then
                  if c < 10214 then
                    if c < 10176 then
                      if c < 10102 then
                        if c < 10101 then return "Ps" else return "Pe" end
                      else
                        if c < 10132 then return "No" else return "So" end
                      end
                    else
                      if c < 10182 then
                        if c < 10181 then return "Sm" else return "Ps" end
                      else
                        if c < 10183 then return "Pe" else return "Sm" end
                      end
                    end
                  else
                    if c < 10218 then
                      if c < 10216 then
                        if c < 10215 then return "Ps" else return "Pe" end
                      else
                        if c < 10217 then return "Ps" else return "Pe" end
                      end
                    else
                      if c < 10220 then
                        if c < 10219 then return "Ps" else return "Pe" end
                      else
                        if c < 10221 then return "Ps" else return "Pe" end
                      end
                    end
                  end
                else
                  if c < 10630 then
                    if c < 10496 then
                      if c < 10224 then
                        if c < 10223 then return "Ps" else return "Pe" end
                      else
                        if c < 10240 then return "Sm" else return "So" end
                      end
                    else
                      if c < 10628 then
                        if c < 10627 then return "Sm" else return "Ps" end
                      else
                        if c < 10629 then return "Pe" else return "Ps" end
                      end
                    end
                  else
                    if c < 10634 then
                      if c < 10632 then
                        if c < 10631 then return "Pe" else return "Ps" end
                      else
                        if c < 10633 then return "Pe" else return "Ps" end
                      end
                    else
                      if c < 10636 then
                        if c < 10635 then return "Pe" else return "Ps" end
                      else
                        if c < 10637 then return "Pe" else return "Ps" end
                      end
                    end
                  end
                end
              end
            else
              if c < 11210 then
                if c < 10716 then
                  if c < 10646 then
                    if c < 10642 then
                      if c < 10640 then
                        if c < 10639 then return "Pe" else return "Ps" end
                      else
                        if c < 10641 then return "Pe" else return "Ps" end
                      end
                    else
                      if c < 10644 then
                        if c < 10643 then return "Pe" else return "Ps" end
                      else
                        if c < 10645 then return "Pe" else return "Ps" end
                      end
                    end
                  else
                    if c < 10712 then
                      if c < 10648 then
                        if c < 10647 then return "Pe" else return "Ps" end
                      else
                        if c < 10649 then return "Pe" else return "Sm" end
                      end
                    else
                      if c < 10714 then
                        if c < 10713 then return "Ps" else return "Pe" end
                      else
                        if c < 10715 then return "Ps" else return "Pe" end
                      end
                    end
                  end
                else
                  if c < 11085 then
                    if c < 11008 then
                      if c < 10749 then
                        if c < 10748 then return "Sm" else return "Ps" end
                      else
                        if c < 10750 then return "Pe" else return "Sm" end
                      end
                    else
                      if c < 11077 then
                        if c < 11056 then return "So" else return "Sm" end
                      else
                        if c < 11079 then return "So" else return "Sm" end
                      end
                    end
                  else
                    if c < 11160 then
                      if c < 11126 then
                        if c < 11124 then return "So" else return "Cn" end
                      else
                        if c < 11158 then return "So" else return "Cn" end
                      end
                    else
                      if c < 11197 then
                        if c < 11194 then return "So" else return "Cn" end
                      else
                        if c < 11209 then return "So" else return "Cn" end
                      end
                    end
                  end
                end
              else
                if c < 11371 then
                  if c < 11360 then
                    if c < 11264 then
                      if c < 11244 then
                        if c < 11219 then return "So" else return "Cn" end
                      else
                        if c < 11248 then return "So" else return "Cn" end
                      end
                    else
                      if c < 11312 then
                        if c < 11311 then return "Lu" else return "Cn" end
                      else
                        if c < 11359 then return "Ll" else return "Cn" end
                      end
                    end
                  else
                    if c < 11367 then
                      if c < 11362 then
                        if c < 11361 then return "Lu" else return "Ll" end
                      else
                        if c < 11365 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 11369 then
                        if c < 11368 then return "Lu" else return "Ll" end
                      else
                        if c < 11370 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 11388 then
                    if c < 11378 then
                      if c < 11373 then
                        if c < 11372 then return "Lu" else return "Ll" end
                      else
                        if c < 11377 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 11381 then
                        if c < 11379 then return "Lu" else return "Ll" end
                      else
                        if c < 11382 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 11395 then
                      if c < 11393 then
                        if c < 11390 then return "Lm" else return "Lu" end
                      else
                        if c < 11394 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 11397 then
                        if c < 11396 then return "Ll" else return "Lu" end
                      else
                        if c < 11398 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                end
              end
            end
          end
        end
      end
    end
  else
    if c < 69952 then
      if c < 43019 then
        if c < 12928 then
          if c < 11719 then
            if c < 11463 then
              if c < 11431 then
                if c < 11415 then
                  if c < 11407 then
                    if c < 11403 then
                      if c < 11401 then
                        if c < 11400 then return "Ll" else return "Lu" end
                      else
                        if c < 11402 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 11405 then
                        if c < 11404 then return "Ll" else return "Lu" end
                      else
                        if c < 11406 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 11411 then
                      if c < 11409 then
                        if c < 11408 then return "Ll" else return "Lu" end
                      else
                        if c < 11410 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 11413 then
                        if c < 11412 then return "Ll" else return "Lu" end
                      else
                        if c < 11414 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                else
                  if c < 11423 then
                    if c < 11419 then
                      if c < 11417 then
                        if c < 11416 then return "Ll" else return "Lu" end
                      else
                        if c < 11418 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 11421 then
                        if c < 11420 then return "Ll" else return "Lu" end
                      else
                        if c < 11422 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 11427 then
                      if c < 11425 then
                        if c < 11424 then return "Ll" else return "Lu" end
                      else
                        if c < 11426 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 11429 then
                        if c < 11428 then return "Ll" else return "Lu" end
                      else
                        if c < 11430 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                end
              else
                if c < 11447 then
                  if c < 11439 then
                    if c < 11435 then
                      if c < 11433 then
                        if c < 11432 then return "Ll" else return "Lu" end
                      else
                        if c < 11434 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 11437 then
                        if c < 11436 then return "Ll" else return "Lu" end
                      else
                        if c < 11438 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 11443 then
                      if c < 11441 then
                        if c < 11440 then return "Ll" else return "Lu" end
                      else
                        if c < 11442 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 11445 then
                        if c < 11444 then return "Ll" else return "Lu" end
                      else
                        if c < 11446 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                else
                  if c < 11455 then
                    if c < 11451 then
                      if c < 11449 then
                        if c < 11448 then return "Ll" else return "Lu" end
                      else
                        if c < 11450 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 11453 then
                        if c < 11452 then return "Ll" else return "Lu" end
                      else
                        if c < 11454 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 11459 then
                      if c < 11457 then
                        if c < 11456 then return "Ll" else return "Lu" end
                      else
                        if c < 11458 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 11461 then
                        if c < 11460 then return "Ll" else return "Lu" end
                      else
                        if c < 11462 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                end
              end
            else
              if c < 11501 then
                if c < 11479 then
                  if c < 11471 then
                    if c < 11467 then
                      if c < 11465 then
                        if c < 11464 then return "Ll" else return "Lu" end
                      else
                        if c < 11466 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 11469 then
                        if c < 11468 then return "Ll" else return "Lu" end
                      else
                        if c < 11470 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 11475 then
                      if c < 11473 then
                        if c < 11472 then return "Ll" else return "Lu" end
                      else
                        if c < 11474 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 11477 then
                        if c < 11476 then return "Ll" else return "Lu" end
                      else
                        if c < 11478 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                else
                  if c < 11487 then
                    if c < 11483 then
                      if c < 11481 then
                        if c < 11480 then return "Ll" else return "Lu" end
                      else
                        if c < 11482 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 11485 then
                        if c < 11484 then return "Ll" else return "Lu" end
                      else
                        if c < 11486 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 11491 then
                      if c < 11489 then
                        if c < 11488 then return "Ll" else return "Lu" end
                      else
                        if c < 11490 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 11499 then
                        if c < 11493 then return "Ll" else return "So" end
                      else
                        if c < 11500 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              else
                if c < 11624 then
                  if c < 11518 then
                    if c < 11507 then
                      if c < 11503 then
                        if c < 11502 then return "Lu" else return "Ll" end
                      else
                        if c < 11506 then return "Mn" else return "Lu" end
                      end
                    else
                      if c < 11513 then
                        if c < 11508 then return "Ll" else return "Cn" end
                      else
                        if c < 11517 then return "Po" else return "No" end
                      end
                    end
                  else
                    if c < 11560 then
                      if c < 11558 then
                        if c < 11520 then return "Po" else return "Ll" end
                      else
                        if c < 11559 then return "Cn" else return "Ll" end
                      end
                    else
                      if c < 11566 then
                        if c < 11565 then return "Cn" else return "Ll" end
                      else
                        if c < 11568 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                else
                  if c < 11687 then
                    if c < 11647 then
                      if c < 11632 then
                        if c < 11631 then return "Cn" else return "Lm" end
                      else
                        if c < 11633 then return "Po" else return "Cn" end
                      end
                    else
                      if c < 11671 then
                        if c < 11648 then return "Mn" else return "Lo" end
                      else
                        if c < 11680 then return "Cn" else return "Lo" end
                      end
                    end
                  else
                    if c < 11703 then
                      if c < 11695 then
                        if c < 11688 then return "Cn" else return "Lo" end
                      else
                        if c < 11696 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 11711 then
                        if c < 11704 then return "Cn" else return "Lo" end
                      else
                        if c < 11712 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                end
              end
            end
          else
            if c < 12299 then
              if c < 11813 then
                if c < 11787 then
                  if c < 11776 then
                    if c < 11735 then
                      if c < 11727 then
                        if c < 11720 then return "Cn" else return "Lo" end
                      else
                        if c < 11728 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 11743 then
                        if c < 11736 then return "Cn" else return "Lo" end
                      else
                        if c < 11744 then return "Cn" else return "Mn" end
                      end
                    end
                  else
                    if c < 11781 then
                      if c < 11779 then
                        if c < 11778 then return "Po" else return "Pi" end
                      else
                        if c < 11780 then return "Pf" else return "Pi" end
                      end
                    else
                      if c < 11785 then
                        if c < 11782 then return "Pf" else return "Po" end
                      else
                        if c < 11786 then return "Pi" else return "Pf" end
                      end
                    end
                  end
                else
                  if c < 11804 then
                    if c < 11799 then
                      if c < 11789 then
                        if c < 11788 then return "Po" else return "Pi" end
                      else
                        if c < 11790 then return "Pf" else return "Po" end
                      end
                    else
                      if c < 11802 then
                        if c < 11800 then return "Pd" else return "Po" end
                      else
                        if c < 11803 then return "Pd" else return "Po" end
                      end
                    end
                  else
                    if c < 11809 then
                      if c < 11806 then
                        if c < 11805 then return "Pi" else return "Pf" end
                      else
                        if c < 11808 then return "Po" else return "Pi" end
                      end
                    else
                      if c < 11811 then
                        if c < 11810 then return "Pf" else return "Ps" end
                      else
                        if c < 11812 then return "Pe" else return "Ps" end
                      end
                    end
                  end
                end
              else
                if c < 11930 then
                  if c < 11834 then
                    if c < 11817 then
                      if c < 11815 then
                        if c < 11814 then return "Pe" else return "Ps" end
                      else
                        if c < 11816 then return "Pe" else return "Ps" end
                      end
                    else
                      if c < 11823 then
                        if c < 11818 then return "Pe" else return "Po" end
                      else
                        if c < 11824 then return "Lm" else return "Po" end
                      end
                    end
                  else
                    if c < 11842 then
                      if c < 11840 then
                        if c < 11836 then return "Pd" else return "Po" end
                      else
                        if c < 11841 then return "Pd" else return "Po" end
                      end
                    else
                      if c < 11850 then
                        if c < 11843 then return "Ps" else return "Po" end
                      else
                        if c < 11904 then return "Cn" else return "So" end
                      end
                    end
                  end
                else
                  if c < 12289 then
                    if c < 12246 then
                      if c < 12020 then
                        if c < 11931 then return "Cn" else return "So" end
                      else
                        if c < 12032 then return "Cn" else return "So" end
                      end
                    else
                      if c < 12284 then
                        if c < 12272 then return "Cn" else return "So" end
                      else
                        if c < 12288 then return "Cn" else return "Zs" end
                      end
                    end
                  else
                    if c < 12295 then
                      if c < 12293 then
                        if c < 12292 then return "Po" else return "So" end
                      else
                        if c < 12294 then return "Lm" else return "Lo" end
                      end
                    else
                      if c < 12297 then
                        if c < 12296 then return "Nl" else return "Ps" end
                      else
                        if c < 12298 then return "Pe" else return "Ps" end
                      end
                    end
                  end
                end
              end
            else
              if c < 12353 then
                if c < 12316 then
                  if c < 12308 then
                    if c < 12303 then
                      if c < 12301 then
                        if c < 12300 then return "Pe" else return "Ps" end
                      else
                        if c < 12302 then return "Pe" else return "Ps" end
                      end
                    else
                      if c < 12305 then
                        if c < 12304 then return "Pe" else return "Ps" end
                      else
                        if c < 12306 then return "Pe" else return "So" end
                      end
                    end
                  else
                    if c < 12312 then
                      if c < 12310 then
                        if c < 12309 then return "Ps" else return "Pe" end
                      else
                        if c < 12311 then return "Ps" else return "Pe" end
                      end
                    else
                      if c < 12314 then
                        if c < 12313 then return "Ps" else return "Pe" end
                      else
                        if c < 12315 then return "Ps" else return "Pe" end
                      end
                    end
                  end
                else
                  if c < 12337 then
                    if c < 12321 then
                      if c < 12318 then
                        if c < 12317 then return "Pd" else return "Ps" end
                      else
                        if c < 12320 then return "Pe" else return "So" end
                      end
                    else
                      if c < 12334 then
                        if c < 12330 then return "Nl" else return "Mn" end
                      else
                        if c < 12336 then return "Mc" else return "Pd" end
                      end
                    end
                  else
                    if c < 12348 then
                      if c < 12344 then
                        if c < 12342 then return "Lm" else return "So" end
                      else
                        if c < 12347 then return "Nl" else return "Lm" end
                      end
                    else
                      if c < 12350 then
                        if c < 12349 then return "Lo" else return "Po" end
                      else
                        if c < 12352 then return "So" else return "Cn" end
                      end
                    end
                  end
                end
              else
                if c < 12688 then
                  if c < 12539 then
                    if c < 12445 then
                      if c < 12441 then
                        if c < 12439 then return "Lo" else return "Cn" end
                      else
                        if c < 12443 then return "Mn" else return "Sk" end
                      end
                    else
                      if c < 12448 then
                        if c < 12447 then return "Lm" else return "Lo" end
                      else
                        if c < 12449 then return "Pd" else return "Lo" end
                      end
                    end
                  else
                    if c < 12549 then
                      if c < 12543 then
                        if c < 12540 then return "Po" else return "Lm" end
                      else
                        if c < 12544 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 12593 then
                        if c < 12591 then return "Lo" else return "Cn" end
                      else
                        if c < 12687 then return "Lo" else return "Cn" end
                      end
                    end
                  end
                else
                  if c < 12800 then
                    if c < 12731 then
                      if c < 12694 then
                        if c < 12690 then return "So" else return "No" end
                      else
                        if c < 12704 then return "So" else return "Lo" end
                      end
                    else
                      if c < 12772 then
                        if c < 12736 then return "Cn" else return "So" end
                      else
                        if c < 12784 then return "Cn" else return "Lo" end
                      end
                    end
                  else
                    if c < 12872 then
                      if c < 12832 then
                        if c < 12831 then return "So" else return "Cn" end
                      else
                        if c < 12842 then return "No" else return "So" end
                      end
                    else
                      if c < 12881 then
                        if c < 12880 then return "No" else return "So" end
                      else
                        if c < 12896 then return "No" else return "So" end
                      end
                    end
                  end
                end
              end
            end
          end
        else
          if c < 42796 then
            if c < 42597 then
              if c < 42565 then
                if c < 42183 then
                  if c < 19904 then
                    if c < 13055 then
                      if c < 12977 then
                        if c < 12938 then return "No" else return "So" end
                      else
                        if c < 12992 then return "No" else return "So" end
                      end
                    else
                      if c < 13312 then
                        if c < 13056 then return "Cn" else return "So" end
                      else
                        if c < 19894 then return "Lo" else return "Cn" end
                      end
                    end
                  else
                    if c < 40981 then
                      if c < 40939 then
                        if c < 19968 then return "So" else return "Lo" end
                      else
                        if c < 40960 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 42125 then
                        if c < 40982 then return "Lm" else return "Lo" end
                      else
                        if c < 42128 then return "Cn" else return "So" end
                      end
                    end
                  end
                else
                  if c < 42528 then
                    if c < 42240 then
                      if c < 42232 then
                        if c < 42192 then return "Cn" else return "Lo" end
                      else
                        if c < 42238 then return "Lm" else return "Po" end
                      end
                    else
                      if c < 42509 then
                        if c < 42508 then return "Lo" else return "Lm" end
                      else
                        if c < 42512 then return "Po" else return "Lo" end
                      end
                    end
                  else
                    if c < 42561 then
                      if c < 42540 then
                        if c < 42538 then return "Nd" else return "Lo" end
                      else
                        if c < 42560 then return "Cn" else return "Lu" end
                      end
                    else
                      if c < 42563 then
                        if c < 42562 then return "Ll" else return "Lu" end
                      else
                        if c < 42564 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                end
              else
                if c < 42581 then
                  if c < 42573 then
                    if c < 42569 then
                      if c < 42567 then
                        if c < 42566 then return "Ll" else return "Lu" end
                      else
                        if c < 42568 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 42571 then
                        if c < 42570 then return "Ll" else return "Lu" end
                      else
                        if c < 42572 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 42577 then
                      if c < 42575 then
                        if c < 42574 then return "Ll" else return "Lu" end
                      else
                        if c < 42576 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 42579 then
                        if c < 42578 then return "Ll" else return "Lu" end
                      else
                        if c < 42580 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                else
                  if c < 42589 then
                    if c < 42585 then
                      if c < 42583 then
                        if c < 42582 then return "Ll" else return "Lu" end
                      else
                        if c < 42584 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 42587 then
                        if c < 42586 then return "Ll" else return "Lu" end
                      else
                        if c < 42588 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 42593 then
                      if c < 42591 then
                        if c < 42590 then return "Ll" else return "Lu" end
                      else
                        if c < 42592 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 42595 then
                        if c < 42594 then return "Ll" else return "Lu" end
                      else
                        if c < 42596 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                end
              end
            else
              if c < 42640 then
                if c < 42624 then
                  if c < 42605 then
                    if c < 42601 then
                      if c < 42599 then
                        if c < 42598 then return "Ll" else return "Lu" end
                      else
                        if c < 42600 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 42603 then
                        if c < 42602 then return "Ll" else return "Lu" end
                      else
                        if c < 42604 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 42611 then
                      if c < 42607 then
                        if c < 42606 then return "Ll" else return "Lo" end
                      else
                        if c < 42608 then return "Mn" else return "Me" end
                      end
                    else
                      if c < 42622 then
                        if c < 42612 then return "Po" else return "Mn" end
                      else
                        if c < 42623 then return "Po" else return "Lm" end
                      end
                    end
                  end
                else
                  if c < 42632 then
                    if c < 42628 then
                      if c < 42626 then
                        if c < 42625 then return "Lu" else return "Ll" end
                      else
                        if c < 42627 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 42630 then
                        if c < 42629 then return "Lu" else return "Ll" end
                      else
                        if c < 42631 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 42636 then
                      if c < 42634 then
                        if c < 42633 then return "Lu" else return "Ll" end
                      else
                        if c < 42635 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 42638 then
                        if c < 42637 then return "Lu" else return "Ll" end
                      else
                        if c < 42639 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              else
                if c < 42736 then
                  if c < 42648 then
                    if c < 42644 then
                      if c < 42642 then
                        if c < 42641 then return "Lu" else return "Ll" end
                      else
                        if c < 42643 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 42646 then
                        if c < 42645 then return "Lu" else return "Ll" end
                      else
                        if c < 42647 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 42652 then
                      if c < 42650 then
                        if c < 42649 then return "Lu" else return "Ll" end
                      else
                        if c < 42651 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 42656 then
                        if c < 42654 then return "Lm" else return "Mn" end
                      else
                        if c < 42726 then return "Lo" else return "Nl" end
                      end
                    end
                  end
                else
                  if c < 42788 then
                    if c < 42775 then
                      if c < 42744 then
                        if c < 42738 then return "Mn" else return "Po" end
                      else
                        if c < 42752 then return "Cn" else return "Sk" end
                      end
                    else
                      if c < 42786 then
                        if c < 42784 then return "Lm" else return "Sk" end
                      else
                        if c < 42787 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 42792 then
                      if c < 42790 then
                        if c < 42789 then return "Lu" else return "Ll" end
                      else
                        if c < 42791 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 42794 then
                        if c < 42793 then return "Lu" else return "Ll" end
                      else
                        if c < 42795 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              end
            end
          else
            if c < 42862 then
              if c < 42830 then
                if c < 42814 then
                  if c < 42806 then
                    if c < 42802 then
                      if c < 42798 then
                        if c < 42797 then return "Lu" else return "Ll" end
                      else
                        if c < 42799 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 42804 then
                        if c < 42803 then return "Lu" else return "Ll" end
                      else
                        if c < 42805 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 42810 then
                      if c < 42808 then
                        if c < 42807 then return "Lu" else return "Ll" end
                      else
                        if c < 42809 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 42812 then
                        if c < 42811 then return "Lu" else return "Ll" end
                      else
                        if c < 42813 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 42822 then
                    if c < 42818 then
                      if c < 42816 then
                        if c < 42815 then return "Lu" else return "Ll" end
                      else
                        if c < 42817 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 42820 then
                        if c < 42819 then return "Lu" else return "Ll" end
                      else
                        if c < 42821 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 42826 then
                      if c < 42824 then
                        if c < 42823 then return "Lu" else return "Ll" end
                      else
                        if c < 42825 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 42828 then
                        if c < 42827 then return "Lu" else return "Ll" end
                      else
                        if c < 42829 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              else
                if c < 42846 then
                  if c < 42838 then
                    if c < 42834 then
                      if c < 42832 then
                        if c < 42831 then return "Lu" else return "Ll" end
                      else
                        if c < 42833 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 42836 then
                        if c < 42835 then return "Lu" else return "Ll" end
                      else
                        if c < 42837 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 42842 then
                      if c < 42840 then
                        if c < 42839 then return "Lu" else return "Ll" end
                      else
                        if c < 42841 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 42844 then
                        if c < 42843 then return "Lu" else return "Ll" end
                      else
                        if c < 42845 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 42854 then
                    if c < 42850 then
                      if c < 42848 then
                        if c < 42847 then return "Lu" else return "Ll" end
                      else
                        if c < 42849 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 42852 then
                        if c < 42851 then return "Lu" else return "Ll" end
                      else
                        if c < 42853 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 42858 then
                      if c < 42856 then
                        if c < 42855 then return "Lu" else return "Ll" end
                      else
                        if c < 42857 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 42860 then
                        if c < 42859 then return "Lu" else return "Ll" end
                      else
                        if c < 42861 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                end
              end
            else
              if c < 42905 then
                if c < 42886 then
                  if c < 42877 then
                    if c < 42873 then
                      if c < 42864 then
                        if c < 42863 then return "Lu" else return "Ll" end
                      else
                        if c < 42865 then return "Lm" else return "Ll" end
                      end
                    else
                      if c < 42875 then
                        if c < 42874 then return "Lu" else return "Ll" end
                      else
                        if c < 42876 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 42882 then
                      if c < 42880 then
                        if c < 42879 then return "Lu" else return "Ll" end
                      else
                        if c < 42881 then return "Lu" else return "Ll" end
                      end
                    else
                      if c < 42884 then
                        if c < 42883 then return "Lu" else return "Ll" end
                      else
                        if c < 42885 then return "Lu" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 42895 then
                    if c < 42891 then
                      if c < 42888 then
                        if c < 42887 then return "Lu" else return "Ll" end
                      else
                        if c < 42889 then return "Lm" else return "Sk" end
                      end
                    else
                      if c < 42893 then
                        if c < 42892 then return "Lu" else return "Ll" end
                      else
                        if c < 42894 then return "Lu" else return "Ll" end
                      end
                    end
                  else
                    if c < 42899 then
                      if c < 42897 then
                        if c < 42896 then return "Lo" else return "Lu" end
                      else
                        if c < 42898 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 42903 then
                        if c < 42902 then return "Ll" else return "Lu" end
                      else
                        if c < 42904 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                end
              else
                if c < 42921 then
                  if c < 42913 then
                    if c < 42909 then
                      if c < 42907 then
                        if c < 42906 then return "Ll" else return "Lu" end
                      else
                        if c < 42908 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 42911 then
                        if c < 42910 then return "Ll" else return "Lu" end
                      else
                        if c < 42912 then return "Ll" else return "Lu" end
                      end
                    end
                  else
                    if c < 42917 then
                      if c < 42915 then
                        if c < 42914 then return "Ll" else return "Lu" end
                      else
                        if c < 42916 then return "Ll" else return "Lu" end
                      end
                    else
                      if c < 42919 then
                        if c < 42918 then return "Ll" else return "Lu" end
                      else
                        if c < 42920 then return "Ll" else return "Lu" end
                      end
                    end
                  end
                else
                  if c < 42999 then
                    if c < 42933 then
                      if c < 42927 then
                        if c < 42922 then return "Ll" else return "Lu" end
                      else
                        if c < 42928 then return "Cn" else return "Lu" end
                      end
                    else
                      if c < 42935 then
                        if c < 42934 then return "Ll" else return "Lu" end
                      else
                        if c < 42936 then return "Ll" else return "Cn" end
                      end
                    end
                  else
                    if c < 43010 then
                      if c < 43002 then
                        if c < 43000 then return "Lo" else return "Lm" end
                      else
                        if c < 43003 then return "Ll" else return "Lo" end
                      end
                    else
                      if c < 43014 then
                        if c < 43011 then return "Mn" else return "Lo" end
                      else
                        if c < 43015 then return "Mn" else return "Lo" end
                      end
                    end
                  end
                end
              end
            end
          end
        end
      else
        if c < 65339 then
          if c < 43968 then
            if c < 43561 then
              if c < 43302 then
                if c < 43138 then
                  if c < 43062 then
                    if c < 43047 then
                      if c < 43043 then
                        if c < 43020 then return "Mn" else return "Lo" end
                      else
                        if c < 43045 then return "Mc" else return "Mn" end
                      end
                    else
                      if c < 43052 then
                        if c < 43048 then return "Mc" else return "So" end
                      else
                        if c < 43056 then return "Cn" else return "No" end
                      end
                    end
                  else
                    if c < 43072 then
                      if c < 43065 then
                        if c < 43064 then return "So" else return "Sc" end
                      else
                        if c < 43066 then return "So" else return "Cn" end
                      end
                    else
                      if c < 43128 then
                        if c < 43124 then return "Lo" else return "Po" end
                      else
                        if c < 43136 then return "Cn" else return "Mc" end
                      end
                    end
                  end
                else
                  if c < 43250 then
                    if c < 43214 then
                      if c < 43204 then
                        if c < 43188 then return "Lo" else return "Mc" end
                      else
                        if c < 43206 then return "Mn" else return "Cn" end
                      end
                    else
                      if c < 43226 then
                        if c < 43216 then return "Po" else return "Nd" end
                      else
                        if c < 43232 then return "Cn" else return "Mn" end
                      end
                    end
                  else
                    if c < 43261 then
                      if c < 43259 then
                        if c < 43256 then return "Lo" else return "Po" end
                      else
                        if c < 43260 then return "Lo" else return "Po" end
                      end
                    else
                      if c < 43264 then
                        if c < 43262 then return "Lo" else return "Cn" end
                      else
                        if c < 43274 then return "Nd" else return "Lo" end
                      end
                    end
                  end
                end
              else
                if c < 43452 then
                  if c < 43389 then
                    if c < 43346 then
                      if c < 43312 then
                        if c < 43310 then return "Mn" else return "Po" end
                      else
                        if c < 43335 then return "Lo" else return "Mn" end
                      end
                    else
                      if c < 43359 then
                        if c < 43348 then return "Mc" else return "Cn" end
                      else
                        if c < 43360 then return "Po" else return "Lo" end
                      end
                    end
                  else
                    if c < 43443 then
                      if c < 43395 then
                        if c < 43392 then return "Cn" else return "Mn" end
                      else
                        if c < 43396 then return "Mc" else return "Lo" end
                      end
                    else
                      if c < 43446 then
                        if c < 43444 then return "Mn" else return "Mc" end
                      else
                        if c < 43450 then return "Mn" else return "Mc" end
                      end
                    end
                  end
                else
                  if c < 43488 then
                    if c < 43471 then
                      if c < 43457 then
                        if c < 43453 then return "Mn" else return "Mc" end
                      else
                        if c < 43470 then return "Po" else return "Cn" end
                      end
                    else
                      if c < 43482 then
                        if c < 43472 then return "Lm" else return "Nd" end
                      else
                        if c < 43486 then return "Cn" else return "Po" end
                      end
                    end
                  else
                    if c < 43504 then
                      if c < 43494 then
                        if c < 43493 then return "Lo" else return "Mn" end
                      else
                        if c < 43495 then return "Lm" else return "Lo" end
                      end
                    else
                      if c < 43519 then
                        if c < 43514 then return "Nd" else return "Lo" end
                      else
                        if c < 43520 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                end
              end
            else
              if c < 43713 then
                if c < 43632 then
                  if c < 43588 then
                    if c < 43573 then
                      if c < 43569 then
                        if c < 43567 then return "Mn" else return "Mc" end
                      else
                        if c < 43571 then return "Mn" else return "Mc" end
                      end
                    else
                      if c < 43584 then
                        if c < 43575 then return "Mn" else return "Cn" end
                      else
                        if c < 43587 then return "Lo" else return "Mn" end
                      end
                    end
                  else
                    if c < 43600 then
                      if c < 43597 then
                        if c < 43596 then return "Lo" else return "Mn" end
                      else
                        if c < 43598 then return "Mc" else return "Cn" end
                      end
                    else
                      if c < 43612 then
                        if c < 43610 then return "Nd" else return "Cn" end
                      else
                        if c < 43616 then return "Po" else return "Lo" end
                      end
                    end
                  end
                else
                  if c < 43696 then
                    if c < 43643 then
                      if c < 43639 then
                        if c < 43633 then return "Lm" else return "Lo" end
                      else
                        if c < 43642 then return "So" else return "Lo" end
                      end
                    else
                      if c < 43645 then
                        if c < 43644 then return "Mc" else return "Mn" end
                      else
                        if c < 43646 then return "Mc" else return "Lo" end
                      end
                    end
                  else
                    if c < 43703 then
                      if c < 43698 then
                        if c < 43697 then return "Mn" else return "Lo" end
                      else
                        if c < 43701 then return "Mn" else return "Lo" end
                      end
                    else
                      if c < 43710 then
                        if c < 43705 then return "Mn" else return "Lo" end
                      else
                        if c < 43712 then return "Mn" else return "Lo" end
                      end
                    end
                  end
                end
              else
                if c < 43777 then
                  if c < 43756 then
                    if c < 43741 then
                      if c < 43715 then
                        if c < 43714 then return "Mn" else return "Lo" end
                      else
                        if c < 43739 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 43744 then
                        if c < 43742 then return "Lm" else return "Po" end
                      else
                        if c < 43755 then return "Lo" else return "Mc" end
                      end
                    end
                  else
                    if c < 43763 then
                      if c < 43760 then
                        if c < 43758 then return "Mn" else return "Mc" end
                      else
                        if c < 43762 then return "Po" else return "Lo" end
                      end
                    else
                      if c < 43766 then
                        if c < 43765 then return "Lm" else return "Mc" end
                      else
                        if c < 43767 then return "Mn" else return "Cn" end
                      end
                    end
                  end
                else
                  if c < 43816 then
                    if c < 43793 then
                      if c < 43785 then
                        if c < 43783 then return "Lo" else return "Cn" end
                      else
                        if c < 43791 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 43808 then
                        if c < 43799 then return "Lo" else return "Cn" end
                      else
                        if c < 43815 then return "Lo" else return "Cn" end
                      end
                    end
                  else
                    if c < 43868 then
                      if c < 43824 then
                        if c < 43823 then return "Lo" else return "Cn" end
                      else
                        if c < 43867 then return "Ll" else return "Sk" end
                      end
                    else
                      if c < 43878 then
                        if c < 43872 then return "Lm" else return "Ll" end
                      else
                        if c < 43888 then return "Cn" else return "Ll" end
                      end
                    end
                  end
                end
              end
            end
          else
            if c < 65072 then
              if c < 64298 then
                if c < 55243 then
                  if c < 44013 then
                    if c < 44008 then
                      if c < 44005 then
                        if c < 44003 then return "Lo" else return "Mc" end
                      else
                        if c < 44006 then return "Mn" else return "Mc" end
                      end
                    else
                      if c < 44011 then
                        if c < 44009 then return "Mn" else return "Mc" end
                      else
                        if c < 44012 then return "Po" else return "Mc" end
                      end
                    end
                  else
                    if c < 44032 then
                      if c < 44016 then
                        if c < 44014 then return "Mn" else return "Cn" end
                      else
                        if c < 44026 then return "Nd" else return "Cn" end
                      end
                    else
                      if c < 55216 then
                        if c < 55204 then return "Lo" else return "Cn" end
                      else
                        if c < 55239 then return "Lo" else return "Cn" end
                      end
                    end
                  end
                else
                  if c < 64256 then
                    if c < 63744 then
                      if c < 55296 then
                        if c < 55292 then return "Lo" else return "Cn" end
                      else
                        if c < 57344 then return "Cs" else return "Co" end
                      end
                    else
                      if c < 64112 then
                        if c < 64110 then return "Lo" else return "Cn" end
                      else
                        if c < 64218 then return "Lo" else return "Cn" end
                      end
                    end
                  else
                    if c < 64285 then
                      if c < 64275 then
                        if c < 64263 then return "Ll" else return "Cn" end
                      else
                        if c < 64280 then return "Ll" else return "Cn" end
                      end
                    else
                      if c < 64287 then
                        if c < 64286 then return "Lo" else return "Mn" end
                      else
                        if c < 64297 then return "Lo" else return "Sm" end
                      end
                    end
                  end
                end
              else
                if c < 64832 then
                  if c < 64323 then
                    if c < 64318 then
                      if c < 64312 then
                        if c < 64311 then return "Lo" else return "Cn" end
                      else
                        if c < 64317 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 64320 then
                        if c < 64319 then return "Lo" else return "Cn" end
                      else
                        if c < 64322 then return "Lo" else return "Cn" end
                      end
                    end
                  else
                    if c < 64450 then
                      if c < 64326 then
                        if c < 64325 then return "Lo" else return "Cn" end
                      else
                        if c < 64434 then return "Lo" else return "Sk" end
                      end
                    else
                      if c < 64830 then
                        if c < 64467 then return "Cn" else return "Lo" end
                      else
                        if c < 64831 then return "Pe" else return "Ps" end
                      end
                    end
                  end
                else
                  if c < 65022 then
                    if c < 64968 then
                      if c < 64912 then
                        if c < 64848 then return "Cn" else return "Lo" end
                      else
                        if c < 64914 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 65020 then
                        if c < 65008 then return "Cn" else return "Lo" end
                      else
                        if c < 65021 then return "Sc" else return "So" end
                      end
                    end
                  else
                    if c < 65048 then
                      if c < 65040 then
                        if c < 65024 then return "Cn" else return "Mn" end
                      else
                        if c < 65047 then return "Po" else return "Ps" end
                      end
                    else
                      if c < 65050 then
                        if c < 65049 then return "Pe" else return "Po" end
                      else
                        if c < 65056 then return "Cn" else return "Mn" end
                      end
                    end
                  end
                end
              end
            else
              if c < 65117 then
                if c < 65090 then
                  if c < 65082 then
                    if c < 65078 then
                      if c < 65075 then
                        if c < 65073 then return "Po" else return "Pd" end
                      else
                        if c < 65077 then return "Pc" else return "Ps" end
                      end
                    else
                      if c < 65080 then
                        if c < 65079 then return "Pe" else return "Ps" end
                      else
                        if c < 65081 then return "Pe" else return "Ps" end
                      end
                    end
                  else
                    if c < 65086 then
                      if c < 65084 then
                        if c < 65083 then return "Pe" else return "Ps" end
                      else
                        if c < 65085 then return "Pe" else return "Ps" end
                      end
                    else
                      if c < 65088 then
                        if c < 65087 then return "Pe" else return "Ps" end
                      else
                        if c < 65089 then return "Pe" else return "Ps" end
                      end
                    end
                  end
                else
                  if c < 65104 then
                    if c < 65095 then
                      if c < 65092 then
                        if c < 65091 then return "Pe" else return "Ps" end
                      else
                        if c < 65093 then return "Pe" else return "Po" end
                      end
                    else
                      if c < 65097 then
                        if c < 65096 then return "Ps" else return "Pe" end
                      else
                        if c < 65101 then return "Po" else return "Pc" end
                      end
                    end
                  else
                    if c < 65113 then
                      if c < 65108 then
                        if c < 65107 then return "Po" else return "Cn" end
                      else
                        if c < 65112 then return "Po" else return "Pd" end
                      end
                    else
                      if c < 65115 then
                        if c < 65114 then return "Ps" else return "Pe" end
                      else
                        if c < 65116 then return "Ps" else return "Pe" end
                      end
                    end
                  end
                end
              else
                if c < 65280 then
                  if c < 65129 then
                    if c < 65123 then
                      if c < 65119 then
                        if c < 65118 then return "Ps" else return "Pe" end
                      else
                        if c < 65122 then return "Po" else return "Sm" end
                      end
                    else
                      if c < 65127 then
                        if c < 65124 then return "Pd" else return "Sm" end
                      else
                        if c < 65128 then return "Cn" else return "Po" end
                      end
                    end
                  else
                    if c < 65141 then
                      if c < 65132 then
                        if c < 65130 then return "Sc" else return "Po" end
                      else
                        if c < 65136 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 65277 then
                        if c < 65142 then return "Cn" else return "Lo" end
                      else
                        if c < 65279 then return "Cn" else return "Cf" end
                      end
                    end
                  end
                else
                  if c < 65292 then
                    if c < 65288 then
                      if c < 65284 then
                        if c < 65281 then return "Cn" else return "Po" end
                      else
                        if c < 65285 then return "Sc" else return "Po" end
                      end
                    else
                      if c < 65290 then
                        if c < 65289 then return "Ps" else return "Pe" end
                      else
                        if c < 65291 then return "Po" else return "Sm" end
                      end
                    end
                  else
                    if c < 65306 then
                      if c < 65294 then
                        if c < 65293 then return "Po" else return "Pd" end
                      else
                        if c < 65296 then return "Po" else return "Nd" end
                      end
                    else
                      if c < 65311 then
                        if c < 65308 then return "Po" else return "Sm" end
                      else
                        if c < 65313 then return "Po" else return "Lu" end
                      end
                    end
                  end
                end
              end
            end
          end
        else
          if c < 67593 then
            if c < 65909 then
              if c < 65506 then
                if c < 65380 then
                  if c < 65372 then
                    if c < 65343 then
                      if c < 65341 then
                        if c < 65340 then return "Ps" else return "Po" end
                      else
                        if c < 65342 then return "Pe" else return "Sk" end
                      end
                    else
                      if c < 65345 then
                        if c < 65344 then return "Pc" else return "Sk" end
                      else
                        if c < 65371 then return "Ll" else return "Ps" end
                      end
                    end
                  else
                    if c < 65376 then
                      if c < 65374 then
                        if c < 65373 then return "Sm" else return "Pe" end
                      else
                        if c < 65375 then return "Sm" else return "Ps" end
                      end
                    else
                      if c < 65378 then
                        if c < 65377 then return "Pe" else return "Po" end
                      else
                        if c < 65379 then return "Ps" else return "Pe" end
                      end
                    end
                  end
                else
                  if c < 65480 then
                    if c < 65438 then
                      if c < 65392 then
                        if c < 65382 then return "Po" else return "Lo" end
                      else
                        if c < 65393 then return "Lm" else return "Lo" end
                      end
                    else
                      if c < 65471 then
                        if c < 65440 then return "Lm" else return "Lo" end
                      else
                        if c < 65474 then return "Cn" else return "Lo" end
                      end
                    end
                  else
                    if c < 65496 then
                      if c < 65488 then
                        if c < 65482 then return "Cn" else return "Lo" end
                      else
                        if c < 65490 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 65501 then
                        if c < 65498 then return "Cn" else return "Lo" end
                      else
                        if c < 65504 then return "Cn" else return "Sc" end
                      end
                    end
                  end
                end
              else
                if c < 65576 then
                  if c < 65519 then
                    if c < 65511 then
                      if c < 65508 then
                        if c < 65507 then return "Sm" else return "Sk" end
                      else
                        if c < 65509 then return "So" else return "Sc" end
                      end
                    else
                      if c < 65513 then
                        if c < 65512 then return "Cn" else return "So" end
                      else
                        if c < 65517 then return "Sm" else return "So" end
                      end
                    end
                  else
                    if c < 65536 then
                      if c < 65532 then
                        if c < 65529 then return "Cn" else return "Cf" end
                      else
                        if c < 65534 then return "So" else return "Cn" end
                      end
                    else
                      if c < 65549 then
                        if c < 65548 then return "Lo" else return "Cn" end
                      else
                        if c < 65575 then return "Lo" else return "Cn" end
                      end
                    end
                  end
                else
                  if c < 65664 then
                    if c < 65599 then
                      if c < 65596 then
                        if c < 65595 then return "Lo" else return "Cn" end
                      else
                        if c < 65598 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 65616 then
                        if c < 65614 then return "Lo" else return "Cn" end
                      else
                        if c < 65630 then return "Lo" else return "Cn" end
                      end
                    end
                  else
                    if c < 65799 then
                      if c < 65792 then
                        if c < 65787 then return "Lo" else return "Cn" end
                      else
                        if c < 65795 then return "Po" else return "Cn" end
                      end
                    else
                      if c < 65847 then
                        if c < 65844 then return "No" else return "Cn" end
                      else
                        if c < 65856 then return "So" else return "Nl" end
                      end
                    end
                  end
                end
              end
            else
              if c < 66463 then
                if c < 66272 then
                  if c < 65953 then
                    if c < 65935 then
                      if c < 65930 then
                        if c < 65913 then return "No" else return "So" end
                      else
                        if c < 65932 then return "No" else return "So" end
                      end
                    else
                      if c < 65948 then
                        if c < 65936 then return "Cn" else return "So" end
                      else
                        if c < 65952 then return "Cn" else return "So" end
                      end
                    end
                  else
                    if c < 66176 then
                      if c < 66045 then
                        if c < 66000 then return "Cn" else return "So" end
                      else
                        if c < 66046 then return "Mn" else return "Cn" end
                      end
                    else
                      if c < 66208 then
                        if c < 66205 then return "Lo" else return "Cn" end
                      else
                        if c < 66257 then return "Lo" else return "Cn" end
                      end
                    end
                  end
                else
                  if c < 66370 then
                    if c < 66336 then
                      if c < 66300 then
                        if c < 66273 then return "Mn" else return "No" end
                      else
                        if c < 66304 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 66349 then
                        if c < 66340 then return "No" else return "Cn" end
                      else
                        if c < 66369 then return "Lo" else return "Nl" end
                      end
                    end
                  else
                    if c < 66422 then
                      if c < 66379 then
                        if c < 66378 then return "Lo" else return "Nl" end
                      else
                        if c < 66384 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 66432 then
                        if c < 66427 then return "Mn" else return "Cn" end
                      else
                        if c < 66462 then return "Lo" else return "Cn" end
                      end
                    end
                  end
                end
              else
                if c < 66812 then
                  if c < 66600 then
                    if c < 66512 then
                      if c < 66500 then
                        if c < 66464 then return "Po" else return "Lo" end
                      else
                        if c < 66504 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 66518 then
                        if c < 66513 then return "Po" else return "Nl" end
                      else
                        if c < 66560 then return "Cn" else return "Lu" end
                      end
                    end
                  else
                    if c < 66730 then
                      if c < 66718 then
                        if c < 66640 then return "Ll" else return "Lo" end
                      else
                        if c < 66720 then return "Cn" else return "Nd" end
                      end
                    else
                      if c < 66772 then
                        if c < 66736 then return "Cn" else return "Lu" end
                      else
                        if c < 66776 then return "Cn" else return "Ll" end
                      end
                    end
                  end
                else
                  if c < 67383 then
                    if c < 66916 then
                      if c < 66856 then
                        if c < 66816 then return "Cn" else return "Lo" end
                      else
                        if c < 66864 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 66928 then
                        if c < 66927 then return "Cn" else return "Po" end
                      else
                        if c < 67072 then return "Cn" else return "Lo" end
                      end
                    end
                  else
                    if c < 67432 then
                      if c < 67414 then
                        if c < 67392 then return "Cn" else return "Lo" end
                      else
                        if c < 67424 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 67590 then
                        if c < 67584 then return "Cn" else return "Lo" end
                      else
                        if c < 67592 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                end
              end
            end
          else
            if c < 68296 then
              if c < 68024 then
                if c < 67751 then
                  if c < 67670 then
                    if c < 67641 then
                      if c < 67638 then
                        if c < 67594 then return "Cn" else return "Lo" end
                      else
                        if c < 67639 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 67645 then
                        if c < 67644 then return "Cn" else return "Lo" end
                      else
                        if c < 67647 then return "Cn" else return "Lo" end
                      end
                    end
                  else
                    if c < 67703 then
                      if c < 67672 then
                        if c < 67671 then return "Cn" else return "Po" end
                      else
                        if c < 67680 then return "No" else return "Lo" end
                      end
                    else
                      if c < 67712 then
                        if c < 67705 then return "So" else return "No" end
                      else
                        if c < 67743 then return "Lo" else return "Cn" end
                      end
                    end
                  end
                else
                  if c < 67862 then
                    if c < 67828 then
                      if c < 67808 then
                        if c < 67760 then return "No" else return "Cn" end
                      else
                        if c < 67827 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 67835 then
                        if c < 67830 then return "Lo" else return "Cn" end
                      else
                        if c < 67840 then return "No" else return "Lo" end
                      end
                    end
                  else
                    if c < 67898 then
                      if c < 67871 then
                        if c < 67868 then return "No" else return "Cn" end
                      else
                        if c < 67872 then return "Po" else return "Lo" end
                      end
                    else
                      if c < 67904 then
                        if c < 67903 then return "Cn" else return "Po" end
                      else
                        if c < 67968 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                end
              else
                if c < 68121 then
                  if c < 68100 then
                    if c < 68048 then
                      if c < 68030 then
                        if c < 68028 then return "Cn" else return "No" end
                      else
                        if c < 68032 then return "Lo" else return "No" end
                      end
                    else
                      if c < 68096 then
                        if c < 68050 then return "Cn" else return "No" end
                      else
                        if c < 68097 then return "Lo" else return "Mn" end
                      end
                    end
                  else
                    if c < 68112 then
                      if c < 68103 then
                        if c < 68101 then return "Cn" else return "Mn" end
                      else
                        if c < 68108 then return "Cn" else return "Mn" end
                      end
                    else
                      if c < 68117 then
                        if c < 68116 then return "Lo" else return "Cn" end
                      else
                        if c < 68120 then return "Lo" else return "Cn" end
                      end
                    end
                  end
                else
                  if c < 68185 then
                    if c < 68159 then
                      if c < 68152 then
                        if c < 68148 then return "Lo" else return "Cn" end
                      else
                        if c < 68155 then return "Mn" else return "Cn" end
                      end
                    else
                      if c < 68168 then
                        if c < 68160 then return "Mn" else return "No" end
                      else
                        if c < 68176 then return "Cn" else return "Po" end
                      end
                    end
                  else
                    if c < 68224 then
                      if c < 68221 then
                        if c < 68192 then return "Cn" else return "Lo" end
                      else
                        if c < 68223 then return "No" else return "Po" end
                      end
                    else
                      if c < 68256 then
                        if c < 68253 then return "Lo" else return "No" end
                      else
                        if c < 68288 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                end
              end
            else
              if c < 69632 then
                if c < 68480 then
                  if c < 68406 then
                    if c < 68331 then
                      if c < 68325 then
                        if c < 68297 then return "So" else return "Lo" end
                      else
                        if c < 68327 then return "Mn" else return "Cn" end
                      end
                    else
                      if c < 68343 then
                        if c < 68336 then return "No" else return "Po" end
                      else
                        if c < 68352 then return "Cn" else return "Lo" end
                      end
                    end
                  else
                    if c < 68440 then
                      if c < 68416 then
                        if c < 68409 then return "Cn" else return "Po" end
                      else
                        if c < 68438 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 68467 then
                        if c < 68448 then return "No" else return "Lo" end
                      else
                        if c < 68472 then return "Cn" else return "No" end
                      end
                    end
                  end
                else
                  if c < 68736 then
                    if c < 68521 then
                      if c < 68505 then
                        if c < 68498 then return "Lo" else return "Cn" end
                      else
                        if c < 68509 then return "Po" else return "Cn" end
                      end
                    else
                      if c < 68608 then
                        if c < 68528 then return "No" else return "Cn" end
                      else
                        if c < 68681 then return "Lo" else return "Cn" end
                      end
                    end
                  else
                    if c < 68858 then
                      if c < 68800 then
                        if c < 68787 then return "Lu" else return "Cn" end
                      else
                        if c < 68851 then return "Ll" else return "Cn" end
                      end
                    else
                      if c < 69216 then
                        if c < 68864 then return "No" else return "Cn" end
                      else
                        if c < 69247 then return "No" else return "Cn" end
                      end
                    end
                  end
                end
              else
                if c < 69817 then
                  if c < 69734 then
                    if c < 69688 then
                      if c < 69634 then
                        if c < 69633 then return "Mc" else return "Mn" end
                      else
                        if c < 69635 then return "Mc" else return "Lo" end
                      end
                    else
                      if c < 69710 then
                        if c < 69703 then return "Mn" else return "Po" end
                      else
                        if c < 69714 then return "Cn" else return "No" end
                      end
                    end
                  else
                    if c < 69763 then
                      if c < 69759 then
                        if c < 69744 then return "Nd" else return "Cn" end
                      else
                        if c < 69762 then return "Mn" else return "Mc" end
                      end
                    else
                      if c < 69811 then
                        if c < 69808 then return "Lo" else return "Mc" end
                      else
                        if c < 69815 then return "Mn" else return "Mc" end
                      end
                    end
                  end
                else
                  if c < 69882 then
                    if c < 69826 then
                      if c < 69821 then
                        if c < 69819 then return "Mn" else return "Po" end
                      else
                        if c < 69822 then return "Cf" else return "Po" end
                      end
                    else
                      if c < 69865 then
                        if c < 69840 then return "Cn" else return "Lo" end
                      else
                        if c < 69872 then return "Cn" else return "Nd" end
                      end
                    end
                  else
                    if c < 69932 then
                      if c < 69891 then
                        if c < 69888 then return "Cn" else return "Mn" end
                      else
                        if c < 69927 then return "Lo" else return "Mn" end
                      end
                    else
                      if c < 69941 then
                        if c < 69933 then return "Mc" else return "Mn" end
                      else
                        if c < 69942 then return "Cn" else return "Nd" end
                      end
                    end
                  end
                end
              end
            end
          end
        end
      end
    else
      if c < 120068 then
        if c < 73032 then
          if c < 71102 then
            if c < 70441 then
              if c < 70196 then
                if c < 70093 then
                  if c < 70018 then
                    if c < 70004 then
                      if c < 69968 then
                        if c < 69956 then return "Po" else return "Cn" end
                      else
                        if c < 70003 then return "Lo" else return "Mn" end
                      end
                    else
                      if c < 70007 then
                        if c < 70006 then return "Po" else return "Lo" end
                      else
                        if c < 70016 then return "Cn" else return "Mn" end
                      end
                    end
                  else
                    if c < 70079 then
                      if c < 70067 then
                        if c < 70019 then return "Mc" else return "Lo" end
                      else
                        if c < 70070 then return "Mc" else return "Mn" end
                      end
                    else
                      if c < 70085 then
                        if c < 70081 then return "Mc" else return "Lo" end
                      else
                        if c < 70090 then return "Po" else return "Mn" end
                      end
                    end
                  end
                else
                  if c < 70113 then
                    if c < 70107 then
                      if c < 70096 then
                        if c < 70094 then return "Po" else return "Cn" end
                      else
                        if c < 70106 then return "Nd" else return "Lo" end
                      end
                    else
                      if c < 70109 then
                        if c < 70108 then return "Po" else return "Lo" end
                      else
                        if c < 70112 then return "Po" else return "Cn" end
                      end
                    end
                  else
                    if c < 70163 then
                      if c < 70144 then
                        if c < 70133 then return "No" else return "Cn" end
                      else
                        if c < 70162 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 70191 then
                        if c < 70188 then return "Lo" else return "Mc" end
                      else
                        if c < 70194 then return "Mn" else return "Mc" end
                      end
                    end
                  end
                end
              else
                if c < 70314 then
                  if c < 70280 then
                    if c < 70206 then
                      if c < 70198 then
                        if c < 70197 then return "Mn" else return "Mc" end
                      else
                        if c < 70200 then return "Mn" else return "Po" end
                      end
                    else
                      if c < 70272 then
                        if c < 70207 then return "Mn" else return "Cn" end
                      else
                        if c < 70279 then return "Lo" else return "Cn" end
                      end
                    end
                  else
                    if c < 70287 then
                      if c < 70282 then
                        if c < 70281 then return "Lo" else return "Cn" end
                      else
                        if c < 70286 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 70303 then
                        if c < 70302 then return "Lo" else return "Cn" end
                      else
                        if c < 70313 then return "Lo" else return "Po" end
                      end
                    end
                  end
                else
                  if c < 70400 then
                    if c < 70371 then
                      if c < 70367 then
                        if c < 70320 then return "Cn" else return "Lo" end
                      else
                        if c < 70368 then return "Mn" else return "Mc" end
                      end
                    else
                      if c < 70384 then
                        if c < 70379 then return "Mn" else return "Cn" end
                      else
                        if c < 70394 then return "Nd" else return "Cn" end
                      end
                    end
                  else
                    if c < 70413 then
                      if c < 70404 then
                        if c < 70402 then return "Mn" else return "Mc" end
                      else
                        if c < 70405 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 70417 then
                        if c < 70415 then return "Cn" else return "Lo" end
                      else
                        if c < 70419 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                end
              end
            else
              if c < 70722 then
                if c < 70478 then
                  if c < 70461 then
                    if c < 70452 then
                      if c < 70449 then
                        if c < 70442 then return "Cn" else return "Lo" end
                      else
                        if c < 70450 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 70458 then
                        if c < 70453 then return "Cn" else return "Lo" end
                      else
                        if c < 70460 then return "Cn" else return "Mn" end
                      end
                    end
                  else
                    if c < 70469 then
                      if c < 70464 then
                        if c < 70462 then return "Lo" else return "Mc" end
                      else
                        if c < 70465 then return "Mn" else return "Mc" end
                      end
                    else
                      if c < 70473 then
                        if c < 70471 then return "Cn" else return "Mc" end
                      else
                        if c < 70475 then return "Cn" else return "Mc" end
                      end
                    end
                  end
                else
                  if c < 70502 then
                    if c < 70488 then
                      if c < 70481 then
                        if c < 70480 then return "Cn" else return "Lo" end
                      else
                        if c < 70487 then return "Cn" else return "Mc" end
                      end
                    else
                      if c < 70498 then
                        if c < 70493 then return "Cn" else return "Lo" end
                      else
                        if c < 70500 then return "Mc" else return "Cn" end
                      end
                    end
                  else
                    if c < 70656 then
                      if c < 70512 then
                        if c < 70509 then return "Mn" else return "Cn" end
                      else
                        if c < 70517 then return "Mn" else return "Cn" end
                      end
                    else
                      if c < 70712 then
                        if c < 70709 then return "Lo" else return "Mc" end
                      else
                        if c < 70720 then return "Mn" else return "Mc" end
                      end
                    end
                  end
                end
              else
                if c < 70843 then
                  if c < 70748 then
                    if c < 70731 then
                      if c < 70726 then
                        if c < 70725 then return "Mn" else return "Mc" end
                      else
                        if c < 70727 then return "Mn" else return "Lo" end
                      end
                    else
                      if c < 70746 then
                        if c < 70736 then return "Po" else return "Nd" end
                      else
                        if c < 70747 then return "Cn" else return "Po" end
                      end
                    end
                  else
                    if c < 70832 then
                      if c < 70750 then
                        if c < 70749 then return "Cn" else return "Po" end
                      else
                        if c < 70784 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 70841 then
                        if c < 70835 then return "Mc" else return "Mn" end
                      else
                        if c < 70842 then return "Mc" else return "Mn" end
                      end
                    end
                  end
                else
                  if c < 70864 then
                    if c < 70852 then
                      if c < 70849 then
                        if c < 70847 then return "Mc" else return "Mn" end
                      else
                        if c < 70850 then return "Mc" else return "Mn" end
                      end
                    else
                      if c < 70855 then
                        if c < 70854 then return "Lo" else return "Po" end
                      else
                        if c < 70856 then return "Lo" else return "Cn" end
                      end
                    end
                  else
                    if c < 71090 then
                      if c < 71040 then
                        if c < 70874 then return "Nd" else return "Cn" end
                      else
                        if c < 71087 then return "Lo" else return "Mc" end
                      end
                    else
                      if c < 71096 then
                        if c < 71094 then return "Mn" else return "Cn" end
                      else
                        if c < 71100 then return "Mc" else return "Mn" end
                      end
                    end
                  end
                end
              end
            end
          else
            if c < 72273 then
              if c < 71450 then
                if c < 71248 then
                  if c < 71219 then
                    if c < 71132 then
                      if c < 71105 then
                        if c < 71103 then return "Mc" else return "Mn" end
                      else
                        if c < 71128 then return "Po" else return "Lo" end
                      end
                    else
                      if c < 71168 then
                        if c < 71134 then return "Mn" else return "Cn" end
                      else
                        if c < 71216 then return "Lo" else return "Mc" end
                      end
                    end
                  else
                    if c < 71231 then
                      if c < 71229 then
                        if c < 71227 then return "Mn" else return "Mc" end
                      else
                        if c < 71230 then return "Mn" else return "Mc" end
                      end
                    else
                      if c < 71236 then
                        if c < 71233 then return "Mn" else return "Po" end
                      else
                        if c < 71237 then return "Lo" else return "Cn" end
                      end
                    end
                  end
                else
                  if c < 71342 then
                    if c < 71296 then
                      if c < 71264 then
                        if c < 71258 then return "Nd" else return "Cn" end
                      else
                        if c < 71277 then return "Po" else return "Cn" end
                      end
                    else
                      if c < 71340 then
                        if c < 71339 then return "Lo" else return "Mn" end
                      else
                        if c < 71341 then return "Mc" else return "Mn" end
                      end
                    end
                  else
                    if c < 71352 then
                      if c < 71350 then
                        if c < 71344 then return "Mc" else return "Mn" end
                      else
                        if c < 71351 then return "Mc" else return "Mn" end
                      end
                    else
                      if c < 71370 then
                        if c < 71360 then return "Cn" else return "Nd" end
                      else
                        if c < 71424 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                end
              else
                if c < 71923 then
                  if c < 71482 then
                    if c < 71462 then
                      if c < 71456 then
                        if c < 71453 then return "Cn" else return "Mn" end
                      else
                        if c < 71458 then return "Mc" else return "Mn" end
                      end
                    else
                      if c < 71468 then
                        if c < 71463 then return "Mc" else return "Mn" end
                      else
                        if c < 71472 then return "Cn" else return "Nd" end
                      end
                    end
                  else
                    if c < 71840 then
                      if c < 71487 then
                        if c < 71484 then return "No" else return "Po" end
                      else
                        if c < 71488 then return "So" else return "Cn" end
                      end
                    else
                      if c < 71904 then
                        if c < 71872 then return "Lu" else return "Ll" end
                      else
                        if c < 71914 then return "Nd" else return "No" end
                      end
                    end
                  end
                else
                  if c < 72243 then
                    if c < 72193 then
                      if c < 71936 then
                        if c < 71935 then return "Cn" else return "Lo" end
                      else
                        if c < 72192 then return "Cn" else return "Lo" end
                      end
                    else
                      if c < 72201 then
                        if c < 72199 then return "Mn" else return "Mc" end
                      else
                        if c < 72203 then return "Mn" else return "Lo" end
                      end
                    end
                  else
                    if c < 72255 then
                      if c < 72250 then
                        if c < 72249 then return "Mn" else return "Mc" end
                      else
                        if c < 72251 then return "Lo" else return "Mn" end
                      end
                    else
                      if c < 72264 then
                        if c < 72263 then return "Po" else return "Mn" end
                      else
                        if c < 72272 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                end
              end
            else
              if c < 72848 then
                if c < 72713 then
                  if c < 72344 then
                    if c < 72324 then
                      if c < 72281 then
                        if c < 72279 then return "Mn" else return "Mc" end
                      else
                        if c < 72284 then return "Mn" else return "Lo" end
                      end
                    else
                      if c < 72330 then
                        if c < 72326 then return "Cn" else return "Lo" end
                      else
                        if c < 72343 then return "Mn" else return "Mc" end
                      end
                    end
                  else
                    if c < 72355 then
                      if c < 72349 then
                        if c < 72346 then return "Mn" else return "Po" end
                      else
                        if c < 72350 then return "Cn" else return "Po" end
                      end
                    else
                      if c < 72441 then
                        if c < 72384 then return "Cn" else return "Lo" end
                      else
                        if c < 72704 then return "Cn" else return "Lo" end
                      end
                    end
                  end
                else
                  if c < 72768 then
                    if c < 72759 then
                      if c < 72751 then
                        if c < 72714 then return "Cn" else return "Lo" end
                      else
                        if c < 72752 then return "Mc" else return "Mn" end
                      end
                    else
                      if c < 72766 then
                        if c < 72760 then return "Cn" else return "Mn" end
                      else
                        if c < 72767 then return "Mc" else return "Mn" end
                      end
                    end
                  else
                    if c < 72794 then
                      if c < 72774 then
                        if c < 72769 then return "Lo" else return "Po" end
                      else
                        if c < 72784 then return "Cn" else return "Nd" end
                      end
                    else
                      if c < 72816 then
                        if c < 72813 then return "No" else return "Cn" end
                      else
                        if c < 72818 then return "Po" else return "Lo" end
                      end
                    end
                  end
                end
              else
                if c < 73015 then
                  if c < 72885 then
                    if c < 72874 then
                      if c < 72872 then
                        if c < 72850 then return "Cn" else return "Mn" end
                      else
                        if c < 72873 then return "Cn" else return "Mc" end
                      end
                    else
                      if c < 72882 then
                        if c < 72881 then return "Mn" else return "Mc" end
                      else
                        if c < 72884 then return "Mn" else return "Mc" end
                      end
                    end
                  else
                    if c < 72968 then
                      if c < 72960 then
                        if c < 72887 then return "Mn" else return "Cn" end
                      else
                        if c < 72967 then return "Lo" else return "Cn" end
                      end
                    else
                      if c < 72971 then
                        if c < 72970 then return "Lo" else return "Cn" end
                      else
                        if c < 73009 then return "Lo" else return "Mn" end
                      end
                    end
                  end
                else
                  if c < 73022 then
                    if c < 73019 then
                      if c < 73018 then return "Cn" else return "Mn" end
                    else
                      if c < 73020 then return "Cn" else return "Mn" end
                    end
                  else
                    if c < 73030 then
                      if c < 73023 then return "Cn" else return "Mn" end
                    else
                      if c < 73031 then return "Lo" else return "Mn" end
                    end
                  end
                end
              end
            end
          end
        else
          if c < 113776 then
            if c < 92992 then
              if c < 92729 then
                if c < 74869 then
                  if c < 74650 then
                    if c < 73050 then
                      if c < 73040 then return "Cn" else return "Nd" end
                    else
                      if c < 73728 then return "Cn" else return "Lo" end
                    end
                  else
                    if c < 74863 then
                      if c < 74752 then return "Cn" else return "Nl" end
                    else
                      if c < 74864 then return "Cn" else return "Po" end
                    end
                  end
                else
                  if c < 78895 then
                    if c < 75076 then
                      if c < 74880 then return "Cn" else return "Lo" end
                    else
                      if c < 77824 then return "Cn" else return "Lo" end
                    end
                  else
                    if c < 83527 then
                      if c < 82944 then return "Cn" else return "Lo" end
                    else
                      if c < 92160 then return "Cn" else return "Lo" end
                    end
                  end
                end
              else
                if c < 92910 then
                  if c < 92778 then
                    if c < 92767 then
                      if c < 92736 then return "Cn" else return "Lo" end
                    else
                      if c < 92768 then return "Cn" else return "Nd" end
                    end
                  else
                    if c < 92784 then
                      if c < 92782 then return "Cn" else return "Po" end
                    else
                      if c < 92880 then return "Cn" else return "Lo" end
                    end
                  end
                else
                  if c < 92928 then
                    if c < 92917 then
                      if c < 92912 then return "Cn" else return "Mn" end
                    else
                      if c < 92918 then return "Po" else return "Cn" end
                    end
                  else
                    if c < 92983 then
                      if c < 92976 then return "Lo" else return "Mn" end
                    else
                      if c < 92988 then return "Po" else return "So" end
                    end
                  end
                end
              end
            else
              if c < 94079 then
                if c < 93027 then
                  if c < 93008 then
                    if c < 92997 then
                      if c < 92996 then return "Lm" else return "Po" end
                    else
                      if c < 92998 then return "So" else return "Cn" end
                    end
                  else
                    if c < 93019 then
                      if c < 93018 then return "Nd" else return "Cn" end
                    else
                      if c < 93026 then return "No" else return "Cn" end
                    end
                  end
                else
                  if c < 93952 then
                    if c < 93053 then
                      if c < 93048 then return "Lo" else return "Cn" end
                    else
                      if c < 93072 then return "Lo" else return "Cn" end
                    end
                  else
                    if c < 94032 then
                      if c < 94021 then return "Lo" else return "Cn" end
                    else
                      if c < 94033 then return "Lo" else return "Mc" end
                    end
                  end
                end
              else
                if c < 100352 then
                  if c < 94176 then
                    if c < 94099 then
                      if c < 94095 then return "Cn" else return "Mn" end
                    else
                      if c < 94112 then return "Lm" else return "Cn" end
                    end
                  else
                    if c < 94208 then
                      if c < 94178 then return "Lm" else return "Cn" end
                    else
                      if c < 100333 then return "Lo" else return "Cn" end
                    end
                  end
                else
                  if c < 110960 then
                    if c < 110592 then
                      if c < 101107 then return "Lo" else return "Cn" end
                    else
                      if c < 110879 then return "Lo" else return "Cn" end
                    end
                  else
                    if c < 113664 then
                      if c < 111356 then return "Lo" else return "Cn" end
                    else
                      if c < 113771 then return "Lo" else return "Cn" end
                    end
                  end
                end
              end
            end
          else
            if c < 119552 then
              if c < 119141 then
                if c < 113823 then
                  if c < 113808 then
                    if c < 113792 then
                      if c < 113789 then return "Lo" else return "Cn" end
                    else
                      if c < 113801 then return "Lo" else return "Cn" end
                    end
                  else
                    if c < 113820 then
                      if c < 113818 then return "Lo" else return "Cn" end
                    else
                      if c < 113821 then return "So" else return "Mn" end
                    end
                  end
                else
                  if c < 119030 then
                    if c < 113828 then
                      if c < 113824 then return "Po" else return "Cf" end
                    else
                      if c < 118784 then return "Cn" else return "So" end
                    end
                  else
                    if c < 119079 then
                      if c < 119040 then return "Cn" else return "So" end
                    else
                      if c < 119081 then return "Cn" else return "So" end
                    end
                  end
                end
              else
                if c < 119180 then
                  if c < 119155 then
                    if c < 119146 then
                      if c < 119143 then return "Mc" else return "Mn" end
                    else
                      if c < 119149 then return "So" else return "Mc" end
                    end
                  else
                    if c < 119171 then
                      if c < 119163 then return "Cf" else return "Mn" end
                    else
                      if c < 119173 then return "So" else return "Mn" end
                    end
                  end
                else
                  if c < 119296 then
                    if c < 119214 then
                      if c < 119210 then return "So" else return "Mn" end
                    else
                      if c < 119273 then return "So" else return "Cn" end
                    end
                  else
                    if c < 119365 then
                      if c < 119362 then return "So" else return "Mn" end
                    else
                      if c < 119366 then return "So" else return "Cn" end
                    end
                  end
                end
              end
            else
              if c < 119970 then
                if c < 119893 then
                  if c < 119808 then
                    if c < 119648 then
                      if c < 119639 then return "So" else return "Cn" end
                    else
                      if c < 119666 then return "No" else return "Cn" end
                    end
                  else
                    if c < 119860 then
                      if c < 119834 then return "Lu" else return "Ll" end
                    else
                      if c < 119886 then return "Lu" else return "Ll" end
                    end
                  end
                else
                  if c < 119964 then
                    if c < 119912 then
                      if c < 119894 then return "Cn" else return "Ll" end
                    else
                      if c < 119938 then return "Lu" else return "Ll" end
                    end
                  else
                    if c < 119966 then
                      if c < 119965 then return "Lu" else return "Cn" end
                    else
                      if c < 119968 then return "Lu" else return "Cn" end
                    end
                  end
                end
              else
                if c < 119994 then
                  if c < 119977 then
                    if c < 119973 then
                      if c < 119971 then return "Lu" else return "Cn" end
                    else
                      if c < 119975 then return "Lu" else return "Cn" end
                    end
                  else
                    if c < 119982 then
                      if c < 119981 then return "Lu" else return "Cn" end
                    else
                      if c < 119990 then return "Lu" else return "Ll" end
                    end
                  end
                else
                  if c < 120004 then
                    if c < 119996 then
                      if c < 119995 then return "Cn" else return "Ll" end
                    else
                      if c < 119997 then return "Cn" else return "Ll" end
                    end
                  else
                    if c < 120016 then
                      if c < 120005 then return "Cn" else return "Ll" end
                    else
                      if c < 120042 then return "Lu" else return "Ll" end
                    end
                  end
                end
              end
            end
          end
        end
      else
        if c < 126545 then
          if c < 121399 then
            if c < 120486 then
              if c < 120135 then
                if c < 120094 then
                  if c < 120077 then
                    if c < 120071 then
                      if c < 120070 then return "Lu" else return "Cn" end
                    else
                      if c < 120075 then return "Lu" else return "Cn" end
                    end
                  else
                    if c < 120086 then
                      if c < 120085 then return "Lu" else return "Cn" end
                    else
                      if c < 120093 then return "Lu" else return "Cn" end
                    end
                  end
                else
                  if c < 120127 then
                    if c < 120122 then
                      if c < 120120 then return "Ll" else return "Lu" end
                    else
                      if c < 120123 then return "Cn" else return "Lu" end
                    end
                  else
                    if c < 120133 then
                      if c < 120128 then return "Cn" else return "Lu" end
                    else
                      if c < 120134 then return "Cn" else return "Lu" end
                    end
                  end
                end
              else
                if c < 120276 then
                  if c < 120172 then
                    if c < 120145 then
                      if c < 120138 then return "Cn" else return "Lu" end
                    else
                      if c < 120146 then return "Cn" else return "Ll" end
                    end
                  else
                    if c < 120224 then
                      if c < 120198 then return "Lu" else return "Ll" end
                    else
                      if c < 120250 then return "Lu" else return "Ll" end
                    end
                  end
                else
                  if c < 120380 then
                    if c < 120328 then
                      if c < 120302 then return "Lu" else return "Ll" end
                    else
                      if c < 120354 then return "Lu" else return "Ll" end
                    end
                  else
                    if c < 120432 then
                      if c < 120406 then return "Lu" else return "Ll" end
                    else
                      if c < 120458 then return "Lu" else return "Ll" end
                    end
                  end
                end
              end
            else
              if c < 120662 then
                if c < 120572 then
                  if c < 120539 then
                    if c < 120513 then
                      if c < 120488 then return "Cn" else return "Lu" end
                    else
                      if c < 120514 then return "Sm" else return "Ll" end
                    end
                  else
                    if c < 120546 then
                      if c < 120540 then return "Sm" else return "Ll" end
                    else
                      if c < 120571 then return "Lu" else return "Sm" end
                    end
                  end
                else
                  if c < 120629 then
                    if c < 120598 then
                      if c < 120597 then return "Ll" else return "Sm" end
                    else
                      if c < 120604 then return "Ll" else return "Lu" end
                    end
                  else
                    if c < 120655 then
                      if c < 120630 then return "Sm" else return "Ll" end
                    else
                      if c < 120656 then return "Sm" else return "Ll" end
                    end
                  end
                end
              else
                if c < 120771 then
                  if c < 120714 then
                    if c < 120688 then
                      if c < 120687 then return "Lu" else return "Sm" end
                    else
                      if c < 120713 then return "Ll" else return "Sm" end
                    end
                  else
                    if c < 120745 then
                      if c < 120720 then return "Ll" else return "Lu" end
                    else
                      if c < 120746 then return "Sm" else return "Ll" end
                    end
                  end
                else
                  if c < 120780 then
                    if c < 120778 then
                      if c < 120772 then return "Sm" else return "Ll" end
                    else
                      if c < 120779 then return "Lu" else return "Ll" end
                    end
                  else
                    if c < 120832 then
                      if c < 120782 then return "Cn" else return "Nd" end
                    else
                      if c < 121344 then return "So" else return "Mn" end
                    end
                  end
                end
              end
            end
          else
            if c < 125264 then
              if c < 122905 then
                if c < 121484 then
                  if c < 121462 then
                    if c < 121453 then
                      if c < 121403 then return "So" else return "Mn" end
                    else
                      if c < 121461 then return "So" else return "Mn" end
                    end
                  else
                    if c < 121477 then
                      if c < 121476 then return "So" else return "Mn" end
                    else
                      if c < 121479 then return "So" else return "Po" end
                    end
                  end
                else
                  if c < 121520 then
                    if c < 121504 then
                      if c < 121499 then return "Cn" else return "Mn" end
                    else
                      if c < 121505 then return "Cn" else return "Mn" end
                    end
                  else
                    if c < 122887 then
                      if c < 122880 then return "Cn" else return "Mn" end
                    else
                      if c < 122888 then return "Cn" else return "Mn" end
                    end
                  end
                end
              else
                if c < 125125 then
                  if c < 122917 then
                    if c < 122914 then
                      if c < 122907 then return "Cn" else return "Mn" end
                    else
                      if c < 122915 then return "Cn" else return "Mn" end
                    end
                  else
                    if c < 122923 then
                      if c < 122918 then return "Cn" else return "Mn" end
                    else
                      if c < 124928 then return "Cn" else return "Lo" end
                    end
                  end
                else
                  if c < 125184 then
                    if c < 125136 then
                      if c < 125127 then return "Cn" else return "No" end
                    else
                      if c < 125143 then return "Mn" else return "Cn" end
                    end
                  else
                    if c < 125252 then
                      if c < 125218 then return "Lu" else return "Ll" end
                    else
                      if c < 125259 then return "Mn" else return "Cn" end
                    end
                  end
                end
              end
            else
              if c < 126516 then
                if c < 126497 then
                  if c < 126464 then
                    if c < 125278 then
                      if c < 125274 then return "Nd" else return "Cn" end
                    else
                      if c < 125280 then return "Po" else return "Cn" end
                    end
                  else
                    if c < 126469 then
                      if c < 126468 then return "Lo" else return "Cn" end
                    else
                      if c < 126496 then return "Lo" else return "Cn" end
                    end
                  end
                else
                  if c < 126503 then
                    if c < 126500 then
                      if c < 126499 then return "Lo" else return "Cn" end
                    else
                      if c < 126501 then return "Lo" else return "Cn" end
                    end
                  else
                    if c < 126505 then
                      if c < 126504 then return "Lo" else return "Cn" end
                    else
                      if c < 126515 then return "Lo" else return "Cn" end
                    end
                  end
                end
              else
                if c < 126535 then
                  if c < 126523 then
                    if c < 126521 then
                      if c < 126520 then return "Lo" else return "Cn" end
                    else
                      if c < 126522 then return "Lo" else return "Cn" end
                    end
                  else
                    if c < 126530 then
                      if c < 126524 then return "Lo" else return "Cn" end
                    else
                      if c < 126531 then return "Lo" else return "Cn" end
                    end
                  end
                else
                  if c < 126539 then
                    if c < 126537 then
                      if c < 126536 then return "Lo" else return "Cn" end
                    else
                      if c < 126538 then return "Lo" else return "Cn" end
                    end
                  else
                    if c < 126541 then
                      if c < 126540 then return "Lo" else return "Cn" end
                    else
                      if c < 126544 then return "Lo" else return "Cn" end
                    end
                  end
                end
              end
            end
          end
        else
          if c < 127552 then
            if c < 126625 then
              if c < 126564 then
                if c < 126555 then
                  if c < 126551 then
                    if c < 126548 then
                      if c < 126547 then return "Lo" else return "Cn" end
                    else
                      if c < 126549 then return "Lo" else return "Cn" end
                    end
                  else
                    if c < 126553 then
                      if c < 126552 then return "Lo" else return "Cn" end
                    else
                      if c < 126554 then return "Lo" else return "Cn" end
                    end
                  end
                else
                  if c < 126559 then
                    if c < 126557 then
                      if c < 126556 then return "Lo" else return "Cn" end
                    else
                      if c < 126558 then return "Lo" else return "Cn" end
                    end
                  else
                    if c < 126561 then
                      if c < 126560 then return "Lo" else return "Cn" end
                    else
                      if c < 126563 then return "Lo" else return "Cn" end
                    end
                  end
                end
              else
                if c < 126585 then
                  if c < 126572 then
                    if c < 126567 then
                      if c < 126565 then return "Lo" else return "Cn" end
                    else
                      if c < 126571 then return "Lo" else return "Cn" end
                    end
                  else
                    if c < 126580 then
                      if c < 126579 then return "Lo" else return "Cn" end
                    else
                      if c < 126584 then return "Lo" else return "Cn" end
                    end
                  end
                else
                  if c < 126592 then
                    if c < 126590 then
                      if c < 126589 then return "Lo" else return "Cn" end
                    else
                      if c < 126591 then return "Lo" else return "Cn" end
                    end
                  else
                    if c < 126603 then
                      if c < 126602 then return "Lo" else return "Cn" end
                    else
                      if c < 126620 then return "Lo" else return "Cn" end
                    end
                  end
                end
              end
            else
              if c < 127169 then
                if c < 126976 then
                  if c < 126635 then
                    if c < 126629 then
                      if c < 126628 then return "Lo" else return "Cn" end
                    else
                      if c < 126634 then return "Lo" else return "Cn" end
                    end
                  else
                    if c < 126704 then
                      if c < 126652 then return "Lo" else return "Cn" end
                    else
                      if c < 126706 then return "Sm" else return "Cn" end
                    end
                  end
                else
                  if c < 127136 then
                    if c < 127024 then
                      if c < 127020 then return "So" else return "Cn" end
                    else
                      if c < 127124 then return "So" else return "Cn" end
                    end
                  else
                    if c < 127153 then
                      if c < 127151 then return "So" else return "Cn" end
                    else
                      if c < 127168 then return "So" else return "Cn" end
                    end
                  end
                end
              else
                if c < 127280 then
                  if c < 127232 then
                    if c < 127185 then
                      if c < 127184 then return "So" else return "Cn" end
                    else
                      if c < 127222 then return "So" else return "Cn" end
                    end
                  else
                    if c < 127248 then
                      if c < 127245 then return "No" else return "Cn" end
                    else
                      if c < 127279 then return "So" else return "Cn" end
                    end
                  end
                else
                  if c < 127462 then
                    if c < 127344 then
                      if c < 127340 then return "So" else return "Cn" end
                    else
                      if c < 127405 then return "So" else return "Cn" end
                    end
                  else
                    if c < 127504 then
                      if c < 127491 then return "So" else return "Cn" end
                    else
                      if c < 127548 then return "So" else return "Cn" end
                    end
                  end
                end
              end
            end
          else
            if c < 129344 then
              if c < 128896 then
                if c < 128000 then
                  if c < 127584 then
                    if c < 127568 then
                      if c < 127561 then return "So" else return "Cn" end
                    else
                      if c < 127570 then return "So" else return "Cn" end
                    end
                  else
                    if c < 127744 then
                      if c < 127590 then return "So" else return "Cn" end
                    else
                      if c < 127995 then return "So" else return "Sk" end
                    end
                  end
                else
                  if c < 128752 then
                    if c < 128736 then
                      if c < 128725 then return "So" else return "Cn" end
                    else
                      if c < 128749 then return "So" else return "Cn" end
                    end
                  else
                    if c < 128768 then
                      if c < 128761 then return "So" else return "Cn" end
                    else
                      if c < 128884 then return "So" else return "Cn" end
                    end
                  end
                end
              else
                if c < 129120 then
                  if c < 129040 then
                    if c < 129024 then
                      if c < 128981 then return "So" else return "Cn" end
                    else
                      if c < 129036 then return "So" else return "Cn" end
                    end
                  else
                    if c < 129104 then
                      if c < 129096 then return "So" else return "Cn" end
                    else
                      if c < 129114 then return "So" else return "Cn" end
                    end
                  end
                else
                  if c < 129280 then
                    if c < 129168 then
                      if c < 129160 then return "So" else return "Cn" end
                    else
                      if c < 129198 then return "So" else return "Cn" end
                    end
                  else
                    if c < 129296 then
                      if c < 129292 then return "So" else return "Cn" end
                    else
                      if c < 129343 then return "So" else return "Cn" end
                    end
                  end
                end
              end
            else
              if c < 178208 then
                if c < 129488 then
                  if c < 129408 then
                    if c < 129360 then
                      if c < 129357 then return "So" else return "Cn" end
                    else
                      if c < 129388 then return "So" else return "Cn" end
                    end
                  else
                    if c < 129472 then
                      if c < 129432 then return "So" else return "Cn" end
                    else
                      if c < 129473 then return "So" else return "Cn" end
                    end
                  end
                else
                  if c < 173824 then
                    if c < 131072 then
                      if c < 129511 then return "So" else return "Cn" end
                    else
                      if c < 173783 then return "Lo" else return "Cn" end
                    end
                  else
                    if c < 177984 then
                      if c < 177973 then return "Lo" else return "Cn" end
                    else
                      if c < 178206 then return "Lo" else return "Cn" end
                    end
                  end
                end
              else
                if c < 917536 then
                  if c < 194560 then
                    if c < 183984 then
                      if c < 183970 then return "Lo" else return "Cn" end
                    else
                      if c < 191457 then return "Lo" else return "Cn" end
                    end
                  else
                    if c < 917505 then
                      if c < 195102 then return "Lo" else return "Cn" end
                    else
                      if c < 917506 then return "Cf" else return "Cn" end
                    end
                  end
                else
                  if c < 983040 then
                    if c < 917760 then
                      if c < 917632 then return "Cf" else return "Cn" end
                    else
                      if c < 918000 then return "Mn" else return "Cn" end
                    end
                  else
                    if c < 1048576 then
                      if c < 1048574 then return "Co" else return "Cn" end
                    else
                      if c < 1114110 then return "Co" else return "Cn" end
                    end
                  end
                end
              end
            end
          end
        end
      end
    end
  end
end
