lusty-store-mongo
=================

Mongo plugin for lusty persistence interface