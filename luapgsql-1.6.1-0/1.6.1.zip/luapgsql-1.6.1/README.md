A Lua Binding for PostgreSQL

Copyright (C) Micro Systems Marc Balmer.
You can reach the author at marc@msys.ch

Makefile is for BSD systems
GNUmakefile is for Linux systems

See luapgsql.md for full documentation.
