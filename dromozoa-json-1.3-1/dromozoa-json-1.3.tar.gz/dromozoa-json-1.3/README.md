# dromozoa-json

JSON encoder and decoder.

## References

* https://tools.ietf.org/html/rfc7159
* https://tools.ietf.org/html/rfc6901
* https://tools.ietf.org/html/rfc6902
