return {
  ["quiet"] = true,
  ["compress"] = "bz2"
}