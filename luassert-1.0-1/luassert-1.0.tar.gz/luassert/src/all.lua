--setup luassert
assert = require 'luassert.assert'
require 'luassert.modifiers'
require 'luassert.assertions'

spy = require 'luassert.spy'
mock = require 'luassert.mock'
require 'luassert.languages.en'
