#ifndef _LEDA_IO_H_
#define _LEDA_IO_H_

#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"

#include <sys/types.h>

int leda_wrap_io(lua_State *L);
int leda_unwrap_io(lua_State *L);
int socket_flush(lua_State *L);

#ifndef SYNC_IO

typedef unsigned long aio_context_t;

#if defined(__LITTLE_ENDIAN)
#define PADDED(x,y)	x, y
#else //if defined(__BIG_ENDIAN)
#define PADDED(x,y)	y, x
//#else
//#error edit for your odd byteorder.
#endif

enum {
	IOCB_CMD_PREAD = 0,
	IOCB_CMD_PWRITE = 1,
	IOCB_CMD_FSYNC = 2,
	IOCB_CMD_FDSYNC = 3,
	/* 
	 * IOCB_CMD_PREADX = 4,
	 * IOCB_CMD_POLL = 5,
	 */
	IOCB_CMD_NOOP = 6,
	IOCB_CMD_PREADV = 7,
	IOCB_CMD_PWRITEV = 8,
};

struct io_event {
	u_int64_t           data;           /* the data field from the iocb */
	u_int64_t           obj;            /* what iocb this event came from */
	int64_t           res;            /* result code for this event */
	int64_t           res2;           /* secondary result */
};

struct iocb {
	/* these are internal to the kernel/libc. */
	u_int64_t	aio_data;	/* data to be returned in event's data */
	u_int32_t	PADDED(aio_key, aio_reserved1);
	/* the kernel sets aio_key to the req # */

	/* common fields */
	u_int16_t	aio_lio_opcode;	/* see IOCB_CMD_ above */
	int16_t	aio_reqprio;
	u_int32_t	aio_fildes;

	u_int64_t	aio_buf;
	u_int64_t	aio_nbytes;
	int64_t	aio_offset;

	/* extra parameters */
	u_int64_t	aio_reserved2;	

	u_int32_t	aio_flags;
	/*
	 * If different from 0, this is an eventfd to deliver AIO results to
	 */
	u_int32_t	aio_resfd;
}; /* 64 bytes */

int aio_init(aio_context_t ** ctx_p);
int aio_submit_read(int fd, char * buf, int size, void * data);
int aio_submit_write(int fd, const char * buf, int size, void * data);
long io_getevents(aio_context_t ctx, long min_nr, long nr,
			 struct io_event *events, struct timespec *tmo);
#endif

#endif// _LEDA_IO_H_
