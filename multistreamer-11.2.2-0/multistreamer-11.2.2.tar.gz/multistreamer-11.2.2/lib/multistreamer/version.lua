return {
  MAJOR = 11,
  MINOR = 2,
  PATCH = 2,
  STRING = '11.2.2',
}
