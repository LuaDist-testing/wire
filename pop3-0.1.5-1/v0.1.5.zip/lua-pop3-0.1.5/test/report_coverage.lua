require "luacov.runner".load_config(".luacov")
require "luacov.reporter.coveralls".report()
