# dromozoa-prl

Lua bindings for Parallels Virtualization SDK.
