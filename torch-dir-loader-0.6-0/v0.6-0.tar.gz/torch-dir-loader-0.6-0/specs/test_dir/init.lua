local object = {
  a = 1
}

return object
