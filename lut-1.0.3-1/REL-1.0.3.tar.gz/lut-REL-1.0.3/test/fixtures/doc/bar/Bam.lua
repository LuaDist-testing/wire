--[[------------------------------------------------------

  # Other example class

  Some simple doc example class.

  We can test links to methods: doc.DocTest.isOK.

--]]-----------------------------------------------------

