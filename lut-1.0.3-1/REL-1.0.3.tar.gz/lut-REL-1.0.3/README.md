lut [![Build Status](https://travis-ci.org/lubyk/lut.png)](https://travis-ci.org/lubyk/lut)
===

Lubyk utility library (provides documentation generation from lua code and testing).


[Documentation](http://doc.lubyk.org/lut.html).

install
-------

    luadist install lut

or

    luarocks install lut

