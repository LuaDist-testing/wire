luawebsocket
============

A WebSocket implementation for Lua, written in C

Copyright (C) 2014, 2015 by Micro Systems Marc Balmer, CH-5073 Gipf-Oberfrick.
All rights reserved.


