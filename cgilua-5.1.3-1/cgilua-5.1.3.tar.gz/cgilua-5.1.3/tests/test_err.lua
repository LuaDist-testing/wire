cgilua.htmlheader()
cgilua.put"Oi!"
--io.write"something\n"
cgilua.errorlog ("eca", "emerg")
