Much of the Wiki requires examples with tables. It is therefore useful to use iTorch and export to markdown that is then clenad from the scripts and entered into the Wiki.
