if [ "$(uname)" == "Linux" ]; then
  PLATFORM="linux" ;
elif [ "$(uname)" = "Darwin" ]; then
  PLATFORM="macosx" ;
fi
