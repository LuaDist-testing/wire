
require 'Coat'

class 'MyApp.Bar.Foo'

has.bar = { is = 'rw' }

