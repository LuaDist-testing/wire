
require 'Coat'

class 'MyApp.Baz.Foo'

has.baz = { is = 'rw' }

