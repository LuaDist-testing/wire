#!/usr/bin/env wsapi.cgi

require "toycms"

return toycms.run
