#!/usr/bin/lua

local function test_script()
  assert( 1 == 1 )
end

