# luasolr
Lua to Apache Solr connection module

Provides minimalistic interface to solr enabling posting and quering data records 
