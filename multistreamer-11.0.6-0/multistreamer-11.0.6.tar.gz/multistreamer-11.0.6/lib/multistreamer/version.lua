return {
  MAJOR = 11,
  MINOR = 0,
  PATCH = 6,
  STRING = '11.0.6',
}
