package.path = './spec/?.lua;../src/?.lua;'..package.path

describe("json output test", function()
  it("", function()
    assert.are.equal(true, true)
  end)
end)
