package.path = './spec/?.lua;../src/?.lua;'..package.path

describe("json input test", function()
  it("", function()
    assert.are.equal(true, true)
  end)
end)
