# dromozoa-utf8

Lua 5.3 compatible pure-Lua UTF-8 implementation.
