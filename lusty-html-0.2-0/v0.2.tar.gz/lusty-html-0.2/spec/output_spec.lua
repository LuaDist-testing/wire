package.path = './spec/?.lua;../src/?.lua;'..package.path

describe("html output test", function()
  it("", function()
    assert.are.equal(true, true)
  end)
end)
