-- Debugging is off by default
_G._DEBUG = _G._DEBUG or false
