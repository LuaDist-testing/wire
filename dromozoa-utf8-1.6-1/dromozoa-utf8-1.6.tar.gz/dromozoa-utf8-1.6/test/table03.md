a
:-:|-
foo
