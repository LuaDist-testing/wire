
return foo, bat
