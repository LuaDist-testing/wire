return {
  headers = {},
  send = function(body) end,
  ["end"] = function() end,
  status = 404
}
