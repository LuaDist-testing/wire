return {
  url = "",
  headers = {},
  data = {}
}
